# P1030680 crib search - code overview (for Jessica / HELUT comparison)

Christoffer Duif, October 2026. Written with Claude Code (AI). Comments and identifiers in the code are in **Danish**;
this file explains the parts that matter. Node.js 22+, WebGPU via Dawn (`npm i` in `sky/`, package `webgpu` 0.6.1).
Tested on RTX 5070 (Windows, D3D12) and RTX 5090 (Linux, Vulkan) - bit-identical results.

## Pipeline for one crib at one position

1. **GPU bombe** (`web/gpu-kerne-v5.js`, WGSL) - Turing-Welchman bombe with diagonal board, exhaustive over
   M4: 336 wheel orders x 104 "composite reflector" variants (greek wheel Beta/Gamma x 26 offsets x thin B/C,
   folded into one fixed reflector because the greek wheel never steps) = **34,944 units**; per unit all
   17,576 offsets (kL,kM,kR) x 26 right-ring values (turnover position). Menu window = best 26 letters of the crib.
   Output: "stops" (offsets + turnover pattern + one stecker hypothesis for the test letter).
2. **CPU finisher** (`solver.js`, worker threads) per stop: recover middle ring from the turnover pattern,
   propagate the crib equations over the WHOLE crib (not just the GPU window) - if that contradicts, retry with
   exactly one equation outside the window dropped (tolerates one garbled letter); then a plugboard hillclimb
   (trigram score + bonus per matching crib letter, max 10 pairs); keep if crib matches with <= 1 miss.
3. **Score + hit rule** (`ui.js`, `sky/koer.js`): trigram language model `ubaad.bin` (built from the decrypted U-534
   corpus) over the full 72 letters; alarm if <= 1 crib miss and score > -660 (real texts: -468..-568; false
   candidates top out around -633).

## Speed (RTX 5070, units/s; 34,944 units = one full crib)

| kernel | 26-letter crib | 18 | split crib with ?s | weak 14 |
|---|---|---|---|---|
| V3 (worklist propagation) | 135 | 123 | 111 | 129 |
| V4 (+ Turing loop test) | 398 | 821 | 651 | 217 |
| **V5** (+ step table, loop cache, Q cache) | **588** | **3,124** | **1,494** | **238** |

So one full crib is ~11-60 s (weak/short cribs are dominated by the number of stops, not the search).
Per crib that is 34,944 x 17,576 x 26 ~ 1.6e10 machine states, i.e. roughly 3e8-1.5e9 states/s on the GPU.

## The speed-ups (all verified bit-identical against a fixed set of 10 test jobs, `sky/test-v5.js` + `sky/facit-node.json`)

- **Loop test (V4)** - profiling showed 96 % of V3's time went into testing the 26 stecker hypotheses for the
  test letter. For every closed walk through the test letter in the menu, the product permutation P must have the
  correct stecker h as a fixed point (P(h) = h), otherwise full propagation would contradict on the edge that closes
  the loop. Walks are found on the CPU (BFS tree from the test letter; each non-tree edge gives a closed walk) and
  shipped to the kernel; only fixed points (~1 of 26) get full propagation. Same stops, 3-7x faster.
- **Step table (V5)** - the rotor stepping pattern in the window depends only on (middle start, right start); 676
  patterns per unit are computed once per workgroup and packed in one u32 each (first index where dL>=1, dL>=2,
  dM>=1, dM>=2, dM>=3), instead of 26 x L steps per thread.
- **Loop-test cache (V5)** - one thread handles all 26 right-ring values of a state; the loop test only depends on
  the step counts at the walk's edge positions, and because the masks are monotone, popcount(mask & W) per mask is an
  exact key. Most loop tests are reused (biggest win: 18-letter cribs 821 -> 3,124 units/s).
- **Q cache (V5)** - the left+middle+reflector table does not depend on the right rotor; cached across units/cribs.

## Error tolerance ("perfection engine", `byg-perfekt.js`)

A garbled letter INSIDE the bombe window hides the key. For the hypotheses we believe most, the engine does a
coverage audit of everything already run (strict vs. tolerant runs, masked variants) and greedily adds variants with
1-2 masked blocks ('?') until single and double reception errors are covered (typ. 88-95 % at 3 % errors/letter).
A '?' covers all 26 letters at once, which is far cheaper than enumerating Morse neighbours.

## Self-test (`sky/selvtest.js`)

Daily: random M4 key, artificial 72-letter message, run through the real pipeline: clean crib, a garbled letter in the
crib outside the window, a garbled letter in the message + masked crib, and a short 14-letter crib. All must give
"MULIG LØSNING" (possible solution) with >= 68/72 letters right. `sky/maal-korte.js` did 8/8 for 13-18-letter cribs.

## Files

| file | what |
|---|---|
| `enigma.js` | M3/M4 machine (verified against real messages) |
| `solver.js` | CPU bombe/finisher, `menuInfo` (menu strength), plugboard hillclimb |
| `ui.js` | local server: builds GPU jobs (window choice), runs the CPU finisher, logs |
| `web/gpu-kerne.js`, `-v3`, `-v4`, `-v5` | WGSL kernels (V1 reference ... V5 current) + host code |
| `sky/gpu-node.js`, `sky/koer.js` | headless runner (queue file -> GPU -> CPU -> log) |
| `sky/test-v5.js`, `sky/bench-v5.js` | bit-identity test and benchmark |
| `byg-perfekt.js`, `perfekt-hypoteser.txt` | error-coverage engine and its hypothesis list |
| `u534.txt` | P1030680 ciphertext (letter 68 C/L uncertain - always masked) |
| `u534_corpus.json` | Hörenberg's U-534 messages (public), used for tests and statistics |

Questions welcome. I'd be very interested in how HELUT's deletion/garble branches work - indels are something this
setup does not handle at all.

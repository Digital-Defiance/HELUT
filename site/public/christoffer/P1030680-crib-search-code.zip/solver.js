'use strict';
// Knækker for Enigma M3 og M4 med plugboard.
//
// Metode:
//  1) BOMBE MED DIAGONALBRÆT. Kriben giver ligningen  S(c_i) = P_i(S(p_i)).
//     Vi gætter rotorstillingen (ikke plugboardet), så P_i er kendt. Så gætter
//     vi ÉT plugboard-led, propagerer gennem menuen, og dør gættet i en
//     modstrid, forkastes hele klassen af plugboards på én gang. Ca. 0,1 %
//     af rotorstillingerne overlever — og de kommer med en del af
//     plugboardet allerede løst.
//  2) HILLCLIMB. De plugboard-par kriben ikke rører findes med
//     trigram-statistikker, med bonus for hvert krib-bogstav der rammer.
//
// M4 håndteres som M3 med en sammensat reflektor (græskerhjulet står stille),
// så bomben er den samme. Prisen er at græskerhjulets type og stilling bliver
// ekstra ubekendte: 2 hjul × 26 stillinger × 2 tynde reflektorer = 104
// reflektorvarianter mod M3's 2.

const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const os = require('os');
const path = require('path');
const fs = require('fs');
const E = require('./enigma.js');
const { A, F, B, HAK, REFT } = E;

// Menugraf: vælg det bogstav der giver stærkest propagering
function menuInfo(krib, ct, L) {
  const grad = new Array(26).fill(0);
  const nabo = Array.from({ length: 26 }, () => []);
  let kanter = 0;
  for (let i = 0; i < L; i++) {
    if (krib[i] === '?') continue;        // ukendt bogstav binder ingenting
    const p = krib.charCodeAt(i) - 65, c = ct.charCodeAt(i) - 65;
    grad[p]++; grad[c]++; nabo[p].push(c); nabo[c].push(p); kanter++;
  }
  const mark = new Array(26).fill(-1);
  const komp = [];
  for (let s = 0; s < 26; s++) {
    if (grad[s] === 0 || mark[s] >= 0) continue;
    const q = [s], m = [s]; mark[s] = komp.length;
    while (q.length) {
      const v = q.pop();
      for (const w of nabo[v]) if (mark[w] < 0) { mark[w] = komp.length; m.push(w); q.push(w); }
    }
    komp.push(m);
  }
  komp.sort((a, b) => b.length - a.length);
  const stor = komp[0] || [0];
  // Bomben propagerer kun fra froeen og rammer derfor kun froeens komponent.
  // Loekker andre steder i menuen hjaelper ikke. Maalt 2026-09-24: en krib med
  // 2 loekker, men kun 6 kanter i froeens komponent, gav over 27 mio. stop.
  // Vaelg derfor komponenten med flest loekker (saa flest kanter).
  const kIdx = new Array(26).fill(-1); komp.forEach((c, i) => c.forEach(v => kIdx[v] = i));
  const kKant = new Array(komp.length).fill(0);
  for (let i = 0; i < L; i++) { if (krib[i] === '?') continue; kKant[kIdx[krib.charCodeAt(i) - 65]]++; }
  let bi = 0;
  for (let i = 1; i < komp.length; i++) {
    const li = kKant[i] - komp[i].length + 1, lb = kKant[bi] - komp[bi].length + 1;
    if (li > lb || (li === lb && kKant[i] > kKant[bi])) bi = i;
  }
  const valgt = komp[bi] || [0];
  let frø = valgt[0];
  for (const v of valgt) if (grad[v] > grad[frø]) frø = v;
  const knuder = komp.reduce((a, c) => a + c.length, 0);
  return { frø, komponenter: komp.length, største: stor.length, løkker: kanter - knuder + komp.length, knuder,
           frøKanter: kKant[bi] || 0, frøLøkker: komp.length ? kKant[bi] - valgt.length + 1 : 0 };
}

// Bomben kan kun håndtere ét midterrotor-step inde i sit vindue, så vinduet
// holdes på højst 13 bogstaver. Af en lang krib vælger vi det vindue der giver
// flest løkker — resten af kriben bruges bagefter som eftercheck, og dræber
// praktisk talt alle falske positiver.
function vælgVindue(krib, ct, D, maksL) {
  let L = Math.min(maksL || 13, krib.length);
  let bedst = null;
  // Har kriben et ukendt bogstav, skrumper vi vinduet indtil der findes et
  // der ikke rammer det. Saa ser bomben aldrig hullet.
  if (krib.includes('?')) {
    while (L > 3) {
      let fri = false;
      for (let w = 0; w + L <= krib.length; w++)
        if (!krib.slice(w, w + L).includes('?')) { fri = true; break; }
      if (fri) break;
      L--;
    }
  }
  for (let w = 0; w + L <= krib.length; w++) {
    if (krib.slice(w, w + L).includes('?')) continue;
    const m = menuInfo(krib.slice(w), ct.slice(D + w), L);
    if (!bedst || m.løkker > bedst.m.løkker ||
      (m.løkker === bedst.m.løkker && m.største > bedst.m.største)) bedst = { w, L, m };
  }
  return bedst;
}

// Byg listen af arbejdsenheder (rotorrækkefølge × reflektorvariant).
// Er der givet en eksplicit liste (fx de enheder GPU'en har peget på),
// bruges den i stedet.
function byggEnheder(o) {
  if (o.enheder && o.enheder.length)
    return { enheder: o.enheder, ordner: o.enheder.length, varianter: 1 };
  const rotorer = o.rotorer && o.rotorer.length >= 3
    ? o.rotorer : (o.model === 'M4' ? E.M4_ROTORER : E.M3_ROTORER);
  const ordner = [];
  for (const a of rotorer) for (const b of rotorer) for (const c of rotorer)
    if (a !== b && b !== c && a !== c) ordner.push([a, b, c]);

  const varianter = [];
  if (o.model === 'M4') {
    for (const refl of (o.reflektorer && o.reflektorer.length ? o.reflektorer : ['Bt', 'Ct']))
      for (const g of (o.græske && o.græske.length ? o.græske : E.GRÆSKE))
        for (const gp of (o.græskPositioner && o.græskPositioner.length
          ? o.græskPositioner : [...Array(26).keys()]))
          varianter.push({ refl, græsk: g, græskPos: gp });
  } else {
    for (const refl of (o.reflektorer && o.reflektorer.length ? o.reflektorer : ['B', 'C']))
      varianter.push({ refl });
  }

  const enheder = [];
  for (const v of varianter) for (const rot of ordner) enheder.push({ rot, ...v });
  return { enheder, ordner: ordner.length, varianter: varianter.length };
}

// Groft tidsskøn (kalibreret på en i9-10850K, 20 kerner)
function vurderTid(antalEnheder, længde, kerner) {
  const kernesekPrEnhed = 2.5 + 0.066 * Math.max(40, længde);
  return antalEnheder * kernesekPrEnhed / Math.max(1, kerner);
}

// ---------------------------------------------------------------- WORKER ---
if (!isMainThread) {
  // KRIB = hele kriben. D = dens plads i beskeden (0-baseret).
  // W = hvor bombens vindue begynder i beskeden, L = vinduets længde.
  // Bomben kører på vinduet; resten af kriben bruges som eftercheck.
  const { CT, KRIB, sprogfil, frø, L, W, D } = workerData;
  const ct = new Uint8Array(CT.length);
  for (let i = 0; i < CT.length; i++) ct[i] = CT.charCodeAt(i) - 65;
  const N = ct.length;
  const kribFuld = new Uint8Array(KRIB.length);
  const UKENDT = 99;                     // markerer et bogstav vi ikke stoler paa
  for (let i = 0; i < KRIB.length; i++)
    kribFuld[i] = KRIB[i] === '?' ? UKENDT : KRIB.charCodeAt(i) - 65;
  const KL = kribFuld.length;
  let KLægte = 0;
  for (let i = 0; i < KL; i++) if (kribFuld[i] !== UKENDT) KLægte++;
  // Efterchecket kræver ikke HELE kriben: hillclimb'et kan mangle en enkelt
  // ledning, og så fejler nogle få krib-bogstaver selv ved den rigtige nøgle.
  // Tål altid mindst ét forkert krib-bogstav: ved kribs på 12-13 bogstaver er
  // vinduet L hele kriben, og så krævede KRAV før ALLE bogstaver (påpeget af DeepSeek).
  const KRAV = Math.min(Math.max(L, Math.round(KLægte * 0.8)), KLægte - 1);
  // Kriegsmarine brugte 10 plugpar (alle tre dagsnøgler i korpusset har præcis 10).
  const MAKS_PAR = 10;
  // Bedste 20-bogstavs strækning af tysk UDEN FOR kriben, gennemsnit pr. trigram.
  // Kalibreret 24/9: rigtig nøgle -6,6..-6,9 (også med et udfaldent bogstav efter
  // bogstav ~36), falske fund -9,2..-11,8, tilfældig tekst bedst -8,7.
  const VINDUE = 20;
  // Kun til kalibrering/test: ENIGMA_TOPK hæver loftet, så ALLE kandidater kan ses.
  // (Omjustering ved udfald blev afprøvet 24/9 og fjernet igen: den reddede ikke den
  // rigtige nøgle ved tidlige udfald - klatringen er da allerede ført vild - men gav
  // falske kandidater ca. 100 point ekstra. Se solver.js.med-omjustering.)
  const TOPK = +process.env.ENIGMA_TOPK || 40;
  const cr = [], cic = [];
  for (let i = 0; i < L; i++) { cr.push(kribFuld[W - D + i]); cic.push(ct[W + i]); }
  const tri = new Float32Array(fs.readFileSync(sprogfil).buffer.slice(0));
  const dec = new Uint8Array(N);
  const BONUS = 18;

  function score(P, plug) {
    for (let i = 0; i < N; i++) dec[i] = plug[P[i][plug[ct[i]]]];
    let s = 0, idx = dec[0] * 26 + dec[1];
    for (let i = 2; i < N; i++) { idx = (idx % 676) * 26 + dec[i]; s += tri[idx]; }
    for (let i = 0; i < KL; i++) if (dec[D + i] === kribFuld[i]) s += BONUS;
    return s;
  }
  // Efterchecket: HELE kriben skal ramme, ikke kun bombens vindue
  function kribTræf(P, plug) {
    let n = 0;
    for (let i = 0; i < KL; i++) if (plug[P[D + i][plug[ct[D + i]]]] === kribFuld[i]) n++;
    return n;
  }

  const plug = new Int8Array(26), tmp = new Int8Array(26);
  function sæt(cfg, a, b, pa, pb) {
    plug[a] = a; plug[b] = b; plug[pa] = pa; plug[pb] = pb;
    if (cfg === 0) { plug[a] = b; plug[b] = a; if (pa !== a && pb !== b && pa !== b) { plug[pa] = pb; plug[pb] = pa; } }
    else if (cfg === 1) { if (pb !== b) { plug[a] = pb; plug[pb] = a; } if (pa !== a) { plug[b] = pa; plug[pa] = b; } }
    else if (cfg === 3) { plug[a] = b; plug[b] = a; }
  }
  function klatr(P, as) {
    for (let j = 0; j < 26; j++) plug[j] = as[j] >= 0 ? as[j] : j;
    const fri = [], erFri = new Uint8Array(26);
    for (let j = 0; j < 26; j++) if (as[j] < 0) { fri.push(j); erFri[j] = 1; }
    let bedst = score(P, plug), forbedret = true, runder = 0;
    while (forbedret && runder < 6) {
      forbedret = false; runder++;
      for (let x = 0; x < fri.length; x++) {
        const a = fri[x];
        for (let y = x + 1; y < fri.length; y++) {
          const b = fri[y], pa = plug[a], pb = plug[b];
          if (pa === b || !erFri[pa] || !erFri[pb]) continue;
          tmp.set(plug);
          let bs = bedst, bc = -1;
          for (const cfg of [0, 1, 2, 3]) {
            sæt(cfg, a, b, pa, pb);
            let np = 0; for (let j = 0; j < 26; j++) if (plug[j] !== j) np++;
            if (np / 2 > MAKS_PAR) { plug.set(tmp); continue; }
            const s = score(P, plug);
            if (s > bs) { bs = s; bc = cfg; }
            plug.set(tmp);
          }
          if (bc >= 0) { sæt(bc, a, b, pa, pb); bedst = bs; forbedret = true; }
        }
      }
    }
    return { s: bedst, plug: Int8Array.from(plug) };
  }

  // Sammensat permutation for venstre+midt+reflektor, for alle (kL,kM)
  function byggQ(rotL, rotM, ref) {
    const Q = new Int8Array(26 * 26 * 26);
    const f0 = F[rotL], b0 = B[rotL], f1 = F[rotM], b1 = B[rotM];
    for (let kL = 0; kL < 26; kL++) for (let kM = 0; kM < 26; kM++) {
      const base = (kL * 26 + kM) * 26;
      for (let x = 0; x < 26; x++) {
        let y = (f1[(x + kM) % 26] - kM + 26) % 26;
        y = (f0[(y + kL) % 26] - kL + 26) % 26;
        y = ref[y];
        y = (b0[(y + kL) % 26] - kL + 26) % 26;
        y = (b1[(y + kM) % 26] - kM + 26) % 26;
        Q[base + x] = y;
      }
    }
    return Q;
  }

  const tildel = new Int8Array(26);
  function bombe(Pt, ud) {
    let n = 0;
    for (let h = 0; h < 26; h++) {
      tildel.fill(-1); tildel[frø] = h; tildel[h] = frø;
      let ok = true, ændret = true;
      while (ændret && ok) {
        ændret = false;
        for (let i = 0; i < L; i++) {
          const p = cr[i], c = cic[i], P = Pt[i];
          let a = tildel[p];
          if (a !== -1) {
            const v = P[a];
            if (tildel[c] === -1) { if (tildel[v] !== -1) { ok = false; break; } tildel[c] = v; tildel[v] = c; ændret = true; }
            else if (tildel[c] !== v) { ok = false; break; }
          }
          a = tildel[c];
          if (a !== -1) {
            const v = P[a];
            if (tildel[p] === -1) { if (tildel[v] !== -1) { ok = false; break; } tildel[p] = v; tildel[v] = p; ændret = true; }
            else if (tildel[p] !== v) { ok = false; break; }
          }
        }
      }
      if (ok) { ud.push(Int8Array.from(tildel)); n++; }
    }
    return n;
  }

  const PT = [];
  for (let dL = 0; dL < 2; dL++) {
    const a = [];
    for (let dM = 0; dM < 3; dM++) { const b = []; for (let i = 0; i < L; i++) b.push(new Int8Array(26)); a.push(b); }
    PT.push(a);
  }
  const Pt = new Array(L);

  function permsAf(rot, ringe, pos, ref) {
    const M = E.maskine(rot, ringe, pos, ref);
    const P = [];
    for (let i = 0; i < N; i++) {
      E.step(M);
      const q = new Int8Array(26);
      for (let x = 0; x < 26; x++) q[x] = E.igennem(M, x);
      P.push(q);
    }
    return P;
  }
  function stepSignatur(rot, ringe, pos, ref) {
    const M = E.maskine(rot, ringe, pos, ref);
    let s = '';
    for (let i = 0; i < N; i++) {
      const a = M.pos[0], b = M.pos[1];
      E.step(M);
      if (M.pos[0] !== a) s += 'L' + i;
      if (i < L && M.pos[1] !== b) s += 'm' + i;
    }
    return s;
  }

  // Hvilke tegn i kriben stepper midterrotoren, givet højre ringstilling?
  // Klarer både ét og to hak (rotor VI/VII/VIII).
  function stepIndeks(kR, rr, hakR, ud) {
    ud.length = 0;
    for (let i = 1; i <= L; i++) {
      const vindue = ((kR + rr + i - 2) % 26 + 26) % 26;
      if (hakR.indexOf(vindue) >= 0) ud.push(i);
    }
    return ud;
  }

  // Find de startpositioner der efter W+1 step giver de ønskede offsets.
  // Baglæns stepping duer ikke: 650 tilstande har to forgængere på grund af
  // dobbeltsteppet. Så vi regner forlæns og efterprøver.
  const startBuf = [];
  function findStarts(rot, ringe, kL, kM, kR, ref, Wx) {
    startBuf.length = 0;
    const Wv = Wx === undefined ? W : Wx;
    const pr = ((kR + ringe[2] - (Wv + 1)) % 26 + 26) % 26;
    // Maalt: ved W=45 kan midterrotoren have steppet 5 gange, ved W=55 seks.
    // Graensen var 4 og tabte gyldige starttilstande for sene kribs.
    for (let dm = 0; dm <= 8; dm++) for (let dl = 0; dl <= 3; dl++) {
      const pl = ((kL + ringe[0] - dl) % 26 + 26) % 26;
      const pm = ((kM + ringe[1] - dm) % 26 + 26) % 26;
      const M = E.maskine(rot, ringe, [pl, pm, pr], ref);
      for (let i = 0; i <= Wv; i++) E.step(M);
      if (((M.pos[0] - ringe[0] + 26) % 26) === kL &&
          ((M.pos[1] - ringe[1] + 26) % 26) === kM &&
          ((M.pos[2] - ringe[2] + 26) % 26) === kR) startBuf.push([pl, pm, pr]);
    }
    return startBuf;
  }

  // Når maskinen først er konkret, kender vi P_i for HELE beskeden — ikke kun
  // bombens vindue. Så kan krib-ligningen S(c_i) = P_i(S(p_i)) propageres over
  // hele kriben og binde langt flere ledninger, end vinduet alene kunne.
  // Giver den modstrid, er kandidaten død med det samme.
  const udvid = new Int8Array(26);
  // spring = én krib-plads hvis ligning udelades (hørefejl uden for bombens vindue, Astra 6 30/9).
  function udvidMedKrib(P, as, spring = -1) {
    udvid.set(as);
    let ændret = true;
    while (ændret) {
      ændret = false;
      for (let i = 0; i < KL; i++) {
        if (kribFuld[i] === UKENDT || i === spring) continue;
        const p = kribFuld[i], c = ct[D + i], Pi = P[D + i];
        let a = udvid[p];
        if (a !== -1) {
          const v = Pi[a];
          if (udvid[c] === -1) { if (udvid[v] !== -1) return null; udvid[c] = v; udvid[v] = c; ændret = true; }
          else if (udvid[c] !== v) return null;
        }
        a = udvid[c];
        if (a !== -1) {
          const v = Pi[a];
          if (udvid[p] === -1) { if (udvid[v] !== -1) return null; udvid[p] = v; udvid[v] = p; ændret = true; }
          else if (udvid[p] !== v) return null;
        }
      }
    }
    return udvid;
  }

  // --- GPU-stop behandlet direkte -------------------------------------------
  // GPU'en gemmer (kL,kM,kR) = offsets ved kribbens foerste bogstav, hoejre ring
  // rr, medloebsmoenstret (ml,m1,m2) og plug-gaettet h for froe. Midterringen
  // gemmes ikke, men den kan genfindes: kun de rm der giver samme moenster, passer.
  // Samme regler som shaderen - se web/gpu-kerne.js.
  function maskerPasser(kM, rm, kR, rr, hakM, hakR, Lg, ml, m1, m2) {
    let pm = (kM + rm) % 26, pr = (kR + rr) % 26, dl = 0, dm = 0, a = 0, b = 0, c = 0;
    for (let i = 1; i < Lg; i++) {
      if (hakM.indexOf(pm) >= 0) { pm = (pm + 1) % 26; dm++; dl++; }
      else if (hakR.indexOf(pr) >= 0) { pm = (pm + 1) % 26; dm++; }
      pr = (pr + 1) % 26;
      if (dl >= 1) a |= (1 << i);
      if (dm >= 1) b |= (1 << i);
      if (dm >= 2) c |= (1 << i);
    }
    return (a >>> 0) === (ml >>> 0) && (b >>> 0) === (m1 >>> 0) && (c >>> 0) === (m2 >>> 0);
  }
  // To maskiner med samme offsets ved kriben og samme trin gennem HELE beskeden
  // er den samme maskine. (stepSignatur ser kun paa midtertrin inde i vinduet.)
  function fuldSignatur(rot, ringe, pos, ref) {
    const M = E.maskine(rot, ringe, pos, ref);
    let s = '';
    for (let i = 0; i < N; i++) {
      const a = M.pos[0], b = M.pos[1];
      E.step(M);
      if (M.pos[0] !== a) s += 'L' + i;
      if (M.pos[1] !== b) s += 'm' + i;
    }
    return s;
  }

  function vinduesScore(P, plugs) {
    score(P, plugs);                           // fylder dec med dekrypteringen
    let best = -Infinity;
    for (let a = 0; a + VINDUE <= N; a++) {
      // aldrig oven i et KENDT krib-bogstav (huller i en todelt krib er fri tekst)
      let røres = false;
      for (let i = Math.max(a, D); i < Math.min(a + VINDUE, D + KL); i++) if (kribFuld[i - D] !== UKENDT) { røres = true; break; }
      if (røres) continue;
      let s = 0;
      for (let i = a + 2; i < a + VINDUE; i++) s += tri[(dec[i - 2] * 26 + dec[i - 1]) * 26 + dec[i]];
      if (s > best) best = s;
    }
    return best / (VINDUE - 2);
  }

  let bedste = [], tysk = [], fundneDenneEnhed = 0, enhedMeta = null;
  // Kandidater med en tysk strækning beholdes, selv om deres samlede score er lav
  // (et udfaldent bogstav kan trække den rigtige nøgles samlede score ned).
  const udtag = () => bedste.splice(0).concat(tysk.splice(0));
  // Bombens vindue for den igangværende opgave (GPU-stop: Wg/Lg, CPU-bombe: W/L).
  let bombeW = W, bombeL = L;
  function overvej(rot, ringe, pos, ref, as) {
    const P = permsAf(rot, ringe, pos, ref);
    const rigere = udvidMedKrib(P, as);
    if (rigere) return behandl(rot, ringe, pos, P, rigere);
    // 30/9 (Astra 6, reproduceret): ét fejlhørt cifferbogstav i kriben UDEN FOR bombens vindue gav
    // modstrid her, så den rigtige nøgle døde før reglen om højst 1 kribfejl. Prøv derfor igen med
    // præcis én ligning udeladt - kun pladser uden for vinduet (inde i vinduet har bomben allerede
    // krævet dem opfyldt). Højst én udeladelse = samme fejlbudget som fundreglen.
    for (let i = 0; i < KL; i++) {
      if (kribFuld[i] === UKENDT) continue;
      const m = D + i; if (m >= bombeW && m < bombeW + bombeL) continue;
      const r = udvidMedKrib(P, as, i);
      if (r) behandl(rot, ringe, pos, P, Int8Array.from(r));
    }
  }
  function behandl(rot, ringe, pos, P, rigere) {
    let par = 0; for (let j = 0; j < 26; j++) if (rigere[j] >= 0 && rigere[j] !== j) par++;
    if (par / 2 > MAKS_PAR) return;            // kriben alene tvinger flere end 10 plugpar
    const r = klatr(P, rigere);
    if (kribTræf(P, r.plug) < KRAV) return;
    fundneDenneEnhed++;
    const v = vinduesScore(P, r.plug);
    const post = { s: r.s, vindue: v, rot, ringe, pos: pos.slice(), ...enhedMeta, plug: Array.from(r.plug) };
    if (bedste.length < TOPK || r.s > bedste[bedste.length - 1].s) {
      bedste.push(post);
      bedste.sort((a, b) => b.s - a.s);
      if (bedste.length > TOPK) bedste.length = TOPK;
    }
    // De 40 med bedste tyske strækning beholdes altid (grænsen afhænger af sprogmodellen og
    // bestemmes i siden). Før 24/9 aften: kun dem over VINDUE_GRÆNSE.
    if (tysk.length < 40 || v > tysk[tysk.length - 1].vindue) {
      tysk.push(post);
      tysk.sort((a, b) => b.vindue - a.vindue);
      if (tysk.length > 40) tysk.length = 40;
    }
  }

  parentPort.on('message', enhed => {
    if (enhed === null) { parentPort.postMessage({ resultat: udtag(), sidste: true }); process.exit(0); }
    if (enhed.stopBatch) {                      // GPU har allerede kort bomben
      const u = enhed.enhed;
      const ref = u.græsk ? E.sammensatReflektor(u.græsk, u.græskPos, u.refl) : REFT[u.refl];
      enhedMeta = u.græsk ? { refl: u.refl, græsk: u.græsk, græskPos: u.græskPos } : { refl: u.refl };
      bombeW = enhed.Wg; bombeL = enhed.Lg;
      const hakM = HAK[u.rot[1]], hakR = HAK[u.rot[2]];
      fundneDenneEnhed = 0;
      const set = new Set();
      for (const [kL, kM, kR, rr, ml, m1, m2, h] of enhed.stops) {
        const as = new Int8Array(26).fill(-1);
        as[enhed.frøG] = h; as[h] = enhed.frøG;
        for (let rm = 0; rm < 26; rm++) {
          if (!maskerPasser(kM, rm, kR, rr, hakM, hakR, enhed.Lg, ml, m1, m2)) continue;
          const ringe = [0, rm, rr];
          const starter = findStarts(u.rot, ringe, kL, kM, kR, ref, enhed.Wg).map(x => x.slice());
          for (const pos of starter) {
            const sg = kL + ',' + kM + ',' + kR + ',' + h + '|' + fuldSignatur(u.rot, ringe, pos, ref);
            if (set.has(sg)) continue;
            set.add(sg);
            overvej(u.rot, ringe, pos, ref, as);
          }
        }
      }
      parentPort.postMessage({ tik: 1, fundne: fundneDenneEnhed });
      parentPort.postMessage({ resultat: udtag(), fundne: fundneDenneEnhed });
      return;
    }
    const [rl, rm, rr_] = enhed.rot;
    const ref = enhed.græsk
      ? E.sammensatReflektor(enhed.græsk, enhed.græskPos, enhed.refl)
      : REFT[enhed.refl];
    enhedMeta = enhed.græsk
      ? { refl: enhed.refl, græsk: enhed.græsk, græskPos: enhed.græskPos }
      : { refl: enhed.refl };
    const Q = byggQ(rl, rm, ref);
    const f2 = F[rr_], b2 = B[rr_], hakR = HAK[rr_], hakM = HAK[rm];
    fundneDenneEnhed = 0;
    const si = [];

    for (let kL = 0; kL < 26; kL++) {
      for (let kM = 0; kM < 26; kM++) {
        // Meld undervejs, så fremdriften er jævn fra første sekund
        parentPort.postMessage({ tik: 1, fundne: fundneDenneEnhed });
        for (let kR = 0; kR < 26; kR++) {
          for (let dL = 0; dL < 2; dL++) for (let dM = 0; dM < 3; dM++) {
            const qb = (((kL + dL) % 26) * 26 + ((kM + dM) % 26)) * 26;
            for (let i = 0; i < L; i++) {
              const k = (kR + i) % 26, P = PT[dL][dM][i];
              for (let x = 0; x < 26; x++) {
                const y = (f2[(x + k) % 26] - k + 26) % 26;
                P[x] = (b2[(Q[qb + y] + k) % 26] - k + 26) % 26;
              }
            }
          }

          // A) venstre rotor står stille under kriben
          //    t = hvornår midterrotoren stepper (0 = aldrig)
          for (let t = 0; t <= L; t++) {
            for (let i = 0; i < L; i++) Pt[i] = PT[0][(t > 0 && i >= t - 1) ? 1 : 0][i];
            const ud = [];
            if (!bombe(Pt, ud)) continue;
            for (let rr = 0; rr < 26; rr++) {
              stepIndeks(kR, rr, hakR, si);
              const passer = t === 0 ? si.length === 0 : (si.length === 1 && si[0] === t);
              if (!passer) continue;
              for (const as of ud) {
                const set = new Set();
                for (let rmg = 0; rmg < 26; rmg++) {
                  const ringe = [0, rmg, rr];
                  for (const pos of findStarts(enhed.rot, ringe, kL, kM, kR, ref)) {
                    const sg = stepSignatur(enhed.rot, ringe, pos, ref);
                    if (set.has(sg)) continue;
                    set.add(sg);
                    overvej(enhed.rot, ringe, pos, ref, as);
                  }
                }
              }
            }
          }

          // B) venstre rotor stepper inde i kriben (ved tL), evt. plus et
          //    ekstra midterstep fra højre rotors hak (ved tR)
          for (let tL = 1; tL <= L; tL++) for (let tR = 0; tR <= L; tR++) {
            if (tR === tL) continue;
            for (let i = 0; i < L; i++) {
              const ch = i + 1;
              Pt[i] = PT[ch >= tL ? 1 : 0][(ch >= tL ? 1 : 0) + ((tR > 0 && ch >= tR) ? 1 : 0)][i];
            }
            const ud = [];
            if (!bombe(Pt, ud)) continue;
            for (let rr = 0; rr < 26; rr++) {
              stepIndeks(kR, rr, hakR, si);
              const passer = tR === 0
                ? si.every(x => x === tL)
                : (si.length === 1 && si[0] === tR);
              if (!passer) continue;
              const ekstra = (tR > 0 && tR < tL) ? 1 : 0;
              for (const hak of hakM) {
                const rmg = ((hak - kM - ekstra) % 26 + 26) % 26;
                const ringe = [0, rmg, rr];
                for (const pos of findStarts(enhed.rot, ringe, kL, kM, kR, ref))
                  for (const as of ud) overvej(enhed.rot, ringe, pos, ref, as);
              }
            }
          }
        }
      }
    }
    parentPort.postMessage({ resultat: udtag(), fundne: fundneDenneEnhed });
  });

  parentPort.postMessage({ klar: true });

// ------------------------------------------------------------------ MAIN ---
} else {
  function solve(opt) {
    const CT = E.rens(opt.ciffertekst);
    let KRIB = E.rensKrib(opt.krib);             // '?' = ukendt/hul (28/9)
    const D = Math.max(0, opt.kribPlads | 0);     // krib-plads i beskeden, 0-baseret
    const sprogfil = opt.sprogfil || path.join(__dirname, 'tysk.bin');

    if (!CT) throw new Error('Ingen ciffertekst.');
    if (KRIB.length < 4) throw new Error('Kriben skal være mindst 4 bogstaver.');
    if (D + KRIB.length > CT.length) throw new Error(
      `Kriben går ud over beskeden: plads ${D + 1} + ${KRIB.length} bogstaver > ${CT.length}.`);
    // Enigma krypterer aldrig et bogstav til sig selv. Men telegrafisten kan
    // have hørt forkert: ÉN kollision er langt mere sandsynligt en
    // afskrivningsfejl end et bevis på at kriben er forkert. Den markeres som
    // ukendt i stedet for at hele hypotesen kasseres. To eller flere er
    // derimod for meget til at være et uheld.
    const kollisioner = [];
    for (let i = 0; i < KRIB.length; i++) if (KRIB[i] === CT[D + i]) kollisioner.push(i);
    if (kollisioner.length > 1) {
      const e = new Error(
        `Kriben kan ikke passe: ${kollisioner.length} bogstaver er identiske med cifferteksten ` +
        `(plads ${kollisioner.map(i => D + i + 1).join(', ')}). Enigma kan aldrig kryptere et ` +
        `bogstav til sig selv, og mere end én kollision er ikke en afskrivningsfejl.`);
      e.umuligt = true;
      throw e;
    }
    if (kollisioner.length === 1) {
      const i = kollisioner[0];
      KRIB = KRIB.slice(0, i) + '?' + KRIB.slice(i + 1);
    }

    let vindue = vælgVindue(KRIB, CT, D, 13);
    // 30/9 (Astra 6): en krib med spredte '?' har intet sammenhængende CPU-vindue. I GPU-stop-tilstand
    // er CPU-bomben ikke i brug, så GPU'ens eget vindue bruges til bogføring (KRAV, menu).
    if (!vindue && Array.isArray(opt.gpuStop) && opt.gpuL) {
      const w = (opt.gpuW === undefined ? D : opt.gpuW) - D;
      vindue = { L: opt.gpuL, w, m: menuInfo(KRIB.slice(w), CT.slice(D + w), opt.gpuL) };
    }
    if (!vindue) throw new Error('Kriben har intet brugbart vindue (for mange ?).');
    const L = vindue.L, W = D + vindue.w;
    const menu = vindue.m;
    const { enheder: alleEnheder } = byggEnheder(opt);
    // GPU-stop: hver opgave er en portion stop fra een enhed. Ellers hele enheder.
    // Et tomt stop-saet betyder at GPU'en har udelukket alt - IKKE at CPU'en skal
    // scanne det hele selv. Det var en fejl der kunne starte timers unoedigt arbejde.
    const stopTilstand = Array.isArray(opt.gpuStop);
    const enheder = stopTilstand
      ? opt.gpuStop.map(b => ({ stopBatch: true, enhed: b.enhed, stops: b.stops, Wg: (opt.gpuW === undefined ? D : opt.gpuW), Lg: opt.gpuL, frøG: opt.gpuFrø }))
      : alleEnheder;
    if (stopTilstand && enheder.length === 0) return Promise.resolve({
      resultater: [], fundneIalt: 0, sekunder: 0, menu, ciffertekst: CT, krib: KRIB, L, afbrudt: false, enheder: 0 });
    const nw = Math.max(1, Math.min(opt.kerner || (os.cpus().length - 1), 32, enheder.length));
    const t0 = Date.now();
    const alle = [];
    const workers = [];
    let næste = 0, levende = nw, afbrudt = false;
    let tik = 0, fundneAfsluttede = 0, sidsteMelding = 0;
    const TIK_PR_ENHED = stopTilstand ? 1 : 26 * 26;
    const tikIalt = enheder.length * TIK_PR_ENHED;
    const iGang = new Map();
    const meld = () => {
      let n = fundneAfsluttede;
      for (const v of iGang.values()) n += v;
      if (opt.påProgress) opt.påProgress(tik, tikIalt, (Date.now() - t0) / 1000, n);
    };

    if (opt.påStart) opt.påStart({
      kerner: nw, enheder: enheder.length, menu,
      vindue: { plads: D + 1, vindueStart: W + 1, længde: L, løkker: menu.løkker },
      skøn: vurderTid(enheder.length, CT.length, nw),
      stop() { afbrudt = true; for (const w of workers) w.terminate(); },
    });

    return new Promise((resolve, reject) => {
      for (let w = 0; w < nw; w++) {
        let wk;
        try {
          wk = new Worker(__filename, { workerData: { CT, KRIB, sprogfil, frø: menu.frø, L, W, D } });
        } catch (e) { return reject(e); }
        workers.push(wk);
        wk.on('error', reject);
        wk.on('message', m => {
          if (m.tik) {
            tik += m.tik;
            iGang.set(wk, m.fundne || 0);
            const nu = Date.now();
            if (nu - sidsteMelding > 250) { sidsteMelding = nu; meld(); }
            return;
          }
          if (m.resultat) {
            alle.push(...m.resultat);
            if (!m.sidste) {
              fundneAfsluttede += m.fundne || 0;
              iGang.set(wk, 0);
              meld();
            }
          }
          if (afbrudt) { wk.postMessage(null); return; }
          if (næste < enheder.length) wk.postMessage(enheder[næste++]); else wk.postMessage(null);
        });
        wk.on('exit', () => {
          if (--levende === 0) {
            alle.sort((a, b) => b.s - a.s);
            let fundneIalt = fundneAfsluttede;
            for (const v of iGang.values()) fundneIalt += v;
            resolve({
              resultater: alle, fundneIalt, sekunder: (Date.now() - t0) / 1000,
              menu, ciffertekst: CT, krib: KRIB, L, afbrudt, enheder: enheder.length,
            });
          }
        });
      }
    });
  }

  module.exports = { solve, menuInfo, byggEnheder, vurderTid, vælgVindue };
}

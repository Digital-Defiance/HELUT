'use strict';
// GPU-bomben, VERSION 4 (4/10) = V3 + TURINGS LØKKE-TEST foran hypotese-løkken.
//   løkke-test   : hver lukket vandring i menuen gennem test-bogstavet (frø) giver en permutation Π
//                  (sammensat af Enigma-permutationerne langs vandringen). Den rigtige stecker h for frø
//                  SKAL være et fixpunkt: Π(h) = h - ellers giver propageringen modstrid i den kant der lukker
//                  løkken. Så kun fixpunkterne (i snit ~1 af 26) propageres fuldt. Samme stop som V3, mindre arbejde.
//                  Vandringerne findes på CPU'en (løkkeVandringer) og ligger i kribdata[160..223].
// --- herunder: V3's oprindelige beskrivelse ---
// GPU-bomben, VERSION 3 (29/9) — samme søgning som V1/V2, med mindre arbejde pr. hypotese.
//   arbejdsliste : i stedet for at feje HELE kriben igennem igen og igen, efterses kun de
//                  krib-kanter der rører et bogstav som lige har fået en værdi ('uro'-bitmaske).
//                  Fixpunktet - og dermed stop/ikke-stop - er det samme; kun arbejdet er mindre.
//   splitRR      : én tråd pr. (rotorposition, højre-ring) i stedet for pr. rotorposition,
//                  så trådene i et hold bliver færdige mere samtidig (mindre ventetid).
// Bygger på V2 (Q fra cache, fordoblede rotortabeller, f2/b2 i delt hukommelse).
// Output er BIT-IDENTISK med V1 - testet i web/test-v3.html.

// Målt 29/9 på RTX 5070 (enh/s, V2 -> V3): 26 bogst 84,6 -> 143,2 · 18 bogst 111,1 -> 128,0 · 14 bogst svag 116,5 -> 132,2.
// Arbejdslisten vinder på lange krib, fejningen på korte - 'auto' vælger pr. krib (grænse: >= 20 kendte bogstaver i GPU-vinduet).
// 4/10: med løkke-testen er der næsten intet tilbage at propagere, og fejningen er hurtigst for alle længder
// (målt: 26 bogst 395 mod 370 enh/s, 18: 822 mod 762, 14: 212 mod 175).
const V4_STANDARD = { wg: 128, arbejdsliste: false, splitRR: true };
const V4_AUTO_GRÆNSE = 20;

function v4Wgsl(o) {
  const WG = o.wg;
  // (qb, k) for krib-plads i ud fra trin-maskerne
  const plads = `let dL = ((ml >> i) & 1u) + ((l2 >> i) & 1u);
            let dM = ((m1 >> i) & 1u) + ((m2 >> i) & 1u) + ((m3 >> i) & 1u);
            var a = kL + dL; if (a >= 26u) { a = a - 26u; }
            var b = kM + dM; if (b >= 26u) { b = b - 26u; }
            let qb = (a * 26u + b) * 26u;
            var k = kR + i; if (k >= 26u) { k = k - 26u; }`;
  // Samme regel for én krib-kant som i V1/V2 (se gpu-kerne.js) - kun rækkefølgen er ændret.
  const kant = (tilfoej) => `
            let p = crS[i];
            let c = ciS[i];
            ${plads}
            let rp = les(p, lid);
            if (har(rp)) {
              let v = Pval(u, qb, k, vaerdi(rp));
              let rc = les(c, lid);
              if (!har(rc)) {
                if (har(les(v, lid))) { ok = false; break; }
                skriv(c, lid, v);
                skriv(v, lid, c);
                ${tilfoej('c', 'v')}
              } else if (vaerdi(rc) != v) { ok = false; break; }
            }
            let rc2 = les(c, lid);
            if (har(rc2)) {
              let v = Pval(u, qb, k, vaerdi(rc2));
              let rp2 = les(p, lid);
              if (!har(rp2)) {
                if (har(les(v, lid))) { ok = false; break; }
                skriv(p, lid, v);
                skriv(v, lid, p);
                ${tilfoej('p', 'v')}
              } else if (vaerdi(rp2) != v) { ok = false; break; }
            }`;
  const propagering = o.arbejdsliste ? `
        // ARBEJDSLISTE: kun kanter der rører et bogstav som lige har fået en værdi.
        // 'uro' = bitmaske over bogstaver der skal efterses. Fixpunktet (og dermed stop/ikke-stop)
        // er det samme som ved gentagne fejninger - kun mængden af arbejde er mindre.
        var uro: u32 = (1u << froe) | (1u << h);
        loop {
          if (uro == 0u || !ok) { break; }
          let x = firstTrailingBit(uro);
          uro = uro & ~(1u << x);
          let a0 = adjS[x]; let a1 = adjS[x + 1u];
          for (var j: u32 = a0; j < a1; j = j + 1u) {
            let i = adjS[27u + j];
            ${kant((y, z) => `uro = uro | (1u << ${y}) | (1u << ${z});`)}
          }
        }` : `
        var aendret = true;
        while (aendret && ok) {
          aendret = false;
          for (var i: u32 = 0u; i < L; i = i + 1u) {
            if (crS[i] >= 26u) { continue; }
            ${kant(() => 'aendret = true;')}
          }
        }`;
  const hoved = o.splitRR ? `
  let t = wg.x * ${WG}u + lid;
  if (t >= 456976u) { return; }
  let r = t % 17576u;
  let rrFra = t / 17576u; let rrTil = rrFra + 1u;` : `
  let r = wg.x * ${WG}u + lid;
  if (r >= 17576u) { return; }
  let rrFra = 0u; let rrTil = 26u;`;

  return `
struct Par { L: u32, froe: u32, enheder: u32, maksStop: u32 };
@group(0) @binding(0) var<storage, read> Q    : array<u32>;
@group(0) @binding(1) var<storage, read> f2   : array<u32>;
@group(0) @binding(2) var<storage, read> b2   : array<u32>;
@group(0) @binding(3) var<storage, read> kribdata : array<u32>;   // [0..31] krib, [32..63] ciffer, [64..159] kantlister, [160..223] løkke-vandringer
@group(0) @binding(5) var<uniform>       par  : Par;
@group(0) @binding(6) var<storage, read_write> taeller : atomic<u32>;
@group(0) @binding(7) var<storage, read_write> stop : array<u32>;
@group(0) @binding(8) var<storage, read> hak  : array<u32>;

var<private> ST: u32;
var<workgroup> crS: array<u32, 32>;
var<workgroup> ciS: array<u32, 32>;
var<workgroup> adjS: array<u32, 96>;
var<workgroup> fS: array<u32, 52>;
var<workgroup> bS: array<u32, 52>;
var<workgroup> walkS: array<u32, 64>;   // [0]=antal vandringer, [1..4]=længder, [5..]=kant-pladser i rækkefølge
var<workgroup> til: array<u32, ${26 * WG}>;
fn les(x: u32, lid: u32) -> u32 { return til[x * ${WG}u + lid]; }
fn har(e: u32) -> bool { return (e & 0xFFFFFF00u) == ST; }
fn vaerdi(e: u32) -> u32 { return (e & 255u) - 1u; }
fn skriv(x: u32, lid: u32, v: u32) { til[x * ${WG}u + lid] = ST | (v + 1u); }
fn qByte(u: u32, i: u32) -> u32 { return (Q[u * 4394u + (i >> 2u)] >> ((i & 3u) * 8u)) & 255u; }
fn Pval(u: u32, qb: u32, k: u32, x: u32) -> u32 {
  var y = fS[x + k] + 26u - k; if (y >= 26u) { y = y - 26u; }
  var z = bS[qByte(u, qb + y) + k] + 26u - k; if (z >= 26u) { z = z - 26u; }
  return z;
}

@compute @workgroup_size(${WG})
fn main(@builtin(workgroup_id) wg: vec3<u32>, @builtin(local_invocation_id) li: vec3<u32>) {
  let lid = li.x;
  let u = wg.y;
  if (lid < par.L) { crS[lid] = kribdata[lid]; ciS[lid] = kribdata[32u + lid]; }
  for (var i: u32 = lid; i < 96u; i = i + ${WG}u) { adjS[i] = kribdata[64u + i]; }
  if (lid < 52u) { fS[lid] = f2[u * 52u + lid]; bS[lid] = b2[u * 52u + lid]; }
  if (lid < 64u) { walkS[lid] = kribdata[160u + lid]; }
  workgroupBarrier();
  ${hoved}
  let kL = r / 676u;
  let kM = (r / 26u) % 26u;
  let kR = r % 26u;
  let L  = par.L;
  let froe = par.froe;
  let hakM = hak[u * 2u];
  let hakR = hak[u * 2u + 1u];
  ST = 0u;

  for (var rr: u32 = rrFra; rr < rrTil; rr = rr + 1u) {
    var tagetNul = false;
    for (var rm: u32 = 0u; rm < 26u; rm = rm + 1u) {
      var pm = (kM + rm) % 26u;
      var pr = (kR + rr) % 26u;
      var dl: u32 = 0u; var dm: u32 = 0u;
      var ml: u32 = 0u; var l2: u32 = 0u;
      var m1: u32 = 0u; var m2: u32 = 0u; var m3: u32 = 0u;
      for (var i: u32 = 1u; i < L; i = i + 1u) {
        if (((hakM >> pm) & 1u) == 1u) { pm = (pm + 1u) % 26u; dm = dm + 1u; dl = dl + 1u; }
        else if (((hakR >> pr) & 1u) == 1u) { pm = (pm + 1u) % 26u; dm = dm + 1u; }
        pr = (pr + 1u) % 26u;
        if (dl >= 1u) { ml = ml | (1u << i); }
        if (dl >= 2u) { l2 = l2 | (1u << i); }
        if (dm >= 1u) { m1 = m1 | (1u << i); }
        if (dm >= 2u) { m2 = m2 | (1u << i); }
        if (dm >= 3u) { m3 = m3 | (1u << i); }
      }
      if (ml == 0u) {
        if (tagetNul) { continue; }
        tagetNul = true;
      }
      // V4 løkke-test: kun h med Π(h) = h for ALLE vandringer kan overleve propageringen.
      var levende: u32 = 0x3FFFFFFu;
      var wo: u32 = 5u;
      for (var w: u32 = 0u; w < walkS[0]; w = w + 1u) {
        let wl = walkS[1u + w];
        var ny: u32 = 0u;
        for (var h0: u32 = 0u; h0 < 26u; h0 = h0 + 1u) {
          if (((levende >> h0) & 1u) == 0u) { continue; }
          var x = h0;
          for (var j: u32 = 0u; j < wl; j = j + 1u) {
            let i = walkS[wo + j];
            ${plads}
            x = Pval(u, qb, k, x);
          }
          if (x == h0) { ny = ny | (1u << h0); }
        }
        levende = ny;
        wo = wo + wl;
        if (levende == 0u) { break; }
      }
      for (var h: u32 = 0u; h < 26u; h = h + 1u) {
        if (((levende >> h) & 1u) == 0u) { continue; }
        ST = ST + 256u;
        skriv(froe, lid, h);
        skriv(h, lid, froe);
        var ok = true;
        ${propagering}
        if (ok) {
          let n = atomicAdd(&taeller, 1u);
          if (n < par.maksStop) {
            let o = n * 9u;
            stop[o+0u]=u; stop[o+1u]=kL; stop[o+2u]=kM; stop[o+3u]=kR; stop[o+4u]=rr;
            stop[o+5u]=ml; stop[o+6u]=m1; stop[o+7u]=m2; stop[o+8u]=h;
          }
        }
      }
    }
  }
}`;
}

function v4Delt(o) { return 26 * o.wg * 4 + 2 * 32 * 4 + 96 * 4 + 2 * 52 * 4 + 64 * 4; }

// Lukkede vandringer gennem frø i menuen (kun kendte kanter i GPU-vinduet). BFS-træ fra frø; hver kant uden for
// træet giver vandringen frø->u, kanten, v->frø. Fælles stykker af de to træstier går frem og tilbage og ophæver
// hinanden (Enigma-permutationer er involutioner), så testen er lige så stærk som løkken selv.
function løkkeVandringer(cr, ci, L, frø) {
  const kanter = [];
  for (let i = 0; i < L; i++) if (cr[i] < 26) kanter.push([cr[i], ci[i], i]);
  const dist = new Array(26).fill(-1), far = new Array(26).fill(-1); // far = kant-indeks ind til bogstavet
  dist[frø] = 0; const kø = [frø];
  while (kø.length) { const x = kø.shift(); for (let e = 0; e < kanter.length; e++) { const [p, c] = kanter[e]; const y = p === x ? c : c === x ? p : -1;
    if (y >= 0 && dist[y] < 0) { dist[y] = dist[x] + 1; far[y] = e; kø.push(y); } } }
  const træ = new Set(far.filter(e => e >= 0));
  const opad = x => { const v = []; while (x !== frø) { const e = far[x]; v.push(kanter[e][2]); x = kanter[e][0] === x ? kanter[e][1] : kanter[e][0]; } return v; };
  const vandr = [];
  for (let e = 0; e < kanter.length; e++) {
    if (træ.has(e)) continue;
    const [p, c, i] = kanter[e];
    if (dist[p] < 0) continue;                       // ikke i frøs komponent
    vandr.push(opad(p).reverse().concat([i], opad(c)));
  }
  vandr.sort((a, b) => a.length - b.length);
  const ud = []; let n = 0;
  for (const v of vandr) { if (ud.length >= 4 || n + v.length > 59) break; ud.push(v); n += v.length; }
  const a = new Uint32Array(64); a[0] = ud.length; let o = 5;
  ud.forEach((v, j) => { a[1 + j] = v.length; for (const i of v) a[o++] = i; });
  return a;
}

async function gpuOpsætningV4(variant) {
  const o = { ...V4_STANDARD, ...(variant || {}) };
  if (!navigator.gpu) throw new Error('WebGPU er ikke tilgængelig i denne browser.');
  const ad = await navigator.gpu.requestAdapter({ powerPreference: 'high-performance' });
  if (!ad) throw new Error('Ingen GPU-adapter.');
  const behov = v4Delt(o) + 64;           // GPU'en runder op til justering
  if (behov > ad.limits.maxComputeWorkgroupStorageSize)
    throw new Error(`Variant ${JSON.stringify(o)} kræver ${behov} bytes delt hukommelse; GPU'en har ${ad.limits.maxComputeWorkgroupStorageSize}.`);
  const dev = await ad.requestDevice({ requiredLimits: {
    maxComputeWorkgroupStorageSize: ad.limits.maxComputeWorkgroupStorageSize,
    maxComputeInvocationsPerWorkgroup: Math.max(256, o.wg), maxComputeWorkgroupSizeX: Math.max(256, o.wg) } });
  async function lav(oo) {
    dev.pushErrorScope('validation');
    const mod = dev.createShaderModule({ code: v4Wgsl(oo) });
    const info = await mod.getCompilationInfo();
    for (const m of info.messages) if (m.type === 'error') throw new Error(`WGSL linje ${m.lineNum}: ${m.message}`);
    const pp = dev.createComputePipeline({ layout: 'auto', compute: { module: mod, entryPoint: 'main' } });
    const fejl = await dev.popErrorScope();
    if (fejl) throw new Error('pipeline: ' + fejl.message);
    return pp;
  }
  const auto = o.arbejdsliste === 'auto';
  const pipeLang = o.arbejdsliste !== false ? await lav({ ...o, arbejdsliste: true }) : null;   // arbejdsliste
  const pipeKort = o.arbejdsliste !== true ? await lav({ ...o, arbejdsliste: false }) : null;   // fejning
  return { ad, dev, pipe: pipeLang || pipeKort, pipeKort: auto ? pipeKort : null, o, navn: ((ad.info && ad.info.architecture) || 'ukendt') + ' · V4 ' + JSON.stringify(o) };
}

// Samme kontrakt som gpuScan i gpu-kerne.js (inkl. overløb pr. enhed og STOPLOFT).
async function gpuScanV4(g, job, påFremdrift, skalStoppe, maksStop, skalPause) {
  const E = window.Enigma;
  const { dev, o } = g;
  // Vælg efter antal KENDTE bogstaver i GPU-vinduet (ikke vinduets længde): en todelt krib med mange '?'
  // opfører sig som en kort krib. (Rettet 29/9: LEITUNGVO?????????EUNXUUUFLO gav 80 enh/s med arbejdslisten.)
  const kendte = job.cr.slice(0, job.L).filter(x => (x >>> 0) < 26).length;
  // 29/9 aften, målt i Node på 3 enhedsudsnit: det er VINDUETS LÆNGDE der afgør det, ikke antal kendte.
  // Todelt krib (26 m. 9 ?): arbejdsliste 108 mod fejning 84 enh/s. 14 bogst: fejning 127 mod 87. 18: lige.
  void kendte;
  const pipe = g.pipeKort && job.L < V4_AUTO_GRÆNSE ? g.pipeKort : g.pipe;
  const ST = GPUBufferUsage.STORAGE, CD = GPUBufferUsage.COPY_DST, CS = GPUBufferUsage.COPY_SRC;
  const FLOK = 16;
  const MAKS = maksStop || 60000;
  const STOPLOFT = 500000;
  let forSvag = false;
  const alleStop = [];
  const igen = [];
  let færdige = 0, mangler = 0;
  let overløb = false;
  const t0 = performance.now();
  let pausetMs = 0;
  const L = job.L;
  if (L > 26) throw new Error('V4: højst 26 bogstaver i GPU-vinduet.');

  const bCr = dev.createBuffer({ size: 128, usage: ST | CD });
  const bCi = dev.createBuffer({ size: 128, usage: ST | CD });
  const crA = new Uint32Array(32), ciA = new Uint32Array(32);
  crA.set(job.cr.map(x => x >>> 0)); ciA.set(job.cic);
  dev.queue.writeBuffer(bCr, 0, crA); dev.queue.writeBuffer(bCi, 0, ciA);
  const lister = Array.from({ length: 26 }, () => []);
  for (let i = 0; i < L; i++) { const p = crA[i], c = ciA[i]; if (p >= 26) continue; lister[p].push(i); lister[c].push(i); }
  const adjA = new Uint32Array(96); let n0 = 0;
  for (let x = 0; x < 26; x++) { adjA[x] = n0; for (const i of lister[x]) adjA[27 + n0++] = i; }
  adjA[26] = n0;
  const metaA = new Uint32Array(224); metaA.set(crA, 0); metaA.set(ciA, 32); metaA.set(adjA, 64);
  metaA.set(løkkeVandringer(crA, ciA, L, job.frø), 160);
  const bMeta = dev.createBuffer({ size: 224 * 4, usage: ST | CD });
  dev.queue.writeBuffer(bMeta, 0, metaA);

  function lavSæt() {
    const s = {
      bQ: dev.createBuffer({ size: FLOK * 4394 * 4, usage: ST | CD }),
      bF: dev.createBuffer({ size: FLOK * 52 * 4, usage: ST | CD }),
      bB: dev.createBuffer({ size: FLOK * 52 * 4, usage: ST | CD }),
      bHak: dev.createBuffer({ size: FLOK * 2 * 4, usage: ST | CD }),
      bPar: dev.createBuffer({ size: 16, usage: GPUBufferUsage.UNIFORM | CD }),
      bTal: dev.createBuffer({ size: 4, usage: ST | CS | CD }),
      bStop: dev.createBuffer({ size: MAKS * 9 * 4, usage: ST | CS }),
      lTal: dev.createBuffer({ size: 4, usage: GPUBufferUsage.MAP_READ | CD }),
      lStop: dev.createBuffer({ size: MAKS * 9 * 4, usage: GPUBufferUsage.MAP_READ | CD }),
    };
    s.bind = dev.createBindGroup({ layout: pipe.getBindGroupLayout(0),
      entries: [s.bQ, s.bF, s.bB, bMeta, s.bPar, s.bTal, s.bStop, s.bHak].map((b, i) => ({ binding: [0, 1, 2, 3, 5, 6, 7, 8][i], resource: { buffer: b } })) });
    return s;
  }
  const sæt = [lavSæt(), lavSæt(), lavSæt()];
  const ledige = sæt.slice();
  const qBuf = new Uint32Array(FLOK * 4394), fBuf = new Uint32Array(FLOK * 52), bBuf = new Uint32Array(FLOK * 52), hBuf = new Uint32Array(FLOK * 2);
  // Rotortabeller bygges én gang pr. enhed og genbruges (sparer CPU-tid i browseren)
  const qCache = new Map();
  function send(s, start, n) {
    const flok = job.enheder.slice(start, start + n);
    flok.forEach((e, u) => {
      const nøgle = start + u;
      let Qp = qCache.get(nøgle);
      if (!Qp) {
        const ref = e.græsk ? E.sammensatReflektor(e.græsk, e.græskPos, e.refl) : E.REFT[e.refl];
        const Q = gpuByggQ(e.rot[0], e.rot[1], ref);
        Qp = new Uint32Array(4394);
        for (let i = 0; i < 17576; i++) Qp[i >> 2] |= Q[i] << ((i & 3) * 8);
        if (qCache.size > 64) qCache.clear();
        qCache.set(nøgle, Qp);
      }
      qBuf.set(Qp, u * 4394);
      const f = E.F[e.rot[2]], b = E.B[e.rot[2]];
      for (let i = 0; i < 52; i++) { fBuf[u * 52 + i] = f[i % 26]; bBuf[u * 52 + i] = b[i % 26]; }
      let mM = 0; for (const h of E.HAK[e.rot[1]]) mM |= (1 << h);
      let mR = 0; for (const h of E.HAK[e.rot[2]]) mR |= (1 << h);
      hBuf[u * 2] = mM; hBuf[u * 2 + 1] = mR;
    });
    dev.queue.writeBuffer(s.bQ, 0, qBuf, 0, flok.length * 4394);
    dev.queue.writeBuffer(s.bF, 0, fBuf, 0, flok.length * 52);
    dev.queue.writeBuffer(s.bB, 0, bBuf, 0, flok.length * 52);
    dev.queue.writeBuffer(s.bHak, 0, hBuf, 0, flok.length * 2);
    dev.queue.writeBuffer(s.bPar, 0, Uint32Array.from([L, job.frø, flok.length, MAKS]));
    dev.queue.writeBuffer(s.bTal, 0, new Uint32Array([0]));
    const enc = dev.createCommandEncoder();
    const pass = enc.beginComputePass();
    pass.setPipeline(pipe); pass.setBindGroup(0, s.bind);
    pass.dispatchWorkgroups(Math.ceil((o.splitRR ? 456976 : 17576) / o.wg), flok.length);
    pass.end();
    enc.copyBufferToBuffer(s.bTal, 0, s.lTal, 0, 4);
    const tD = performance.now();
    dev.queue.submit([enc.finish()]);
    return { s, start, n: flok.length, tD, p: s.lTal.mapAsync(GPUMapMode.READ) };
  }

  const MÅL_MS = (typeof window !== 'undefined' && window.ENIGMA_MAAL_MS) || 120;
  let skridt = 4, estimat = 0, næste = 0, sidsteSlut = t0;
  const iFlyvning = [];
  const stopNu = () => (skalStoppe && skalStoppe()) || forSvag;
  for (;;) {
    while (iFlyvning.length < 2 && ledige.length && (igen.length || næste < job.enheder.length) &&
           !stopNu() && !(skalPause && skalPause())) {
      if (igen.length) { iFlyvning.push(send(ledige.shift(), igen.shift(), 1)); continue; }
      const k = send(ledige.shift(), næste, skridt);
      næste += k.n;
      iFlyvning.push(k);
    }
    if (!iFlyvning.length) {
      if ((næste >= job.enheder.length && !igen.length) || stopNu()) break;
      const p0 = performance.now();
      while (skalPause && skalPause() && !(skalStoppe && skalStoppe())) await new Promise(r => setTimeout(r, 400));
      pausetMs += performance.now() - p0;
      sidsteSlut = performance.now();
      continue;
    }
    const k = iFlyvning.shift();
    await k.p;
    const tSlut = performance.now();
    const varighed = tSlut - Math.max(k.tD, sidsteSlut);
    sidsteSlut = tSlut;
    const n = new Uint32Array(k.s.lTal.getMappedRange())[0];
    k.s.lTal.unmap();
    if (forSvag) { ledige.push(k.s); continue; }
    if (n > MAKS) {
      overløb = true;
      if (k.n > 1) for (let e = k.start; e < k.start + k.n; e++) igen.push(e);
      else mangler++;
      ledige.push(k.s); continue;
    }
    if (alleStop.length + n > STOPLOFT) { forSvag = true; ledige.push(k.s); continue; }
    færdige += k.n;
    const antal = n;
    if (antal > 0) {
      const enc2 = dev.createCommandEncoder();
      enc2.copyBufferToBuffer(k.s.bStop, 0, k.s.lStop, 0, antal * 9 * 4);
      dev.queue.submit([enc2.finish()]);
      await k.s.lStop.mapAsync(GPUMapMode.READ, 0, antal * 9 * 4);
      const raa = new Uint32Array(k.s.lStop.getMappedRange(0, antal * 9 * 4));
      for (let i = 0; i < antal; i++) {
        const st = Array.from(raa.subarray(i * 9, i * 9 + 9));
        st[0] += k.start;
        alleStop.push(st);
      }
      k.s.lStop.unmap();
      sidsteSlut = performance.now();
    }
    ledige.push(k.s);
    if (påFremdrift) påFremdrift(færdige + mangler, job.enheder.length, alleStop.length, (performance.now() - t0 - pausetMs) / 1000, overløb);
    estimat = Math.max(varighed / k.n, estimat * 0.7);
    skridt = Math.max(1, Math.min(FLOK, 2 * k.n, Math.floor(MÅL_MS / Math.max(estimat, 1))));
  }
  for (const k of iFlyvning) { try { await k.p; k.s.lTal.unmap(); } catch (_) {} }
  for (const s of sæt) for (const b of Object.values(s)) if (b && b.destroy) b.destroy();
  bCr.destroy(); bCi.destroy(); bMeta.destroy();
  mangler = job.enheder.length - færdige;
  return { stop: alleStop, overløb, forSvag, mangler, sekunder: (performance.now() - t0 - pausetMs) / 1000 };
}

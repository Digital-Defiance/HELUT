'use strict';
// GPU-bomben, version 2 — kører HELE kriben, ikke kun et vindue.
//
// Opregner de konkrete ringstillinger i stedet for abstrakte stepping-skemaer.
// For hver højre-ringstilling gælder: rammer midterrotoren aldrig sit eget hak,
// er steppingen ens for alle midter-ringstillinger, og den kører vi én gang.
// Kun de få hvor venstre rotor faktisk stepper, køres hver for sig.
//
// Det fjerner længdegrænsen på 13 bogstaver (dobbelthak og to midterstep er
// dækket, fordi steppingen simuleres direkte) — og dermed får bomben hele
// den lange kribs filtreringskraft.
//
// Valideret bit-eksakt mod CPU-referencen i gpu-facit2.js.

const GPU_WGSL = `
struct Par { L: u32, froe: u32, enheder: u32, maksStop: u32 };

@group(0) @binding(0) var<storage, read> Q    : array<u32>;
@group(0) @binding(1) var<storage, read> f2   : array<u32>;
@group(0) @binding(2) var<storage, read> b2   : array<u32>;
@group(0) @binding(3) var<storage, read> cr   : array<u32>;
@group(0) @binding(4) var<storage, read> cic  : array<u32>;
@group(0) @binding(5) var<uniform>       par  : Par;
@group(0) @binding(6) var<storage, read_write> taeller : atomic<u32>;
@group(0) @binding(7) var<storage, read_write> stop : array<u32>;
@group(0) @binding(8) var<storage, read> hak  : array<u32>;   // 2 per enhed: midt, højre

var<workgroup> Qs: array<u32, 4394>;
var<workgroup> til: array<u32, 1664>;

fn qByte(i: u32) -> u32 { return (Qs[i >> 2u] >> ((i & 3u) * 8u)) & 255u; }

fn Pval(u: u32, qb: u32, k: u32, x: u32) -> u32 {
  let y = (f2[u * 26u + (x + k) % 26u] + 26u - k) % 26u;
  return (b2[u * 26u + (qByte(qb + y) + k) % 26u] + 26u - k) % 26u;
}

@compute @workgroup_size(64)
fn main(@builtin(workgroup_id) wg: vec3<u32>,
        @builtin(local_invocation_id) li: vec3<u32>) {
  let lid = li.x;
  let u = wg.y;
  for (var i: u32 = lid; i < 4394u; i = i + 64u) { Qs[i] = Q[u * 4394u + i]; }
  workgroupBarrier();

  let r = wg.x * 64u + lid;
  if (r >= 17576u) { return; }
  let kL = r / 676u;
  let kM = (r / 26u) % 26u;
  let kR = r % 26u;
  let L  = par.L;
  let hakM = hak[u * 2u];
  let hakR = hak[u * 2u + 1u];
  var stempel: u32 = 0u;

  for (var rr: u32 = 0u; rr < 26u; rr = rr + 1u) {
    var tagetNul = false;
    for (var rm: u32 = 0u; rm < 26u; rm = rm + 1u) {

      // --- steppingen over kriben som tre bitmasker ---
      var pm = (kM + rm) % 26u;
      var pr = (kR + rr) % 26u;
      var dl: u32 = 0u; var dm: u32 = 0u;
      var ml: u32 = 0u; var l2: u32 = 0u;
      var m1: u32 = 0u; var m2: u32 = 0u; var m3: u32 = 0u;
      for (var i: u32 = 1u; i < L; i = i + 1u) {
        if (((hakM >> pm) & 1u) == 1u) { pm = (pm + 1u) % 26u; dm = dm + 1u; dl = dl + 1u; }
        else if (((hakR >> pr) & 1u) == 1u) { pm = (pm + 1u) % 26u; dm = dm + 1u; }
        pr = (pr + 1u) % 26u;
        // Tre bits til midterrotoren og to til venstre. Med kun to hhv. een
        // maettede taelleren, og en gyldig tilstand blev repraesenteret som en
        // anden maskine - hvorefter den rigtige noegle blev kasseret.
        if (dl >= 1u) { ml = ml | (1u << i); }
        if (dl >= 2u) { l2 = l2 | (1u << i); }
        if (dm >= 1u) { m1 = m1 | (1u << i); }
        if (dm >= 2u) { m2 = m2 | (1u << i); }
        if (dm >= 3u) { m3 = m3 | (1u << i); }
      }
      if (ml == 0u) {
        if (tagetNul) { continue; }
        tagetNul = true;
      }

      // --- bomben over hele kriben ---
      for (var h: u32 = 0u; h < 26u; h = h + 1u) {
        stempel = stempel + 256u;
        let st = stempel;
        til[par.froe * 64u + lid] = st | (h + 1u);
        til[h * 64u + lid] = st | (par.froe + 1u);
        var ok = true;
        var aendret = true;
        while (aendret && ok) {
          aendret = false;
          for (var i: u32 = 0u; i < L; i = i + 1u) {
            let dL = ((ml >> i) & 1u) + ((l2 >> i) & 1u);
            let dM = ((m1 >> i) & 1u) + ((m2 >> i) & 1u) + ((m3 >> i) & 1u);
            let qb = (((kL + dL) % 26u) * 26u + ((kM + dM) % 26u)) * 26u;
            let k  = (kR + i) % 26u;
            let p  = cr[i];
            // 99 = bogstav vi ikke stoler paa (afskrivningsfejl). Pladsen
            // taeller stadig i steppingen, men binder ingenting.
            if (p >= 26u) { continue; }
            let c  = cic[i];

            let rp = til[p * 64u + lid];
            if ((rp & 0xFFFFFF00u) == st) {
              let v = Pval(u, qb, k, (rp & 255u) - 1u);
              let rc = til[c * 64u + lid];
              if ((rc & 0xFFFFFF00u) != st) {
                if ((til[v * 64u + lid] & 0xFFFFFF00u) == st) { ok = false; break; }
                til[c * 64u + lid] = st | (v + 1u);
                til[v * 64u + lid] = st | (c + 1u);
                aendret = true;
              } else if ((rc & 255u) - 1u != v) { ok = false; break; }
            }
            let rc2 = til[c * 64u + lid];
            if ((rc2 & 0xFFFFFF00u) == st) {
              let v = Pval(u, qb, k, (rc2 & 255u) - 1u);
              let rp2 = til[p * 64u + lid];
              if ((rp2 & 0xFFFFFF00u) != st) {
                if ((til[v * 64u + lid] & 0xFFFFFF00u) == st) { ok = false; break; }
                til[p * 64u + lid] = st | (v + 1u);
                til[v * 64u + lid] = st | (p + 1u);
                aendret = true;
              } else if ((rp2 & 255u) - 1u != v) { ok = false; break; }
            }
          }
        }
        if (ok) {
          let n = atomicAdd(&taeller, 1u);
          if (n < par.maksStop) {
            let o = n * 9u;
            stop[o+0u]=u; stop[o+1u]=kL; stop[o+2u]=kM; stop[o+3u]=kR; stop[o+4u]=rr;
            stop[o+5u]=ml; stop[o+6u]=m1; stop[o+7u]=m2; stop[o+8u]=h;
          }
        }
      }
    }
  }
}`;

// Q = venstre rotor + midterrotor + reflektor, for alle (kL, kM)
function gpuByggQ(rotL, rotM, ref) {
  const E = window.Enigma;
  const Q = new Uint8Array(26 * 26 * 26);
  const f0 = E.F[rotL], b0 = E.B[rotL], f1 = E.F[rotM], b1 = E.B[rotM];
  for (let kL = 0; kL < 26; kL++) for (let kM = 0; kM < 26; kM++) {
    const base = (kL * 26 + kM) * 26;
    for (let x = 0; x < 26; x++) {
      let y = (f1[(x + kM) % 26] - kM + 26) % 26;
      y = (f0[(y + kL) % 26] - kL + 26) % 26;
      y = ref[y];
      y = (b0[(y + kL) % 26] - kL + 26) % 26;
      y = (b1[(y + kM) % 26] - kM + 26) % 26;
      Q[base + x] = y;
    }
  }
  return Q;
}

async function gpuOpsætning() {
  if (!navigator.gpu) throw new Error('WebGPU er ikke tilgængelig i denne browser.');
  const ad = await navigator.gpu.requestAdapter({ powerPreference: 'high-performance' });
  if (!ad) throw new Error('Ingen GPU-adapter.');
  // Et device får kun 16 KB delt hukommelse som standard — vi skal bruge ~24.
  const ønsket = Math.min(32768, ad.limits.maxComputeWorkgroupStorageSize);
  if (ønsket < 24232) throw new Error(`GPU'en tilbyder kun ${ønsket} bytes delt hukommelse; der skal bruges 24.232.`);
  const dev = await ad.requestDevice({ requiredLimits: { maxComputeWorkgroupStorageSize: ønsket } });
  dev.pushErrorScope('validation');
  const mod = dev.createShaderModule({ code: GPU_WGSL });
  const info = await mod.getCompilationInfo();
  for (const m of info.messages) if (m.type === 'error') throw new Error(`WGSL linje ${m.lineNum}: ${m.message}`);
  const pipe = dev.createComputePipeline({ layout: 'auto', compute: { module: mod, entryPoint: 'main' } });
  const fejl = await dev.popErrorScope();
  if (fejl) throw new Error('pipeline: ' + fejl.message);
  return { ad, dev, pipe, navn: (ad.info && ad.info.architecture) || 'ukendt' };
}

// Kører enhedslisten igennem. påFremdrift(gjort, ialt, stop, sekunder)
async function gpuScan(g, job, påFremdrift, skalStoppe, maksStop, skalPause) {
  const E = window.Enigma;
  const { dev, pipe } = g;
  const ST = GPUBufferUsage.STORAGE, CD = GPUBufferUsage.COPY_DST, CS = GPUBufferUsage.COPY_SRC;
  // FLOK er loftet for enheder pr. kommando (buffere er dimensioneret til det).
  const FLOK = 16;
  const MAKS = maksStop || 60000;
  // Over dette er kriben for svag til at afgoere noget. Afbryd i stedet for at
  // fylde browserens hukommelse (det faeldede browseren 2026-09-24).
  const STOPLOFT = 500000;
  let forSvag = false;
  const alleStop = [];
  // 28/9 (ChatGPT-review): et overløb må IKKE kassere stop fra enheder der allerede er
  // færdige. En portion der løber over, køres om én enhed ad gangen; løber en ENKELT
  // enhed over, springes kun den over og tælles som manglende. Rammes STOPLOFT,
  // stopper scanningen, men de indsamlede stop behandles stadig ("delvis").
  const igen = [];            // enheder der skal køres om enkeltvis
  let færdige = 0, mangler = 0;
  let overløb = false;
  const t0 = performance.now();
  let pausetMs = 0;          // holdes udenfor, saa enh/s og logget tid forbliver aerlige

  const bCr = dev.createBuffer({ size: Math.max(4, job.cr.length * 4), usage: ST | CD });
  const bCi = dev.createBuffer({ size: Math.max(4, job.cic.length * 4), usage: ST | CD });
  dev.queue.writeBuffer(bCr, 0, Uint32Array.from(job.cr));
  dev.queue.writeBuffer(bCi, 0, Uint32Array.from(job.cic));

  // TO SÆT buffere, så der altid ligger én kommando klar i GPU'ens kø, mens browseren
  // venter på svar fra den forrige (24/9 aften: 50-70 % udnyttelse i Firefox, fordi
  // GPU'en stod stille under hver mapAsync-rundtur). Hver kommando er stadig ~0,25 s.
  function lavSæt() {
    const s = {
      bQ: dev.createBuffer({ size: FLOK * 4394 * 4, usage: ST | CD }),
      bF: dev.createBuffer({ size: FLOK * 26 * 4, usage: ST | CD }),
      bB: dev.createBuffer({ size: FLOK * 26 * 4, usage: ST | CD }),
      bHak: dev.createBuffer({ size: FLOK * 2 * 4, usage: ST | CD }),
      bPar: dev.createBuffer({ size: 16, usage: GPUBufferUsage.UNIFORM | CD }),
      bTal: dev.createBuffer({ size: 4, usage: ST | CS | CD }),
      bStop: dev.createBuffer({ size: MAKS * 9 * 4, usage: ST | CS }),
      lTal: dev.createBuffer({ size: 4, usage: GPUBufferUsage.MAP_READ | CD }),
      lStop: dev.createBuffer({ size: MAKS * 9 * 4, usage: GPUBufferUsage.MAP_READ | CD }),
    };
    s.bind = dev.createBindGroup({
      layout: pipe.getBindGroupLayout(0),
      entries: [s.bQ, s.bF, s.bB, bCr, bCi, s.bPar, s.bTal, s.bStop, s.bHak]
        .map((b, i) => ({ binding: i, resource: { buffer: b } })),
    });
    return s;
  }
  const sæt = [lavSæt(), lavSæt()];
  const ledige = sæt.slice();

  const qBuf = new Uint32Array(FLOK * 4394);
  const fBuf = new Uint32Array(FLOK * 26);
  const bBuf = new Uint32Array(FLOK * 26);
  const hBuf = new Uint32Array(FLOK * 2);

  // Byg og send én kommando for enhederne [start, start+n) på et ledigt sæt.
  // (writeBuffer kopierer data med det samme, så CPU-arrays kan genbruges.)
  function send(s, start, n) {
    const flok = job.enheder.slice(start, start + n);
    qBuf.fill(0);
    flok.forEach((e, u) => {
      const ref = e.græsk ? E.sammensatReflektor(e.græsk, e.græskPos, e.refl) : E.REFT[e.refl];
      const Q = gpuByggQ(e.rot[0], e.rot[1], ref);
      for (let i = 0; i < 17576; i++) qBuf[u * 4394 + (i >> 2)] |= Q[i] << ((i & 3) * 8);
      const f = E.F[e.rot[2]], b = E.B[e.rot[2]];
      for (let i = 0; i < 26; i++) { fBuf[u * 26 + i] = f[i]; bBuf[u * 26 + i] = b[i]; }
      let mM = 0; for (const h of E.HAK[e.rot[1]]) mM |= (1 << h);
      let mR = 0; for (const h of E.HAK[e.rot[2]]) mR |= (1 << h);
      hBuf[u * 2] = mM; hBuf[u * 2 + 1] = mR;
    });
    dev.queue.writeBuffer(s.bQ, 0, qBuf);
    dev.queue.writeBuffer(s.bF, 0, fBuf);
    dev.queue.writeBuffer(s.bB, 0, bBuf);
    dev.queue.writeBuffer(s.bHak, 0, hBuf);
    dev.queue.writeBuffer(s.bPar, 0, Uint32Array.from([job.L, job.frø, flok.length, MAKS]));
    dev.queue.writeBuffer(s.bTal, 0, new Uint32Array([0]));
    const enc = dev.createCommandEncoder();
    const pass = enc.beginComputePass();
    pass.setPipeline(pipe); pass.setBindGroup(0, s.bind);
    pass.dispatchWorkgroups(Math.ceil(17576 / 64), flok.length);
    pass.end();
    // Hent KUN tælleren hjem først; stopbufferen kun når der er stop.
    enc.copyBufferToBuffer(s.bTal, 0, s.lTal, 0, 4);
    const tD = performance.now();
    dev.queue.submit([enc.finish()]);
    return { s, start, n: flok.length, tD, p: s.lTal.mapAsync(GPUMapMode.READ) };
  }

  // Selvjusterende skridt: hver GPU-kommando skal tage ~0,25 s, uanset hvor tung
  // kriben er. To nedbrud (0x119, 22/9 og 24/9) skete under lange kommandoer.
  const MÅL_MS = (typeof window !== "undefined" && window.ENIGMA_MAAL_MS) || 120;   // 29/9: 250 -> 120 efter 4. driver-nedbrud (0x119). Målt: -4 % fart på stærke krib, 0 % på svage; 60 ms kostede 21 %
  let skridt = 4, estimat = 0, næste = 0, sidsteSlut = t0;
  const iFlyvning = [];
  const stopNu = () => (skalStoppe && skalStoppe()) || forSvag;
  for (;;) {
    // Fyld køen op til to kommandoer
    while (iFlyvning.length < 2 && ledige.length && (igen.length || næste < job.enheder.length) &&
           !stopNu() && !(skalPause && skalPause())) {
      if (igen.length) { iFlyvning.push(send(ledige.shift(), igen.shift(), 1)); continue; }
      const k = send(ledige.shift(), næste, skridt);
      næste += k.n;
      iFlyvning.push(k);
    }
    if (!iFlyvning.length) {
      if ((næste >= job.enheder.length && !igen.length) || stopNu()) break;
      // Pause: alt i flyvning er færdigt, GPU'en er helt fri
      const p0 = performance.now();
      while (skalPause && skalPause() && !(skalStoppe && skalStoppe()))
        await new Promise(r => setTimeout(r, 400));
      pausetMs += performance.now() - p0;
      sidsteSlut = performance.now();
      continue;
    }
    const k = iFlyvning.shift();
    await k.p;
    const tSlut = performance.now();
    // Ren GPU-tid for DENNE kommando: fra den forrige blev færdig (eller denne blev sendt)
    const varighed = tSlut - Math.max(k.tD, sidsteSlut);
    sidsteSlut = tSlut;
    const n = new Uint32Array(k.s.lTal.getMappedRange())[0];
    k.s.lTal.unmap();
    if (forSvag) { ledige.push(k.s); continue; }   // allerede afbrudt: bare tøm køen
    if (n > MAKS) {
      overløb = true;
      if (k.n > 1) for (let e = k.start; e < k.start + k.n; e++) igen.push(e);
      else mangler++;
      ledige.push(k.s); continue;
    }
    if (alleStop.length + n > STOPLOFT) { forSvag = true; ledige.push(k.s); continue; }
    færdige += k.n;

    const antal = Math.min(n, MAKS);
    if (antal > 0) {
      const enc2 = dev.createCommandEncoder();
      enc2.copyBufferToBuffer(k.s.bStop, 0, k.s.lStop, 0, antal * 9 * 4);
      dev.queue.submit([enc2.finish()]);
      await k.s.lStop.mapAsync(GPUMapMode.READ, 0, antal * 9 * 4);
      const raa = new Uint32Array(k.s.lStop.getMappedRange(0, antal * 9 * 4));
      for (let i = 0; i < antal; i++) {
        const st = Array.from(raa.slice(i * 9, i * 9 + 9));
        st[0] += k.start;                                // global enhedsindeks
        alleStop.push(st);
      }
      k.s.lStop.unmap();
      sidsteSlut = performance.now();
    }
    ledige.push(k.s);

    if (påFremdrift) påFremdrift(færdige + mangler, job.enheder.length, alleStop.length,
      (performance.now() - t0 - pausetMs) / 1000, overløb);
    // Husk tunge enheder et stykke tid, og voks hoejst til det dobbelte ad gangen.
    estimat = Math.max(varighed / k.n, estimat * 0.7);
    skridt = Math.max(1, Math.min(FLOK, 2 * k.n, Math.floor(MÅL_MS / Math.max(estimat, 1))));
  }
  // Ryd op: afbrudte kommandoer skal være færdige før bufferne slippes
  for (const k of iFlyvning) { try { await k.p; k.s.lTal.unmap(); } catch (_) {} }
  for (const s of sæt) for (const b of Object.values(s)) if (b && b.destroy) b.destroy();
  bCr.destroy(); bCi.destroy();
  // Alt der hverken blev færdigt eller talt som manglende (afbrudt/stoppet) mangler også.
  mangler = job.enheder.length - færdige;
  return { stop: alleStop, overløb, forSvag, mangler, sekunder: (performance.now() - t0 - pausetMs) / 1000 };
}

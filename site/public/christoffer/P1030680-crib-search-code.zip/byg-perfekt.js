'use strict';
// 4/10: PERFEKTIONS-MOTOREN. For hver hypotese i perfekt-hypoteser.txt:
//   1) DÆKNINGS-REGNSKAB: hvilke enkelt-hørefejl i kriben ville den rigtige nøgle have overlevet i de kørsler
//      der ALLEREDE er lavet? En kørsel r tester hypotesen H, hvis r's kendte bogstaver er en del af H (samme
//      plads). En hørefejl på bogstav e er dækket af r, hvis e ikke er "dødeligt" i r:
//        - fejltolerant solver (Duif-node efter 30/9 kl. 10:22): kun bogstaverne i GPU-vinduet er dødelige;
//          én fejl uden for vinduet tåles af CPU'en (Astra 6-rettelsen).
//        - streng solver (alt før): alle kendte bogstaver er dødelige.
//        - maskerede bogstaver ('?') i r er aldrig dødelige.
//   2) MANGLENDE KØRSLER: grådigt vælges maskerede varianter (én sammenhængende blok sat til '?') indtil
//      ALLE enkeltfejl er dækket. Hver variant skal stadig have en stærk menu (se stærkNok; samme
//      vinduesregel som ui.js), ellers giver den hundredtusinder af stop og ender som 'delvis'.
//   3) SIKKERHED: P(den rigtige nøgle findes | hypotesen er rigtig) med 3 % hørefejl pr. bogstav,
//      regnet over 0, 1 og 2 fejl. Før og efter de nye kørsler.
// Kør:  node byg-perfekt.js            -> kribs-perfekt.txt + rapport
//       node byg-perfekt.js --status   -> kun rapport (ingen ny kø)
const fs = require('fs'), path = require('path'), os = require('os');
const { menuInfo } = require('./solver.js');
const CT = fs.readFileSync(path.join(__dirname, 'u534.txt'), 'utf8').replace(/[^A-Z]/g, '');
const LOG = path.join(os.homedir(), 'OneDrive', 'Dokumenter', 'enigma-log');
const RETTET = Date.parse('2026-09-30T08:22:49Z');
const Q_FEJL = 0.03, ENHEDER = 34944;
const KUN_STATUS = process.argv.includes('--status');
const MÅL = +(process.argv.find(a => a.startsWith('--maal=')) || '--maal=0.97').split('=')[1];   // stop når sikkerheden når dette
const MAKS_NYE = 12;                                    // højst så mange nye kørsler pr. hypotese

// ---------- kørsler der er gennemført ----------
const kørsler = [], delvis = new Set();
const FÆRDIG = new Set(['intet', 'kriben passer', 'falsk træf', 'MULIG LØSNING', 'passer', 'falsk', 'MULIG']);
for (const f of fs.readdirSync(LOG).filter(f => /^koersler-.*\.jsonl$/.test(f))) {
  const pc = f.replace(/^koersler-|\.jsonl$/g, '');
  for (const l of fs.readFileSync(path.join(LOG, f), 'utf8').split(/\r?\n/)) {
    let x; try { x = JSON.parse(l); } catch (_) { continue; }
    if (x.krib && x.status === 'delvis') delvis.add(x.krib + ' @' + x.plads);
    if (!x.krib || !FÆRDIG.has(x.status)) continue;
    kørsler.push({ krib: x.krib, plads: +x.plads, tolerant: pc === 'Duif-node' && Date.parse(x.tid) >= RETTET });
  }
}
for (const r of fs.readFileSync(path.join(__dirname, 'daekning.csv'), 'utf8').trim().split(/\r?\n/).slice(1).map(l => l.split(';')))
  if (r[0] && FÆRDIG.has(r[2])) kørsler.push({ krib: r[0], plads: +r[1], tolerant: false });

// ---------- GPU-vinduet (samme regel som ui.js /api/gpu/job) ----------
function vindue(krib, plads) {                       // plads 1-baseret -> { w, L, m } eller null
  const D = plads - 1;
  if (D < 0 || D + krib.length > CT.length) return null;
  let kol = 0; for (let i = 0; i < krib.length; i++) if (krib[i] === CT[D + i]) kol++;
  if (kol > 1) return null;
  const kM = kol === 1 ? [...krib].map((c, i) => c === CT[D + i] ? '?' : c).join('') : krib;
  const L = Math.min(krib.length, 26); let w = 0, m = null;
  for (let x = 0; x + L <= krib.length; x++) {
    const mx = menuInfo(kM.slice(x), CT.slice(D + x), L);
    if (!m || mx.frøLøkker > m.frøLøkker || (mx.frøLøkker === m.frøLøkker && mx.frøKanter > m.frøKanter)) { m = mx; w = x; }
  }
  return { w, L, m, kM };
}
// Menu-styrke der holder stop-tallet nede (målt 4/10 på ~2.000 kørsler: 11-12 kanter med 1 løkke gav
// "delvis" i ~20 % af tilfældene; disse kombinationer gav p90 under ~60.000 stop og næsten aldrig delvis)
// Strammet samme aften: FDREIVIER???????UKK @11 (12 kanter, 2 løkker) gav ~670.000 stop. Nu kun kombinationer
// med median under ~5.000 stop i historikken.
const stærkNok = m => (m.frøKanter >= 15 && m.frøLøkker >= 1) || (m.frøKanter >= 13 && m.frøLøkker >= 2) || (m.frøKanter >= 12 && m.frøLøkker >= 3);
const fart = løkker => løkker >= 3 ? 1200 : løkker === 2 ? 800 : 400;   // V5, groft (enh/s)

// ---------- hypoteser ----------
const hyp = [];
for (const l of fs.readFileSync(path.join(__dirname, 'perfekt-hypoteser.txt'), 'utf8').split(/\r?\n/)) {
  if (!l.trim() || l.startsWith('#')) continue;
  const [v, k, p, ...g] = l.split('|').map(s => s.trim());
  const krib = k.toUpperCase().replace(/[^A-Z?]/g, '');
  const pladser = p === 'slut' ? [CT.length - krib.length + 1] : p.split(',').map(s => +s.trim()).filter(Boolean);
  for (const pl of pladser) hyp.push({ vægt: +v, krib, plads: pl, grund: g.join('|') });
}

// En kørsel (krib r @ q) som "job" for hypotesen H (h @ p): dødelige og kendte positioner i H's koordinater.
function somJob(h, p, r, q, tolerant) {
  const d = q - p;
  if (d < 0 || d + r.length > h.length) return null;
  const kendt = [];
  for (let i = 0; i < r.length; i++) {
    if (r[i] === '?') continue;
    if (h[d + i] === '?' || h[d + i] !== r[i]) return null;
    kendt.push(d + i);
  }
  if (!kendt.length) return null;
  let dødelig;
  if (tolerant) { const v = vindue(r, q); if (!v) return null; dødelig = []; for (let i = v.w; i < v.w + v.L; i++) if (v.kM[i] !== '?') dødelig.push(d + i); }
  else dødelig = kendt;
  return { kendt: new Set(kendt), dødelig: new Set(dødelig) };
}
// 5/10: fejlrisiko pr. bogstav. Formularen (arkiv/P1030680-formular.jpg) er håndskrevet; to tegn er tvivlsomme ved
// nærlæsning: plads 11 (gruppe 3 "SJEY", 3. tegn ligner formularens 'g') og plads 56 (gruppe 14 "VVBB", sidste tegn
// kan være 'd'; B/D er også nabo-tegn i morse). Plads 68 (C/L) maskeres altid. Øvrige: 3 % (målt 1,9 % i Dönitz-beskeden).
// 7/10: Girard sammenlignede håndskriften med P1030684 (2 E'er, 5 G'er, 6 B'er, 6 D'er): plads 11 = E og plads 56 = B er sikre
// aflæsninger -> ingen ekstra risiko. (Morse-fejl kan stadig ske, men det dækker de almindelige 3 %.)
const RISIKO = {};
const qVed = abs => RISIKO[abs] || Q_FEJL;
// P0 = sandsynlighed for ingen fejl i kriben; enkelt-fejl e vejer P0*r(e), par (a,b) vejer P0*r(a)*r(b), r = q/(1-q)
function vægte(kendte, plads) {
  const r = new Map(); let P0 = 1;
  for (const e of kendte) { const q = qVed(plads + e); P0 *= 1 - q; r.set(e, q / (1 - q)); }
  return { P0, r };
}
function sikkerhed(kendte, jobs, plads) {
  const n = kendte.length; if (!n) return { p: 0, enkelt: 0, udækket: [] };
  const { P0, r } = vægte(kendte, plads);
  const dæk1 = e => jobs.some(j => !j.dødelig.has(e));
  const dæk2 = (a, b) => jobs.some(j => !j.dødelig.has(a) && !j.dødelig.has(b) && (j.kendt.has(a) ? 1 : 0) + (j.kendt.has(b) ? 1 : 0) <= 1);
  const udækket = kendte.filter(e => !dæk1(e));
  let p = jobs.length ? P0 : 0;
  for (const e of kendte) if (!udækket.includes(e)) p += P0 * r.get(e);
  for (let a = 0; a < n; a++) for (let b = a + 1; b < n; b++) if (dæk2(kendte[a], kendte[b])) p += P0 * r.get(kendte[a]) * r.get(kendte[b]);
  return { p, enkelt: (n - udækket.length) / n, udækket };
}

const rapport = [], kø = [];
for (const H of hyp) {
  // plads 68 (NGSC/NGSL) altid ukendt
  let h = [...H.krib].map((c, i) => (H.plads - 1 + i === 67 ? '?' : c)).join('');
  let kendte = [...h].map((c, i) => (c === '?' ? -1 : i)).filter(i => i >= 0);
  const v0 = vindue(h, H.plads);
  if (!v0) { rapport.push({ ...H, fejl: 'umulig her (kollision med ciffertekst eller uden for beskeden)' }); continue; }
  // Én kollision: er hypotesen rigtig, SKAL netop det cifferbogstav være fejlhørt (Enigma krypterer aldrig et
  // bogstav til sig selv). Det bogstav maskeres; hypotesen er så ca. (1-q)/q = 30x mindre sandsynlig på forhånd.
  const kolPos = []; for (let i = 0; i < h.length; i++) if (h[i] === CT[H.plads - 1 + i]) kolPos.push(i);
  if (kolPos.length) { h = [...h].map((c, i) => kolPos.includes(i) ? '?' : c).join(''); kendte = kendte.filter(i => !kolPos.includes(i)); }
  const jobs = [];
  for (const r of kørsler) { const j = somJob(h, H.plads, r.krib, r.plads, r.tolerant); if (j) jobs.push(j); }
  const før = sikkerhed(kendte, jobs, H.plads);
  // kandidater: hele kriben + én maskeret blok (2..halvdelen af bogstaverne)
  const kand = [];
  const prøv = (s) => {
    let a = 0, b = s.length; while (a < b && s[a] === '?') a++; while (b > a && s[b - 1] === '?') b--;
    const jc = s.slice(a, b), q = H.plads + a; if (jc.length < 8 || delvis.has(`${jc} @${q}`)) return;
    const v = vindue(jc, q); if (!v || !stærkNok(v.m)) return;
    const j = somJob(h, H.plads, jc, q, true); if (!j) return;
    kand.push({ linje: `${jc} @${q}`, ...j, løkker: v.m.frøLøkker, sek: ENHEDER / fart(v.m.frøLøkker) });
  };
  const maske = (s, a, l) => s.slice(0, a) + '?'.repeat(l) + s.slice(a + l);
  prøv(h);
  const halv = Math.ceil(kendte.length / 2);
  for (let bl = 2; bl <= halv; bl++) for (let a = 0; a + bl <= h.length; a++) prøv(maske(h, a, bl));
  for (let b1 = 2; b1 <= 7; b1++) for (let b2 = 2; b2 <= 7; b2++) if (b1 + b2 <= halv)
    for (let a = 0; a + b1 <= h.length; a++) for (let b = a + b1 + 1; b + b2 <= h.length; b++) prøv(maske(maske(h, a, b1), b, b2));
  // Gevinst = sandsynlighed for at den rigtige nøgle overlever, regnet på enkelt- og dobbeltfejl der endnu er udækkede
  const { P0, r: rr } = vægte(kendte, H.plads);
  const w1 = e => P0 * rr.get(e), w2 = k => P0 * rr.get(Math.floor(k / 100)) * rr.get(k % 100);
  const alleJobs = jobs.slice(), nye = [];
  const dæk1 = new Set(kendte.filter(e => alleJobs.some(j => !j.dødelig.has(e))));
  const parNøgle = (a, b) => a * 100 + b;
  const dæk2 = new Set();
  const parAf = j => { const fri = kendte.filter(e => !j.dødelig.has(e)), ud = [];
    for (let x = 0; x < fri.length; x++) for (let y = x + 1; y < fri.length; y++) if ((j.kendt.has(fri[x]) ? 1 : 0) + (j.kendt.has(fri[y]) ? 1 : 0) <= 1) ud.push(parNøgle(fri[x], fri[y]));
    return ud; };
  for (const j of alleJobs) for (const k of parAf(j)) dæk2.add(k);
  let p = før.p;
  while (!KUN_STATUS && p < MÅL && nye.length < MAKS_NYE) {
    let bedst = null, bV = 0, bG = 0;
    for (const c of kand) {
      if (nye.includes(c)) continue;
      let g = 0; for (const e of kendte) if (!dæk1.has(e) && !c.dødelig.has(e)) g += w1(e);
      for (const k of (c.par || (c.par = parAf(c)))) if (!dæk2.has(k)) g += w2(k);
      if (!alleJobs.length && !nye.length) g += P0;
      const værdi = g / c.sek;                         // sandsynlighed pr. GPU-sekund
      if (værdi > bV) { bedst = c; bV = værdi; bG = g; }
    }
    if (!bedst || bG < 0.002) break;                   // under 0,2 procentpoint er ikke umagen værd
    nye.push(bedst); alleJobs.push(bedst); p += bG;
    for (const e of kendte) if (!bedst.dødelig.has(e)) dæk1.add(e);
    for (const k of bedst.par) dæk2.add(k);
  }
  const efter = sikkerhed(kendte, jobs.concat(nye), H.plads);
  rapport.push({ ...H, n: kendte.length, gamle: jobs.length, før, nye, efter, kollision: kolPos.length });
  if (nye.length) kø.push({ H, nye, efter, prio: H.vægt - (kolPos.length ? 1.5 : 0) });   // kollision = kræver en hørefejl -> lavere prioritet
}

// ---------- ud ----------
const pct = x => (100 * x).toFixed(0).padStart(3) + ' %';
console.log('vægt  hypotese                                         plads  bogst  kørt  sikkerhed før -> efter  nye kørsler (ca. tid)');
for (const r of rapport) {
  const navn = (r.krib.length > 46 ? r.krib.slice(0, 43) + '...' : r.krib).padEnd(46);
  if (r.fejl) { console.log(`  ${r.vægt}   ${navn} @${String(r.plads).padEnd(4)} ${r.fejl}`); continue; }
  const tid = r.nye.reduce((s, c) => s + c.sek, 0);
  console.log(`  ${r.vægt}   ${navn} @${String(r.plads).padEnd(4)} ${String(r.n).padStart(4)}  ${String(r.gamle).padStart(4)}   ${pct(r.før.p)} -> ${pct(r.efter.p)}` +
    `   ${r.nye.length} (${Math.round(tid / 60)} min)` + (r.kollision ? '  · KRÆVER 1 hørefejl (kollision) -> ~30x mindre sandsynlig' : '') + (r.efter.udækket.length ? `  · ${r.efter.udækket.length} bogstaver kan ikke dækkes` : ''));
}
if (!KUN_STATUS) {
  kø.sort((a, b) => b.prio - a.prio);
  const linjer = ['# PERFEKTIONS-KØ (byg-perfekt.js ' + new Date().toISOString().slice(0, 16) + ') - maskerede varianter der dækker alle enkelt-hørefejl'];
  for (const { H, nye, efter } of kø) { linjer.push(`# [${H.vægt}] ${H.krib} @${H.plads} -> ${pct(efter.p).trim()} sikkerhed · ${H.grund}`); for (const c of nye) linjer.push(c.linje); }
  fs.writeFileSync(path.join(__dirname, 'kribs-perfekt.txt'), linjer.join('\n') + '\n');
  const alle = kø.reduce((s, x) => s + x.nye.length, 0), sek = kø.reduce((s, x) => s + x.nye.reduce((t, c) => t + c.sek, 0), 0);
  console.log(`\n${alle} nye kørsler i kribs-perfekt.txt · ca. ${(sek / 3600).toFixed(1)} timer med V5 (groft skøn)`);
}
fs.writeFileSync(path.join(LOG, 'perfekt-status.json'), JSON.stringify(rapport.map(r => ({ vægt: r.vægt, krib: r.krib, plads: r.plads, grund: r.grund, fejl: r.fejl,
  bogstaver: r.n, kørsler: r.gamle, sikkerhedFør: r.før && +r.før.p.toFixed(3), sikkerhedEfter: r.efter && +r.efter.p.toFixed(3), nye: r.nye && r.nye.map(c => c.linje) })), null, 1));

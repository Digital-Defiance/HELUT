'use strict';
// Enigma M3 og M4 (Kriegsmarine "Schlüssel M").
//
// M3 er verificeret bogstav for bogstav mod emulatoren på
// https://www.101computing.net/enigma-machine-emulator/ (300 tilfældige tests).
// M4 er verificeret mod den ægte U-264-besked fra 1942 (se test.js).
//
// M4 håndteres som en M3 med en *sammensat reflektor*: græskerhjulet står
// stille hele beskeden igennem, så Græsk⁻¹ ∘ tynd reflektor ∘ Græsk er en
// konstant permutation. Det gør at hele resten af koden — også bomben —
// er den samme for begge maskiner.

const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

const ROTORER = {
  I:    { w: 'EKMFLGDQVZNTOWYHXUSPAIBRCJ', hak: 'Q' },
  II:   { w: 'AJDKSIRUXBLHWTMCQGZNPYFVOE', hak: 'E' },
  III:  { w: 'BDFHJLCPRTXVZNYEIWGAKMUSQO', hak: 'V' },
  IV:   { w: 'ESOVPZJAYQUIRHXLNFTGKDCMWB', hak: 'J' },
  V:    { w: 'VZBRGITYUPSDNHLXAWMJQOFECK', hak: 'Z' },
  VI:   { w: 'JPGVOUMFYQBENHZRDKASXLICTW', hak: 'ZM' },
  VII:  { w: 'NZJHGRCXMYSWBOUFAIVLPEKQDT', hak: 'ZM' },
  VIII: { w: 'FKQHTLXOCBJSPDZRAMEWNIUYGV', hak: 'ZM' },
  // Græskerhjul (Zusatzwalze) — kun M4, stepper aldrig
  Beta:  { w: 'LEYJVCNIXWPBQMDRTAKZGFUHOS', hak: '', græsk: true },
  Gamma: { w: 'FSOKANUERHMBTIYCWLQPZXVGJD', hak: '', græsk: true },
};
const M3_ROTORER = ['I', 'II', 'III', 'IV', 'V'];
const M4_ROTORER = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII'];
const GRÆSKE = ['Beta', 'Gamma'];

const REFLEKTORER = {
  B:  { w: 'YRUHQSLDPXNGOKMIEBFZCWVJAT', navn: 'UKW-B',      m4: false },
  C:  { w: 'FVPJIAOYEDRZXWGCTKUQSBNMHL', navn: 'UKW-C',      m4: false },
  Bt: { w: 'ENKQAUYWJICOPBLMDXZVFTHRGS', navn: 'UKW-B tynd', m4: true },
  Ct: { w: 'RDOBJNTKVEHMLFCWZAXGYIPSUQ', navn: 'UKW-C tynd', m4: true },
};

// Opslagstabeller
const F = {}, B = {}, HAK = {};
for (const navn in ROTORER) {
  const f = new Int8Array(26), b = new Int8Array(26);
  for (let i = 0; i < 26; i++) { const o = ROTORER[navn].w.charCodeAt(i) - 65; f[i] = o; b[o] = i; }
  F[navn] = f; B[navn] = b;
  HAK[navn] = [...ROTORER[navn].hak].map(c => c.charCodeAt(0) - 65);
}
const REFT = {};
for (const k in REFLEKTORER) {
  const t = new Int8Array(26);
  for (let i = 0; i < 26; i++) t[i] = REFLEKTORER[k].w.charCodeAt(i) - 65;
  REFT[k] = t;
}

// Græskerhjulet + tynd reflektor smeltet sammen til én fast reflektor.
// off = græskPosition − græskRing (kun differensen betyder noget).
function sammensatReflektor(græsk, off, tyndNavn) {
  const g = F[græsk], gi = B[græsk], u = REFT[tyndNavn];
  const ud = new Int8Array(26);
  const o = ((off % 26) + 26) % 26;
  for (let x = 0; x < 26; x++) {
    let y = (g[(x + o) % 26] - o + 26) % 26;
    y = u[y];
    ud[x] = (gi[(y + o) % 26] - o + 26) % 26;
  }
  return ud;
}

// opt: {rotorer:['II','IV','I'], ringe:[0,0,0], pos:[0,0,0],
//       reflektor:'B'|'Bt'|Int8Array, græsk:'Beta', græskRing:0, græskPos:0}
function maskine(rotorer, ringe, pos, reflektor, m4) {
  let ref;
  if (reflektor instanceof Int8Array) ref = reflektor;
  else if (m4) ref = sammensatReflektor(m4.græsk, (m4.pos | 0) - (m4.ring | 0), reflektor);
  else ref = REFT[reflektor];
  if (!ref) throw new Error(`Ukendt reflektor: ${reflektor}`);
  return {
    rot: rotorer.slice(), ringe: ringe.slice(), pos: pos.slice(), ref,
    hak: rotorer.map(r => HAK[r]),
    f: rotorer.map(r => F[r]), b: rotorer.map(r => B[r]),
  };
}

const påHak = (hak, p) => hak.length === 1 ? hak[0] === p : hak.indexOf(p) >= 0;

// Historisk korrekt stepping, inkl. dobbeltstep.
function step(M) {
  if (påHak(M.hak[1], M.pos[1])) { M.pos[1] = (M.pos[1] + 1) % 26; M.pos[0] = (M.pos[0] + 1) % 26; }
  else if (påHak(M.hak[2], M.pos[2])) { M.pos[1] = (M.pos[1] + 1) % 26; }
  M.pos[2] = (M.pos[2] + 1) % 26;
}

// Vejen gennem rotorer + reflektor og tilbage (uden plugboard).
// Kun differensen k = position − ring indgår — deraf ækvivalensklasserne.
function igennem(M, c) {
  const k0 = (M.pos[0] - M.ringe[0] + 26) % 26;
  const k1 = (M.pos[1] - M.ringe[1] + 26) % 26;
  const k2 = (M.pos[2] - M.ringe[2] + 26) % 26;
  const f = M.f, b = M.b;
  let x = c;
  x = (f[2][(x + k2) % 26] - k2 + 26) % 26;
  x = (f[1][(x + k1) % 26] - k1 + 26) % 26;
  x = (f[0][(x + k0) % 26] - k0 + 26) % 26;
  x = M.ref[x];
  x = (b[0][(x + k0) % 26] - k0 + 26) % 26;
  x = (b[1][(x + k1) % 26] - k1 + 26) % 26;
  x = (b[2][(x + k2) % 26] - k2 + 26) % 26;
  return x;
}

function identitetsPlug() {
  const p = new Int8Array(26);
  for (let i = 0; i < 26; i++) p[i] = i;
  return p;
}

function plugFraPar(s) {
  const p = identitetsPlug();
  if (!s) return p;
  for (const pr of String(s).toUpperCase().trim().split(/[^A-Z]+/)) {
    if (pr.length === 2) {
      const a = pr.charCodeAt(0) - 65, b2 = pr.charCodeAt(1) - 65;
      if (a === b2) throw new Error(`Plugboard-fejl: ${pr} kobler et bogstav til sig selv.`);
      if (p[a] !== a || p[b2] !== b2) throw new Error(`Plugboard-fejl: ${pr} bruger et bogstav der allerede er koblet.`);
      p[a] = b2; p[b2] = a;
    } else if (pr.length) throw new Error(`Plugboard-fejl: "${pr}" er ikke et par på to bogstaver.`);
  }
  return p;
}

function parTilTekst(p) {
  const o = [];
  for (let i = 0; i < 26; i++) if (p[i] > i) o.push(A[i] + A[p[i]]);
  return o.join(' ');
}

// Kryptering = dekryptering. Maskinen ændres undervejs, så lav en ny pr. kørsel.
function kør(M, tekst, plug) {
  const p = plug || identitetsPlug();
  let ud = '';
  for (const ch of String(tekst).toUpperCase()) {
    const c = ch.charCodeAt(0) - 65;
    if (c < 0 || c > 25) continue;
    step(M);
    ud += A[p[igennem(M, p[c])]];
  }
  return ud;
}

// Ét tastetryk: stepper og returnerer {ud, pos} — til den levende maskine i UI'en
function tast(M, bogstav, plug) {
  const c = String(bogstav).toUpperCase().charCodeAt(0) - 65;
  if (c < 0 || c > 25) return null;
  const p = plug || identitetsPlug();
  step(M);
  return { ud: A[p[igennem(M, p[c])]], pos: M.pos.slice() };
}

function bogstaverFraTekst(s, navn, antal) {
  const t = String(s).toUpperCase().replace(/[^A-Z]/g, '');
  if (t.length !== (antal || 3)) throw new Error(`${navn} skal være ${antal || 3} bogstaver (fik "${s}")`);
  return [...t].map(c => c.charCodeAt(0) - 65);
}

const rens = s => String(s || '').toUpperCase().replace(/[^A-Z]/g, '');
// Krib: '?' = ukendt bogstav (usikker aflaesning, eller et hul mellem to krib-stykker).
// Pladsen taeller med i steppingen, men binder ingenting.
const rensKrib = s => String(s || '').toUpperCase().replace(/[^A-Z?]/g, '');

const API = {
  A, ROTORER, REFLEKTORER, M3_ROTORER, M4_ROTORER, GRÆSKE, F, B, HAK, REFT,
  sammensatReflektor, maskine, step, igennem, kør, tast, påHak,
  identitetsPlug, plugFraPar, parTilTekst, bogstaverFraTekst, rens, rensKrib,
};

if (typeof module !== 'undefined' && module.exports) module.exports = API;
if (typeof window !== 'undefined') window.Enigma = API;

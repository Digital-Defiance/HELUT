#!/usr/bin/env node
'use strict';
// Lokal server til Enigma-grænsefladen.
// Selve knækningen kører som native Node-tråde på alle kerner — browseren
// viser maskinen, fremdriften og resultaterne. Selve maskinen kører også
// i browseren (samme enigma.js), så tastaturet svarer øjeblikkeligt.

const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { exec } = require('child_process');
const E = require('./enigma.js');
const { solve, menuInfo, byggEnheder, vurderTid, vælgVindue } = require('./solver.js');

const ROD = __dirname;
// Lejede GPU'er (sky/): eget logmappe- og maskinnavn via miljøet
const PC = process.env.ENIGMA_PC || os.hostname();
const strømme = new Set();
let job = null;
let gpuJob = null;

function send(type, data) {
  const linje = `data: ${JSON.stringify({ type, ...data })}\n\n`;
  for (const r of strømme) { try { r.write(linje); } catch (_) { } }
}
function json(res, kode, data) {
  const b = Buffer.from(JSON.stringify(data), 'utf8');
  res.writeHead(kode, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': b.length });
  res.end(b);
}
function læsBody(req) {
  return new Promise((ok, fejl) => {
    let s = '';
    req.on('data', c => { s += c; if (s.length > 300e6) req.destroy(); });
    req.on('end', () => { try { ok(s ? JSON.parse(s) : {}); } catch (e) { fejl(e); } });
    req.on('error', fejl);
  });
}
function sprogfil(navn) {
  const n = String(navn || 'tysk').toLowerCase().replace(/[^a-zæøå]/g, '');
  const f = path.join(ROD, n + '.bin');
  if (!fs.existsSync(f)) throw new Error(`Ukendt sprog: ${navn}`);
  return f;
}

// Tag kun de felter frem der faktisk må styre søgningen
function opsætning(b) {
  const model = b.model === 'M4' ? 'M4' : 'M3';
  const tilladte = model === 'M4' ? E.M4_ROTORER : E.M3_ROTORER;
  const rotorer = (Array.isArray(b.rotorer) ? b.rotorer : []).filter(r => tilladte.includes(r));
  const refListe = model === 'M4' ? ['Bt', 'Ct'] : ['B', 'C'];
  const reflektorer = (Array.isArray(b.reflektorer) ? b.reflektorer : []).filter(r => refListe.includes(r));
  const o = {
    model,
    rotorer: rotorer.length >= 3 ? rotorer : tilladte,
    reflektorer: reflektorer.length ? reflektorer : refListe,
  };
  if (model === 'M4') {
    const g = (Array.isArray(b.græske) ? b.græske : []).filter(x => E.GRÆSKE.includes(x));
    o.græske = g.length ? g : E.GRÆSKE;
    if (Array.isArray(b.græskPositioner) && b.græskPositioner.length)
      o.græskPositioner = b.græskPositioner.map(Number).filter(n => n >= 0 && n < 26);
  }
  return o;
}

function refAf(f) {
  return f.græsk ? E.sammensatReflektor(f.græsk, f.græskPos, f.refl) : f.refl;
}

// Mange indstillinger giver samme klartekst — saml dem
function grupper(ct, resultater, maks, krib, D) {
  const kort = new Map();
  for (const r of resultater) {
    const tekst = E.kør(E.maskine(r.rot, r.ringe, r.pos, refAf(r)), ct, Int8Array.from(r.plug));
    if (!kort.has(tekst)) kort.set(tekst, { tekst, s: r.s, v: -Infinity, varianter: [] });
    const g = kort.get(tekst);
    if (r.vindue !== undefined && r.vindue > g.v) g.v = r.vindue;
    if (g.varianter.length < 5) g.varianter.push(r);
    if (r.s > g.s) g.s = r.s;
  }
  // De bedste efter samlet score OG de bedste efter tysk strækning uden for kriben sendes
  // begge med, så grænserne (der afhænger af sprogmodellen) kun bestemmes ét sted: i siden.
  const alle = [...kort.values()];
  // 30/9 (Astra 6): fundreglen kræver <=1 kribfejl. Bevar derfor ALTID de bedste kandidater der opfylder
  // det, så de ikke skubbes ud af top-5 af kandidater med flere kribfejl (jokerpladsen tæller ikke).
  const kribFejl = t => { let n = 0; for (let i = 0; krib && i < krib.length; i++) if (krib[i] !== '?' && krib[i] !== ct[D + i] && t[D + i] !== krib[i]) n++; return n; };
  const berettigede = krib ? alle.filter(g => kribFejl(g.tekst) <= 1) : [];
  const valgt = new Set([...alle].sort((a, b) => b.s - a.s).slice(0, maks)
    .concat([...alle].sort((a, b) => b.v - a.v).slice(0, maks))
    .concat([...berettigede].sort((a, b) => b.s - a.s).slice(0, maks))
    .concat([...berettigede].sort((a, b) => b.v - a.v).slice(0, maks)));
  return [...valgt].sort((a, b) => b.s - a.s).map(g => {
    const v = g.varianter[0];
    const kontrol = E.kør(E.maskine(v.rot, v.ringe, v.pos, refAf(v)), g.tekst, Int8Array.from(v.plug)) === ct;
    return {
      score: g.s, vindue: g.v, tekst: g.tekst, kontrol,
      model: v.græsk ? 'M4' : 'M3',
      rotorer: v.rot,
      græsk: v.græsk || null,
      græskPos: v.græsk ? E.A[v.græskPos] : null,
      refl: v.refl,
      reflektorNavn: E.REFLEKTORER[v.refl].navn,
      ring: v.ringe.map(x => E.A[x]).join(''),
      pos: v.pos.map(x => E.A[x]).join(''),
      plug: E.parTilTekst(Int8Array.from(v.plug)),
      ækvivalente: g.varianter.slice(1).map(x =>
        x.ringe.map(y => E.A[y]).join('') + ' / ' + x.pos.map(y => E.A[y]).join('')),
      dele: g.tekst.split('X').filter(Boolean),
    };
  });
}

const RUTER = {
  async 'POST /api/menu'(body) {
    const ct = E.rens(body.ciffertekst), krib = E.rens(body.krib);
    const L = Math.min(krib.length, 26, ct.length);
    if (!ct || L < 1) return { ok: false, grund: 'tom' };
    for (let i = 0; i < L; i++) if (krib[i] === ct[i])
      return { ok: false, grund: 'selv', position: i + 1, bogstav: krib[i] };
    const m = menuInfo(krib, ct, L);
    let vurdering;
    if (L < 10) vurdering = 'haabloes';
    else if (m.løkker >= 2) vurdering = 'fremragende';
    else if (L >= 13 || m.løkker >= 1) vurdering = 'god';
    else if (L >= 11) vurdering = 'tung';
    else vurdering = 'haabloes';
    return { ok: true, L, længde: ct.length, ...m, vurdering };
  },

  async 'POST /api/skoen'(body) {
    const o = opsætning(body);
    const { enheder } = byggEnheder(o);
    const kerner = Math.max(1, Math.min(parseInt(body.kerner) || os.cpus().length, os.cpus().length));
    return { ok: true, enheder: enheder.length, kerner, sekunder: vurderTid(enheder.length, body.længde || 160, kerner) };
  },

  async 'POST /api/knaek'(body) {
    if (job && job.kører) return { ok: false, fejl: 'Et job kører allerede.' };
    const ct = E.rens(body.ciffertekst);
    const krib = E.rens(body.krib) || 'WETTERBERICHT';
    const kerner = Math.max(1, Math.min(parseInt(body.kerner) || os.cpus().length, os.cpus().length));
    const o = opsætning(body);
    job = { kører: true, stop: null };
    (async () => {
      try {
        const svar = await solve({
          ...o, ciffertekst: ct, krib, sprogfil: sprogfil(body.sprog), kerner,
          påStart(h) {
            job.stop = h.stop;
            send('start', { kerner: h.kerner, enheder: h.enheder, menu: h.menu, skøn: h.skøn, model: o.model });
          },
          påProgress(f, ialt, sek, fundne) { send('fremdrift', { f, ialt, sek, fundne }); },
        });
        send('faerdig', {
          sekunder: svar.sekunder, antal: svar.fundneIalt, afbrudt: svar.afbrudt,
          fund: grupper(ct, svar.resultater, 5),
        });
      } catch (e) {
        send('fejl', { besked: e.message, umuligt: !!e.umuligt });
      } finally { job.kører = false; }
    })();
    return { ok: true };
  },

  async 'POST /api/stop'() {
    if (job && job.kører && job.stop) { job.stop(); return { ok: true }; }
    return { ok: false };
  },

  // ---- GPU-broen ----
  // Browseren scanner hele rummet på grafikkortet og melder tilbage hvilke
  // enheder der overhovedet gav et bombe-stop. Derefter kører den beviste
  // CPU-pipeline videre på netop de enheder — resten er allerede udelukket.
  async 'POST /api/gpu/job'(body) {
    const ct = E.rens(body.ciffertekst);
    // '?' er tilladt (28/9): usikkert bogstav, eller hul mellem to krib-stykker
    // (fx KOMXADMXUUUBOOTE????????ZWOSECHS). Hullet taeller i steppingen, binder intet.
    const krib = E.rensKrib(body.krib) || 'WETTERBERICHT';
    const D = Math.max(0, parseInt(body.kribPlads) || 0);
    if (!ct) throw new Error('Ingen ciffertekst.');
    if (D + krib.length > ct.length) throw new Error('Kriben går ud over beskeden.');
    if (/^\?|\?$/.test(krib)) throw new Error('Kriben må ikke starte eller slutte med ? — flyt @PLADS i stedet.');
    // Samme regel som i solver.js: ÉN kollision er langt mere sandsynligt en
    // afskrivningsfejl hos telegrafisten end et bevis på at kriben er forkert.
    const kol = [];
    for (let i = 0; i < krib.length; i++) if (krib[i] === ct[D + i]) kol.push(i);
    if (kol.length > 1)
      throw new Error(`Umuligt: ${kol.length} krib-bogstaver er lig cifferteksten ` +
        `(plads ${kol.map(i => D + i + 1).join(', ')}). Mere end én er ikke et uheld.`);
    const kribM = kol.length === 1
      ? krib.slice(0, kol[0]) + '?' + krib.slice(kol[0] + 1) : krib;

    const o = opsætning(body);
    // GPU-bomben kører HELE kriben (op til 26 bogstaver — steppingmaskerne er
    // 32-bit). Det er dér den lange kribs løkker sidder.
    // Er kriben laengere end 26 (fx to stykker med hul imellem), vaelges det 26-vindue
    // hvis menu er staerkest; resten af kriben bruger CPU'en som haardt eftercheck.
    // (Foer 28/9 var vinduet altid de foerste 26 bogstaver.)
    const L = Math.min(krib.length, 26);
    let w = 0, m = null;
    for (let x = 0; x + L <= krib.length; x++) {
      const mx = menuInfo(kribM.slice(x), ct.slice(D + x), L);
      if (!m || mx.frøLøkker > m.frøLøkker || (mx.frøLøkker === m.frøLøkker && mx.frøKanter > m.frøKanter)) { m = mx; w = x; }
    }
    const W = D + w;
    const { enheder } = byggEnheder(o);
    const cr = [], cic = [];
    for (let i = 0; i < L; i++) {
      cr.push(kribM[w + i] === '?' ? 99 : kribM.charCodeAt(w + i) - 65);   // 99 = ukendt
      cic.push(ct.charCodeAt(W + i) - 65);
    }
    // Maalt: 6 kanter i froeens komponent -> over 27 mio. stop; 9 -> gik; 13+ -> hundreder.
    if (m.frøKanter < 9) throw new Error(`For svag menu: kun ${m.frøKanter} kanter i den del af menuen bomben kan bruge (${m.komponenter} dele). Det ville give millioner af stop.`);
    gpuJob = { ct, krib, D, W, o, sprog: body.sprog, kerner: body.kerner, enheder, frø: m.frø, L };
    return {
      ok: true, L, D, W, frø: m.frø, cr, cic, løkker: m.løkker, største: m.største,
      model: o.model, antal: enheder.length,
      enheder: enheder.map(e => ({ rot: e.rot, refl: e.refl, græsk: e.græsk || null, græskPos: e.græskPos | 0 })),
    };
  },

  async 'POST /api/gpu/faerdig'(body) {
    if (!gpuJob) throw new Error('Intet GPU-job i gang.');
    const idx = Array.isArray(body.enheder) ? body.enheder : [];
    const valgte = idx.map(i => gpuJob.enheder[i]).filter(Boolean);
    send('start', {
      kerner: 0, enheder: valgte.length, menu: { løkker: body.løkker | 0 },
      model: gpuJob.o.model, gpu: true,
    });
    if (!valgte.length) {
      send('faerdig', { sekunder: body.gpuSekunder || 0, antal: 0, afbrudt: false, fund: [], gpu: true });
      return { ok: true, enheder: 0 };
    }
    const kerner = Math.max(1, Math.min(parseInt(gpuJob.kerner) || os.cpus().length, os.cpus().length));
    // Sender browseren selve stoppene (9 tal pr. stop), arbejder CPU'en direkte paa
    // dem i stedet for at koere hele bomben forfra paa hver ramt enhed. Maalt:
    // 0,35 ms pr. stop mod timer for den gamle vej ved mange stop.
    let gpuStop;
    if (Array.isArray(body.stop)) {
      const pr = new Map();
      for (let i = 0; i + 9 <= body.stop.length; i += 9) {
        const u = body.stop[i];
        if (!gpuJob.enheder[u]) continue;
        if (!pr.has(u)) pr.set(u, []);
        pr.get(u).push(body.stop.slice(i + 1, i + 9));
      }
      gpuStop = [];
      for (const [u, st] of pr) for (let k = 0; k < st.length; k += 256)
        gpuStop.push({ enhed: gpuJob.enheder[u], stops: st.slice(k, k + 256) });
    }
    (async () => {
      try {
        const svar = await solve({
          ...gpuJob.o, enheder: valgte, gpuStop, gpuFrø: gpuJob.frø, gpuL: gpuJob.L, gpuW: gpuJob.W,
          ciffertekst: gpuJob.ct, krib: gpuJob.krib,
          kribPlads: gpuJob.D, sprogfil: sprogfil(gpuJob.sprog), kerner,
          påProgress(f, ialt, sek, fundne) { send('fremdrift', { f, ialt, sek, fundne }); },
        });
        send('faerdig', {
          sekunder: (body.gpuSekunder || 0) + svar.sekunder, antal: svar.fundneIalt,
          afbrudt: false, fund: grupper(gpuJob.ct, svar.resultater, 5, gpuJob.krib, gpuJob.D), gpu: true,
        });
      } catch (e) { send('fejl', { besked: e.message }); }
    })();
    return { ok: true, enheder: valgte.length };
  },

  // ---- Fælles kørselslog (28/9) ----
  // Hver færdig krib skrives som én JSON-linje i OneDrive, én fil pr. computer, så stationær,
  // bærbar, Edge og Firefox samles ét sted. `node rapport.js` laver RAPPORT.txt af det hele.
  async 'POST /api/log'(body) {
    const post = { ...body, pc: PC, servertid: new Date().toISOString() };
    fs.appendFileSync(path.join(LOGMAPPE, `koersler-${PC}.jsonl`), JSON.stringify(post) + '\n');
    return { ok: true };
  },
  // Hvad er FÆRDIGT ifølge disk-loggen (alle PC'er)? Browserens hukommelse kan gå tabt ved et
  // nedbrud (Firefox 29/9), disken kan ikke. Nøgle = ciffertekst|sprog|KRIB@plads(1-baseret).
  async 'POST /api/gjort'(body) {
    const ud = {};
    for (const f of fs.readdirSync(LOGMAPPE).filter(f => /^koersler-.*\.jsonl$/.test(f)))
      for (const l of fs.readFileSync(path.join(LOGMAPPE, f), 'utf8').split(/\r?\n/)) {
        let x; try { x = JSON.parse(l); } catch (_) { continue; }
        if (!['intet', 'kriben passer', 'falsk træf', 'umulig', 'MULIG LØSNING'].includes(x.status)) continue;
        ud[x.ct + '|' + x.sprogmodel + '|' + x.krib + '@' + x.plads] = { tid: (x.tid || '').slice(0, 16), resultat: x.status + ' (disk-log, ' + x.pc + ')' };
      }
    return { ok: true, gjort: ud };
  },
  async 'POST /api/koe'(body) {          // hvad køen mangler lige nu (overskrives hver gang)
    const tekst = `# ${PC} · ${body.browser || ''} · ${new Date().toISOString()} · ${body.status || ''}\n` +
      (body.mangler || []).join('\n') + '\n';
    fs.writeFileSync(path.join(LOGMAPPE, `koe-${PC}.txt`), tekst);
    return { ok: true };
  },
};

const LOGMAPPE = process.env.ENIGMA_LOG ? (fs.mkdirSync(process.env.ENIGMA_LOG, { recursive: true }), process.env.ENIGMA_LOG) : (() => {
  const od = path.join(os.homedir(), 'OneDrive', 'Dokumenter', 'enigma-log');
  const m = fs.existsSync(path.dirname(od)) ? od : path.join(ROD, 'enigma-log');
  fs.mkdirSync(m, { recursive: true });
  return m;
})();

const STATISK = {
  '/': ['web/index.html', 'text/html; charset=utf-8'],
  '/enigma.js': ['enigma.js', 'text/javascript; charset=utf-8'],
  '/gpu-test.html': ['web/gpu-test.html', 'text/html; charset=utf-8'],
  '/gpu.html': ['web/gpu.html', 'text/html; charset=utf-8'],
  '/gpu-v2.html': ['web/gpu-v2.html', 'text/html; charset=utf-8'],
  '/gpu-kerne-v2.js': ['web/gpu-kerne-v2.js', 'text/javascript; charset=utf-8'],
  '/gpu-v3.html': ['web/gpu-v3.html', 'text/html; charset=utf-8'],
  '/gpu-kerne-v3.js': ['web/gpu-kerne-v3.js', 'text/javascript; charset=utf-8'],
  '/gpu-kerne-v4.js': ['web/gpu-kerne-v4.js', 'text/javascript; charset=utf-8'],
  '/gpu-kerne-v5.js': ['web/gpu-kerne-v5.js', 'text/javascript; charset=utf-8'],
  '/gpu-test2.html': ['web/gpu-test2.html', 'text/html; charset=utf-8'],
  '/gpu-facit2.json': ['web/gpu-facit2.json', 'application/json; charset=utf-8'],
  '/gpu-kerne.js': ['web/gpu-kerne.js', 'text/javascript; charset=utf-8'],
  '/gpu-facit.json': ['web/gpu-facit.json', 'application/json; charset=utf-8'],
};

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://x');
  const nøgle = req.method + ' ' + u.pathname;

  if (req.method === 'GET' && STATISK[u.pathname]) {
    const [fil, type] = STATISK[u.pathname];
    const b = fs.readFileSync(path.join(ROD, fil));
    res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store' });
    return res.end(b);
  }
  if (nøgle === 'GET /api/info') {
    return json(res, 200, { kerner: os.cpus().length, cpu: (os.cpus()[0] || {}).model || 'ukendt' });
  }
  if (nøgle === 'GET /api/stream') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache', 'Connection': 'keep-alive', 'X-Accel-Buffering': 'no',
    });
    res.write(': forbundet\n\n');
    strømme.add(res);
    const ping = setInterval(() => { try { res.write(': ping\n\n'); } catch (_) { } }, 20000);
    req.on('close', () => { clearInterval(ping); strømme.delete(res); });
    return;
  }
  if (RUTER[nøgle]) {
    try {
      const body = req.method === 'POST' ? await læsBody(req) : {};
      return json(res, 200, await RUTER[nøgle](body));
    } catch (e) {
      return json(res, 200, { ok: false, fejl: e.message });
    }
  }
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Ikke fundet');
});

// --side gpu.html aabner kodeknaekkeren i stedet for maskinen
const sideIdx = process.argv.indexOf('--side');
const SIDE = sideIdx >= 0 ? (process.argv[sideIdx + 1] || '') : '';

function start(port, forsøg) {
  server.once('error', e => {
    if (e.code === 'EADDRINUSE' && forsøg < 12) return start(port + 1, forsøg + 1);
    console.error('Kunne ikke starte serveren:', e.message);
    process.exit(1);
  });
  server.listen(port, '127.0.0.1', () => {
    const url = `http://localhost:${port}`;
    console.log('\n  Kodeknækkeren:   ' + url + '/gpu.html   ·   V2: ' + url + '/gpu-v2.html   ·   V3 (hurtigst): ' + url + '/gpu-v3.html');
    console.log('  Enigma-maskinen: ' + url + '/');
    console.log('  Kørselslog:      ' + LOGMAPPE);
    console.log('  ' + os.cpus().length + ' kerner klar (' + ((os.cpus()[0] || {}).model || '').trim() + ')');
    console.log('\n  Luk dette vindue for at stoppe.\n');
    if (!process.argv.includes('--ingen-browser')) exec(`start "" "${url}/${SIDE}"`, () => { });
  });
}
start(parseInt(process.env.PORT) || 7777, 0);

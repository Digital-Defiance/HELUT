'use strict';
// V5-varianter mod facit-node.json (samme 10 jobs som test-node.js) + fartmåling mod V4.
//   node sky/test-v5.js [backend] [--fart]
const fs = require('fs'), path = require('path'), vm = require('vm'), crypto = require('crypto');
const E = require('../enigma.js');
const { menuInfo, byggEnheder } = require('../solver.js');
const ROD = path.join(__dirname, '..'), WEB = path.join(ROD, 'web');
const D0 = JSON.parse(fs.readFileSync(path.join(ROD, 'forsøg-opgaver.json'), 'utf8'));
const P680 = fs.readFileSync(path.join(ROD, 'u534.txt'), 'utf8').replace(/[^A-Z]/g, '');
const ALLE = byggEnheder({ model: 'M4', rotorer: E.M4_ROTORER, reflektorer: ['Bt', 'Ct'], græske: E.GRÆSKE }).enheder;
function job(ct, krib, D, fra, antal) {
  const L = Math.min(krib.length, 26), cr = [], cic = [];
  for (let i = 0; i < L; i++) { cr.push(krib[i] === '?' ? 99 : krib.charCodeAt(i) - 65); cic.push(ct.charCodeAt(D + i) - 65); }
  const m = menuInfo(krib, ct.slice(D), L);
  return { ok: true, L, D, frø: m.frø, cr, cic, fra,
    enheder: ALLE.slice(fra, fra + antal).map(e => ({ rot: e.rot, refl: e.refl, græsk: e.græsk || null, græskPos: e.græskPos | 0 })) };
}
const JOBS = [
  ['facit2 (kendt nøgle)', () => job(D0.CT, 'EINSTELLENXSCHLUE', 28, 15735, 400)],
  ['svag krib, mange stop', () => job(P680, 'UUUFUNFDREIVIE', 0, 0, 250)],
  ['svag krib, midt', () => job(P680, 'UUUFUNFDREIVIE', 0, 17000, 250)],
  ['svag krib, slutningen', () => job(P680, 'UUUFUNFDREIVIE', 0, 34700, 244)],
  ['slut-krib 18 bogst @50', () => job(P680, 'VVVUUUZWODREISECHS', 49, 5000, 300)],
  ['todelt med 10 ?', () => job(P680, 'UUUEINSEIN??????????EISELEKKXX', 20, 9000, 300)],
  ['26 bogst + joker', () => job(P680, 'KOMX?DMXUUUBOOTEYFDUUUAUSB', 0, 20000, 300)],
  ['12 bogst (svag)', () => job(P680, 'UUUVIRSIBENN', 0, 30000, 12)],
  ['overløb (svag, lille stopbuffer)', () => job(P680, 'UUUFUNFDREIVIE', 0, 100, 60), 5],
  ['facit-tekst @29 17 bogst', () => job(D0.CT, 'EINSTELLENXSCHLUE', 28, 15835, 200)],
];
const aftryk = r => crypto.createHash('sha256').update(r.stop.map(s => s.join(',')).sort().join(';') + '#' + r.mangler).digest('hex').slice(0, 16);
(async () => {
  const backend = process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : '';
  const { create, globals } = await import('webgpu');
  Object.assign(globalThis, globals);
  const gpu = create(backend ? ['backend=' + backend] : []);
  Object.defineProperty(globalThis, 'navigator', { value: { gpu, userAgent: 'node' }, configurable: true, writable: true });
  globalThis.window = globalThis; globalThis.Enigma = E;
  for (const f of ['gpu-kerne.js', 'gpu-kerne-v3.js', 'gpu-kerne-v4.js', 'gpu-kerne-v5.js'])
    vm.runInThisContext(fs.readFileSync(path.join(WEB, f), 'utf8').replace(/^'use strict';/, ''), { filename: f });
  const facit = JSON.parse(fs.readFileSync(path.join(__dirname, 'facit-node.json'), 'utf8'));
  const g4 = await gpuOpsætningV4();
  const VAR = [['STANDARD', {}], ['split', { splitRR: true, cache: false }], ['samlet', { splitRR: false, cache: false }], ['samlet+cache', { splitRR: false, cache: true }]];
  const g5 = []; for (const [n, v] of VAR) g5.push([n, await gpuOpsætningV5(v)]);
  console.log('GPU: ' + g5[0][1].navn);
  let ok = true;
  for (const [navn, lav, maks] of JOBS) {
    const j = lav(); const ud = [];
    for (const [vn, g] of g5) { const r = await gpuScanV5(g, j, null, null, maks); const a5 = aftryk(r); const b = a5 === facit[navn]; if (!b) ok = false; ud.push(`${vn} ${b ? 'OK' : 'FEJL ' + a5}`); }
    console.log(`${ud.every(x => / OK$/.test(x)) ? 'OK  ' : 'FEJL'}  ${navn}: ${ud.join(' · ')}`);
  }
  console.log(ok ? 'V5 (ALLE VARIANTER) BIT-IDENTISK MED FACIT' : 'NOGET FEJLEDE');
  if (ok && process.argv.includes('--fart')) {
    const n = 1500;
    for (const [navn, k, d] of [['stærk 26', 'KOMX?DMXUUUBOOTEYFDUUUAUSB', 0], ['18 bogst', 'VVVUUUZWODREISECHS', 49], ['todelt ?', 'LEITUNGVO?????????EUNXUUUFLO', 0], ['svag 14', 'UUUFUNFDREIVIE', 0], ['AO 13', 'AAAOOOACHTZWO', 24]]) {
      const j = job(P680, k, d, 12000, n);
      await gpuScanV4(g4, j); const r4 = await gpuScanV4(g4, j);
      const ud = [`V4 ${(n / r4.sekunder).toFixed(0)}`];
      for (const [vn, g] of g5) { await gpuScanV5(g, j); const r = await gpuScanV5(g, j); ud.push(`${vn} ${(n / r.sekunder).toFixed(0)}`); }
      console.log(`fart ${navn}: ${ud.join(' · ')} enh/s`);
    }
  }
  process.exit(ok ? 0 : 1);
})().catch(e => { console.error('FEJL', e.stack || e); process.exit(1); });

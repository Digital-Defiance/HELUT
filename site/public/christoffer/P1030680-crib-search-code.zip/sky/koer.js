'use strict';
// Kø-kører uden browser: præcis samme arbejdsgang som web/gpu-v3.html, bare i Node.
//   GPU (V3-kernen via Dawn) -> ui.js /api/gpu/faerdig (CPU-efterbehandling) -> fundregel -> /api/log
// Serveren (ui.js) startes som barneproces med egen logmappe og eget maskinnavn.
// Køfilen læses igen før HVER krib (styringen på stationæren fylder på undervejs).
// Står der en linje '#SLUT' i køfilen og er alt kørt, afsluttes kørslen.
//
//   ENIGMA_PC=vast1 node koer.js --koe koe.txt [--log mappe] [--sprog ubaad] [--backend vulkan]
const fs = require('fs'), path = require('path'), http = require('http'), { spawn } = require('child_process');
const { indlæs } = require('./gpu-node.js');
const E = require('../enigma.js');

const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i >= 0 ? process.argv[i + 1] : d; };
const ROD = path.join(__dirname, '..');
const KØFIL = path.resolve(arg('koe', path.join(__dirname, 'koe.txt')));
const LOG = path.resolve(arg('log', path.join(__dirname, 'log')));
const PC = process.env.ENIGMA_PC || require('os').hostname();
const SPROG = arg('sprog', 'ubaad'), MODEL = arg('model', 'M4');
const CT = E.rens(arg('ct', fs.readFileSync(path.join(ROD, 'u534.txt'), 'utf8')));
const PORT = +arg('port', 7801);
fs.mkdirSync(LOG, { recursive: true });

const tidsstempel = () => new Date().toISOString();
const DAGBOG = path.join(LOG, `dagbog-${PC}.txt`);           // alt hvad køreren laver, linje for linje
// 4/10: fremdriftslinje i cmd-vinduet (overskrives med \r); ryddes før almindelige linjer
let fremLinje = false;
const ryd = () => { if (fremLinje) { process.stdout.write('\r' + ' '.repeat(118) + '\r'); fremLinje = false; } };
const skriv = t => { const l = `${tidsstempel()} ${t}`; ryd(); console.log(l); fs.appendFileSync(DAGBOG, l + '\n'); };
const mmss = s => { s = Math.max(0, Math.round(s)); const h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60, x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };
let køInfo = { rest: 0 };
function fremdrift(op, gjort, ialt, stop, sek) {
  const andel = ialt ? gjort / ialt : 0, fart = sek > 0 ? gjort / sek : 0;
  const bar = '#'.repeat(Math.round(andel * 20)).padEnd(20, '-');
  const navn = op.krib.length > 26 ? op.krib.slice(0, 24) + '..' : op.krib;
  const l = `  [${bar}] ${(100 * andel).toFixed(0).padStart(3)} % · ${fart.toFixed(0).padStart(4)} enh/s · ${mmss(fart ? (ialt - gjort) / fart : 0)} tilbage · ${stop} stop · ${navn} @${op.plads + 1} · ${køInfo.rest} i køen`;
  process.stdout.write('\r' + l.slice(0, 118).padEnd(118)); fremLinje = true;
}

// ---------- serveren ----------
let base = null;
function startServer() {
  return new Promise((ok, fejl) => {
    const b = spawn(process.execPath, [path.join(ROD, 'ui.js'), '--ingen-browser'],
      { env: { ...process.env, PORT: String(PORT), ENIGMA_LOG: LOG, ENIGMA_PC: PC }, stdio: ['ignore', 'pipe', 'pipe'] });
    b.stdout.on('data', d => { const m = String(d).match(/http:\/\/localhost:(\d+)/); if (m && !base) { base = `http://127.0.0.1:${m[1]}`; ok(b); } });
    b.stderr.on('data', d => fs.appendFileSync(DAGBOG, '[server] ' + d));
    b.on('exit', k => { skriv(`server stoppede (${k}) - afslutter så løkken genstarter alt`); process.exit(3); });
    setTimeout(() => fejl(new Error('serveren startede ikke')), 30000);
  });
}
function post(sti, body) {
  return new Promise((ok, fejl) => {
    const data = Buffer.from(JSON.stringify(body));
    const r = http.request(base + sti, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': data.length } }, res => {
      let s = ''; res.setEncoding('utf8'); res.on('data', c => s += c); res.on('end', () => { try { ok(JSON.parse(s)); } catch (e) { fejl(e); } });
    });
    r.on('error', fejl); r.end(data);
  });
}
let ventPå = null;
function lyt() {
  http.get(base + '/api/stream', res => {
    let buf = ''; res.setEncoding('utf8');
    res.on('data', c => {
      buf += c; let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const blok = buf.slice(0, i); buf = buf.slice(i + 2);
        const l = blok.split('\n').find(x => x.startsWith('data: ')); if (!l) continue;
        const d = JSON.parse(l.slice(6));
        if (d.type === 'fejl' && ventPå) { const f = ventPå; ventPå = null; f({ fejl: d.besked }); }
        if (d.type === 'faerdig' && ventPå) { const f = ventPå; ventPå = null; f(d); }
      }
    });
    res.on('end', () => { skriv('SSE lukket'); process.exit(3); });
  });
}

// ---------- fundreglen: ordret fra gpu-v3.html ----------
function jokerPlads(op) { for (let i = 0; i < op.krib.length; i++) if (op.krib[i] === CT[op.plads + i]) return i; return -1; }
function kendte(op) { const j = jokerPlads(op); let n = 0; for (let i = 0; i < op.krib.length; i++) if (i !== j && op.krib[i] !== '?') n++; return n; }
function kribFejl(op, tekst) { const j = jokerPlads(op); let n = 0; for (let i = 0; i < op.krib.length; i++) if (i !== j && op.krib[i] !== '?' && tekst[op.plads + i] !== op.krib[i]) n++; return n; }
function sprogScore(op, f) { return f.score - 18 * (kendte(op) - kribFejl(op, f.tekst)); }
const GRÆNSER = { tysk: { sprog: -700, vindue: -8.0 }, ubaad: { sprog: -660, vindue: -7.8 } };
const grænse = (stop) => {
  const g = GRÆNSER[SPROG] || GRÆNSER.tysk;
  const tiere = Math.max(0, Math.log10(Math.max(1, stop || 0) / 7500));
  return { sprog: g.sprog + 13 * tiere + (tiere > 0 ? 10 : 0), vindue: g.vindue + 0.45 * tiere };
};

let g = null;
function logDisk(op, status, s, ekstra) {
  // Som siden, men ALLE kandidater gemmes (ikke kun de 3 bedste) - der er ingen grund til at smide noget væk.
  const fund = (s && s.fund || []).map(f => ({ fejl: kribFejl(op, f.tekst), sprog: Math.round(sprogScore(op, f)),
      vindue: f.vindue == null ? null : +f.vindue.toFixed(2), score: +f.score.toFixed(1), tekst: f.tekst,
      nøgle: `${f.model} ${f.rotorer.join('-')} ${f.græsk ? f.græsk + '@' + f.græskPos + ' ' : ''}${f.reflektorNavn} ring ${f.ring} pos ${f.pos} plug ${f.plug || '-'}` }))
    .sort((a, b) => a.fejl - b.fejl || b.sprog - a.sprog);
  return post('/api/log', { tid: tidsstempel(), browser: 'node', gpu: g ? g.navn : '', krib: op.krib, plads: op.plads + 1,
    status, version: KERNE + '-node', stop: s ? s.stop : null, mangler: s ? (s.mangler || 0) : null, gpuSek: s && s.gpuSek ? Math.round(s.gpuSek) : null,
    cpuSek: s && s.cpuSek != null ? Math.round(s.cpuSek) : null, enhPrS: s && s.gpuSek ? +(34944 / s.gpuSek).toFixed(1) : null,
    grænse: s && s.stop != null ? grænse(s.stop) : null, sprogmodel: SPROG, ct: CT, fund, ...(ekstra || {}) }).catch(e => skriv('LOG-FEJL ' + e.message));
}

function læsKø() {
  let t = ''; try { t = fs.readFileSync(KØFIL, 'utf8'); } catch (_) { }
  const slut = /^#SLUT/m.test(t);
  const ops = t.split(/\r?\n/).map(l => l.replace(/#.*/, '').trim()).filter(Boolean)
    // '!' foran = kør igen selv om den står som færdig (fx efter en rettelse i solveren, 30/9)
    .map(l => { const m = l.match(/^(!?)(\S+)\s*(?:@\s*(\d+))?$/); return m ? { krib: m[2].toUpperCase(), plads: parseInt(m[3] || '1') - 1, tving: !!m[1] } : null; })
    .filter(Boolean);
  return { ops, slut };
}

const STATUS = path.join(LOG, `status-${PC}.json`);
function status(o) { try { fs.writeFileSync(STATUS, JSON.stringify({ pc: PC, tid: tidsstempel(), gpu: g && g.navn, ...o })); } catch (_) { } }

// 4/10: V4 = V3 + Turings løkke-test; V5 = V4 + trin-tabel, løkke-cache og Q-cache (alle bit-identiske med facit).
// ENIGMA_KERNE=V4 eller V3 skifter tilbage.
const KERNE = (process.env.ENIGMA_KERNE || 'V5').toUpperCase();
async function kørEn(K, op) {
  const job = await post('/api/gpu/job', { ciffertekst: CT, krib: op.krib, kribPlads: op.plads, model: MODEL, sprog: SPROG });
  if (!job.ok) return { fejl: job.fejl, umulig: true };   // afvist af job-byggeren (menu/kollisioner)
  let sidst = 0;
  let sidstSkærm = 0;
  const r = await K['gpuScan' + KERNE](g, job, (gjort, ialt, stop, sek) => {
    if (Date.now() - sidstSkærm >= 1000) { sidstSkærm = Date.now(); fremdrift(op, gjort, ialt, stop, sek); }
    if (Date.now() - sidst < 5000) return; sidst = Date.now();
    status({ krib: op.krib, plads: op.plads + 1, gjort, ialt, stop, sek: Math.round(sek), enhPrS: +(gjort / sek).toFixed(1) });
  });
  const ramte = [...new Set(r.stop.map(s => s[0]))].sort((a, b) => a - b);
  const t1 = Date.now();
  const svar = await new Promise(res => {
    ventPå = res;
    post('/api/gpu/faerdig', { enheder: ramte, stop: r.stop.flat(), gpuSekunder: r.sekunder, løkker: job.løkker })
      .then(x => { if (!x.ok && ventPå) { ventPå = null; res({ fejl: x.fejl }); } }).catch(e => { ventPå = null; res({ fejl: e.message }); });
  });
  return { ...svar, gpuSek: r.sekunder, cpuSek: (Date.now() - t1) / 1000, stop: r.stop.length, overløb: r.overløb, mangler: r.mangler || 0 };
}

(async () => {
  const K = await indlæs(arg('backend', ''));
  g = await K['gpuOpsætning' + KERNE]();
  await startServer(); lyt();
  skriv(`start · ${PC} · ${g.navn} · kø ${KØFIL} · log ${LOG}`);
  const behandlet = new Set();
  let tomSiden = 0;
  for (;;) {
    const gjort = (await post('/api/gjort', {})).gjort || {};
    const { ops, slut } = læsKø();
    const op = ops.find(o => !behandlet.has(o.krib + '@' + o.plads));
    const rest = ops.filter(o => !behandlet.has(o.krib + '@' + o.plads));
    køInfo.rest = Math.max(0, rest.filter(o => o.tving || !gjort[CT + '|' + SPROG + '|' + o.krib + '@' + (o.plads + 1)]).length - 1);
    await post('/api/koe', { browser: 'node', status: op ? 'kører ' + op.krib + ' @' + (op.plads + 1) : (slut ? 'færdig' : 'venter på flere krib'),
      mangler: rest.map(o => o.krib + ' @' + (o.plads + 1)) });
    if (!op) {
      if (slut) { skriv('køen er tom og #SLUT - færdig'); status({ færdig: true }); fs.writeFileSync(path.join(LOG, `FAERDIG-${PC}`), tidsstempel()); break; }
      if (!tomSiden) { tomSiden = Date.now(); skriv('venter på flere krib…'); status({ venter: true }); }
      await new Promise(r => setTimeout(r, 5000)); continue;
    }
    tomSiden = 0;
    behandlet.add(op.krib + '@' + op.plads);
    const tidligere = gjort[CT + '|' + SPROG + '|' + op.krib + '@' + (op.plads + 1)];
    if (tidligere && !op.tving && !/delvis/.test(tidligere.resultat)) { skriv(`spring over ${op.krib} @${op.plads + 1} (${tidligere.resultat})`); continue; }
    skriv(`kører ${op.krib} @${op.plads + 1}`);
    let s;
    try { s = await kørEn(K, op); }
    catch (e) { skriv(`FEJL ${op.krib} @${op.plads + 1}: ${e.stack || e}`); await logDisk(op, 'fejl', null, { besked: String(e && e.message || e) }); continue; }
    // 30/9 (Astra 6): kun job-byggerens afvisning er 'umulig'; en CPU-/serverfejl er 'fejl' og køres igen senere
    if (s.fejl) { const st = s.umulig ? 'umulig' : 'fejl'; skriv(`${st} ${op.krib} @${op.plads + 1}: ${s.fejl}`); await logDisk(op, st, null, { besked: s.fejl }); continue; }
    const tid = `${(s.gpuSek || 0).toFixed(0)} s GPU + ${(s.cpuSek || 0).toFixed(0)} s CPU` + (s.mangler ? ` · DELVIS: ${s.mangler} enheder ikke søgt` : '');
    if (s.fund && s.fund.length) {
      const liste = s.fund.map(f => ({ tekst: f.tekst, fejl: kribFejl(op, f.tekst), sprog: sprogScore(op, f),
        vin: (f.vindue === undefined || f.vindue === null) ? -99 : f.vindue }));
      const ægteK = liste.find(x => x.fejl <= 1 && (x.sprog > grænse(s.stop).sprog || x.vin > grænse(s.stop).vindue));
      const k = ægteK || liste.sort((a, b) => a.fejl - b.fejl || b.sprog - a.sprog)[0];
      // 30/9 (Astra 6): en DELVIS kørsel er aldrig færdig, heller ikke når den giver en alarm (alarm gemmes i feltet 'alarm')
      const st = s.mangler ? 'delvis' : ægteK ? 'MULIG LØSNING' : k.fejl <= 1 ? 'kriben passer' : 'falsk træf';
      skriv(`${ægteK ? '*** MULIG LØSNING *** ' : ''}${st} ${op.krib} @${op.plads + 1} · ${s.fund.length} kandidat(er) af ${s.stop} stop · ${k.fejl} kribfejl · sprog ${k.sprog.toFixed(0)} · strækning ${k.vin.toFixed(1)} · ${tid} · ${k.tekst}`);
      await logDisk(op, st, s, { alarm: !!ægteK });
      // 6/10: alarm til telefonen (ntfy/WhatsApp) - kun den rigtige kø, ikke selvtest/målinger; blokerer aldrig
      if (ægteK && PC === 'Duif-node') try {
        spawn(process.execPath, [path.join(__dirname, 'alarm.js'), `MULIG LØSNING: ${op.krib} @${op.plads + 1} · sprog ${k.sprog.toFixed(0)} · ${k.tekst}`, '--vigtig'], { stdio: 'ignore', detached: true }).unref();
      } catch (_) { }
    } else {
      skriv(`intet ${op.krib} @${op.plads + 1} · ${s.stop} stop · ${tid}`);
      await logDisk(op, s.mangler ? 'delvis' : 'intet', s);
    }
  }
  process.exit(0);
})().catch(e => { skriv('KRAK ' + (e.stack || e)); process.exit(2); });

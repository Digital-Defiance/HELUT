'use strict';
// 5/10: FINDER KÆDEN NØGLEN MED KORTE KRIB? Kunstige beskeder: ægte korpus-klartekst (72 bogst.), tilfældig M4-nøgle,
// krib = et udsnit af klarteksten på en tilfældig plads. Kører hele kæden (koer.js -> V5 -> CPU-solver -> fundregel).
// Måler om resultatet bliver "MULIG LØSNING" - eller om den rigtige nøgle ender som "kriben passer" med dårlig score
// (= vi kunne have "stirret direkte på løsningen").
// Kør: node sky/maal-korte.js [antal pr. længde=3] [længder=13,15,18]
const fs = require('fs'), path = require('path'), os = require('os'), { spawn } = require('child_process');
const E = require('../enigma.js');
const { menuInfo } = require('../solver.js');
const ANTAL = +(process.argv[2] || 3);
const LÆNGDER = (process.argv[3] || '13,15,18').split(',').map(Number);
const PORT = 7897, rnd = n => Math.floor(Math.random() * n);
const korpus = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'u534_corpus.json'), 'utf8')).messages
  .map(x => E.rens(x.plaintext || '')).filter(t => t.length >= 72 && !/KBTACHS/.test(t)).map(t => t.slice(0, 72));
function nøgle() {
  const rot = []; while (rot.length < 3) { const r = E.M4_ROTORER[rnd(8)]; if (!rot.includes(r)) rot.push(r); }
  const b = [...Array(26).keys()].sort(() => Math.random() - 0.5), par = []; for (let i = 0; i < 20; i += 2) par.push(E.A[b[i]] + E.A[b[i + 1]]);
  return { rot, græsk: ['Beta', 'Gamma'][rnd(2)], refl: ['Bt', 'Ct'][rnd(2)], gPos: rnd(26), gRing: rnd(26), ringe: [rnd(26), rnd(26), rnd(26)], pos: [rnd(26), rnd(26), rnd(26)], plugs: par.join(' ') };
}
const krypter = (k, t) => E.kør(E.maskine(k.rot, k.ringe, k.pos, k.refl, { græsk: k.græsk, pos: k.gPos, ring: k.gRing }), t, E.plugFraPar(k.plugs));
const stærk = m => (m.frøKanter >= 15 && m.frøLøkker >= 1) || (m.frøKanter >= 13 && m.frøLøkker >= 2) || (m.frøKanter >= 12 && m.frøLøkker >= 3);
function kør(ct, linje) {
  const mappe = fs.mkdtempSync(path.join(os.tmpdir(), 'enigma-maal-')), køfil = path.join(mappe, 'koe.txt');
  fs.writeFileSync(køfil, linje + '\n#SLUT\n');
  return new Promise(res => {
    const p = spawn(process.execPath, [path.join(__dirname, 'koer.js'), '--koe', køfil, '--log', mappe, '--port', String(PORT), '--ct', ct],
      { env: { ...process.env, ENIGMA_PC: 'maal' }, stdio: 'ignore' });
    const vagt = setTimeout(() => p.kill(), 20 * 60e3);
    p.on('exit', () => { clearTimeout(vagt); let r = null; try { r = JSON.parse(fs.readFileSync(path.join(mappe, 'koersler-maal.jsonl'), 'utf8').trim().split(/\r?\n/)[0]); } catch (_) { }
      try { fs.rmSync(mappe, { recursive: true, force: true }); } catch (_) { } res(r); });
  });
}
(async () => {
  const res = {};
  for (const n of LÆNGDER) for (let t = 0; t < ANTAL; t++) {
    const klar = korpus[rnd(korpus.length)], k = nøgle(), ct = krypter(k, klar);
    let p = -1, m = null;                                   // plads med en menu der ville komme i køen (samme krav som byg-*.js)
    for (let f = 0; f < 200 && p < 0; f++) { const q = rnd(72 - n); const mm = menuInfo(klar.slice(q, q + n), ct.slice(q), n); if (stærk(mm)) { p = q; m = mm; } }
    if (p < 0) { console.log(`${n} bogst: ingen stærk nok plads fundet - springes over`); continue; }
    const krib = klar.slice(p, p + n), t0 = Date.now();
    const r = await kør(ct, `${krib} @${p + 1}`);
    const b = r && (r.fund || [])[0]; let rigtige = 0; if (b && b.tekst) for (let i = 0; i < 72; i++) if (b.tekst[i] === klar[i]) rigtige++;
    const fundet = r && r.status === 'MULIG LØSNING' && rigtige >= 66;
    (res[n] = res[n] || []).push(fundet);
    console.log(`${n} bogst @${String(p + 1).padEnd(3)} ${m.frøKanter} kanter/${m.frøLøkker} løkker: ${fundet ? 'FUNDET ' : 'MISSET '} ${r ? r.status : 'ingen log'}` +
      `${b ? ` · sprog ${b.sprog} · ${rigtige}/72 rigtige` : ''} · ${r ? r.stop + ' stop' : ''} · ${Math.round((Date.now() - t0) / 1000)} s · ${krib}`);
  }
  for (const n of Object.keys(res)) console.log(`${n} bogstaver: ${res[n].filter(Boolean).length}/${res[n].length} fundet`);
  process.exit(0);
})();

'use strict';
// Fartmåling af V5-varianter: node sky/bench-v5.js '<variant-json>' ...
const fs = require('fs'), path = require('path'), vm = require('vm');
const E = require('../enigma.js');
const { menuInfo, byggEnheder } = require('../solver.js');
const ROD = path.join(__dirname, '..'), WEB = path.join(ROD, 'web');
const P680 = fs.readFileSync(path.join(ROD, 'u534.txt'), 'utf8').replace(/[^A-Z]/g, '');
const ALLE = byggEnheder({ model: 'M4', rotorer: E.M4_ROTORER, reflektorer: ['Bt', 'Ct'], græske: E.GRÆSKE }).enheder;
function job(krib, D, fra, n) {
  const L = Math.min(krib.length, 26), cr = [], cic = [];
  for (let i = 0; i < L; i++) { cr.push(krib[i] === '?' ? 99 : krib.charCodeAt(i) - 65); cic.push(P680.charCodeAt(D + i) - 65); }
  return { L, D, frø: menuInfo(krib, P680.slice(D), L).frø, cr, cic, enheder: ALLE.slice(fra, fra + n).map(e => ({ rot: e.rot, refl: e.refl, græsk: e.græsk || null, græskPos: e.græskPos | 0 })) };
}
(async () => {
  const { create, globals } = await import('webgpu');
  Object.assign(globalThis, globals);
  Object.defineProperty(globalThis, 'navigator', { value: { gpu: create([]), userAgent: 'node' }, configurable: true, writable: true });
  globalThis.window = globalThis; globalThis.Enigma = E;
  for (const f of ['gpu-kerne.js', 'gpu-kerne-v5.js']) vm.runInThisContext(fs.readFileSync(path.join(WEB, f), 'utf8').replace(/^'use strict';/, ''));
  for (const a of process.argv.slice(2)) {
    const g = await gpuOpsætningV5(JSON.parse(a)); const n = 1500, ud = [];
    for (const [navn, k, d] of [['26', 'KOMX?DMXUUUBOOTEYFDUUUAUSB', 0], ['18', 'VVVUUUZWODREISECHS', 49], ['todelt', 'LEITUNGVO?????????EUNXUUUFLO', 0], ['14', 'UUUFUNFDREIVIE', 0], ['AO13', 'AAAOOOACHTZWO', 24]]) {
      const j = job(k, d, 12000, n); await gpuScanV5(g, j); const r = await gpuScanV5(g, j); ud.push(`${navn}: ${(n / r.sekunder).toFixed(0)}`);
    }
    console.log(a.padEnd(60), ud.join(' · '), 'enh/s');
  }
  process.exit(0);
})().catch(e => { console.error(e.stack || e); process.exit(1); });

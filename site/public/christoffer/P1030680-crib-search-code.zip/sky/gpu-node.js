'use strict';
// Kører den UÆNDREDE browser-kerne (web/gpu-kerne-v3.js) i Node via Dawn (npm 'webgpu').
// Samme WGSL, samme værtskode - kun "browseren" er skiftet ud. Bruges på lejede GPU'er (Linux/Vulkan).
const fs = require('fs'), path = require('path'), vm = require('vm');
const WEB = path.join(__dirname, '..', 'web');

async function indlæs(backend) {
  const { create, globals } = await import('webgpu');
  Object.assign(globalThis, globals);
  const gpu = create(backend ? ['backend=' + backend] : []);
  Object.defineProperty(globalThis, 'navigator', { value: { gpu, userAgent: 'node' }, configurable: true, writable: true });
  globalThis.window = globalThis;
  if (process.env.ENIGMA_MAAL_MS) globalThis.ENIGMA_MAAL_MS = +process.env.ENIGMA_MAAL_MS;
  globalThis.Enigma = require('../enigma.js');
  // gpuByggQ bor i V1-kernen; resten af filerne er rene funktionserklæringer
  for (const f of ['gpu-kerne.js', 'gpu-kerne-v3.js', 'gpu-kerne-v4.js', 'gpu-kerne-v5.js'])
    vm.runInThisContext(fs.readFileSync(path.join(WEB, f), 'utf8').replace(/^'use strict';/, ''), { filename: f });
  return {
    gpuOpsætningV3: globalThis.gpuOpsætningV3, gpuScanV3: globalThis.gpuScanV3,
    gpuOpsætningV4: globalThis.gpuOpsætningV4, gpuScanV4: globalThis.gpuScanV4,
    gpuOpsætningV5: globalThis.gpuOpsætningV5, gpuScanV5: globalThis.gpuScanV5,
    gpuOpsætning: globalThis.gpuOpsætning, gpuScan: globalThis.gpuScan,
  };
}
module.exports = { indlæs };

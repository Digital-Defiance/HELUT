'use strict';
// 5/10: SELVTEST AF HELE KÆDEN - "virker værktøjet stadig?". Laver kunstige M-Thetis-lignende beskeder med en
// TILFÆLDIG M4-nøgle og kører dem gennem præcis den samme vej som den rigtige kø:
//   koer.js (V5-kernen via Dawn) -> ui.js /api/gpu/faerdig (CPU-solver) -> fundregel -> log.
// Bestået = loggen siger "MULIG LØSNING" og den bedste kandidat dekrypterer til den rigtige klartekst.
//   T1: ren besked, krib forrest (26 bogst.)
//   T2: én hørefejl i kriben UDEN FOR GPU-vinduet (fejltolerancen fra 30/9)
//   T3: én hørefejl i beskeden uden for kriben + krib med maskeret blok (perfektions-motorens type)
// Kør:  node sky/selvtest.js [--port 7898]     (exit 0 = alt bestået). Egen logmappe i %TEMP%, rører ikke kø/log.
//       --dagligt: spring over hvis selvtesten allerede er bestået i dag (start-koe-node.bat bruger det).
// Resultatet skrives altid i enigma-log/selvtest.txt.
const fs = require('fs'), path = require('path'), os = require('os'), { spawn } = require('child_process');
const E = require('../enigma.js');
const { menuInfo } = require('../solver.js');
const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i >= 0 ? process.argv[i + 1] : d; };
const PORT = +arg('port', 7898);
const KLAR = 'LEITUNGVONVONZWOSIBENXUUUFLOTTXXUEBUNGABGEBROCHENXALLEBOOTESOFORTEINLAUFENXX'.slice(0, 72);
const rnd = n => Math.floor(Math.random() * n);

function tilfældigNøgle() {
  const rot = []; while (rot.length < 3) { const r = E.M4_ROTORER[rnd(8)]; if (!rot.includes(r)) rot.push(r); }
  const bogst = [...Array(26).keys()].sort(() => Math.random() - 0.5), par = [];
  for (let i = 0; i < 20; i += 2) par.push(E.A[bogst[i]] + E.A[bogst[i + 1]]);
  return { rot, græsk: ['Beta', 'Gamma'][rnd(2)], refl: ['Bt', 'Ct'][rnd(2)], gPos: rnd(26), gRing: rnd(26),
    ringe: [rnd(26), rnd(26), rnd(26)], pos: [rnd(26), rnd(26), rnd(26)], plugs: par.join(' ') };
}
function krypter(k, tekst) {
  const M = E.maskine(k.rot, k.ringe, k.pos, k.refl, { græsk: k.græsk, pos: k.gPos, ring: k.gRing });
  return E.kør(M, tekst, E.plugFraPar(k.plugs));
}
// GPU-vinduet efter samme regel som ui.js
function vindue(krib, ct, D) {
  const L = Math.min(krib.length, 26); let w = 0, m = null;
  for (let x = 0; x + L <= krib.length; x++) { const mx = menuInfo(krib.slice(x), ct.slice(D + x), L); if (!m || mx.frøLøkker > m.frøLøkker || (mx.frøLøkker === m.frøLøkker && mx.frøKanter > m.frøKanter)) { m = mx; w = x; } }
  return { w, L, m };
}
const skift = (s, i) => s.slice(0, i) + E.A[(s.charCodeAt(i) - 65 + 1 + rnd(25)) % 26] + s.slice(i + 1);

function kørKoer(navn, ct, kø) {
  const mappe = fs.mkdtempSync(path.join(os.tmpdir(), 'enigma-selvtest-'));
  const køfil = path.join(mappe, 'koe.txt');
  fs.writeFileSync(køfil, kø.join('\n') + '\n#SLUT\n');
  return new Promise(res => {
    const p = spawn(process.execPath, [path.join(__dirname, 'koer.js'), '--koe', køfil, '--log', mappe, '--port', String(PORT), '--ct', ct],
      { env: { ...process.env, ENIGMA_PC: 'selvtest' }, stdio: ['ignore', 'ignore', 'pipe'] });
    let fejl = ''; p.stderr.on('data', d => { fejl += d; });
    const vagt = setTimeout(() => p.kill(), 15 * 60e3);
    p.on('exit', () => {
      clearTimeout(vagt);
      let linjer = []; try { linjer = fs.readFileSync(path.join(mappe, 'koersler-selvtest.jsonl'), 'utf8').trim().split(/\r?\n/).map(l => JSON.parse(l)); } catch (_) { }
      try { fs.rmSync(mappe, { recursive: true, force: true }); } catch (_) { }
      res({ linjer, fejl });
    });
  });
}

const LOGD = path.join(os.homedir(), 'OneDrive', 'Dokumenter', 'enigma-log');
const SPOR = path.join(LOGD, 'selvtest.txt');
const idag = new Date().toISOString().slice(0, 10);
const noter = t => { try { fs.appendFileSync(SPOR, new Date().toISOString() + ' ' + t + '\n'); } catch (_) { } };
(async () => {
  if (process.argv.includes('--dagligt')) {
    let tidl = ''; try { tidl = fs.readFileSync(SPOR, 'utf8'); } catch (_) { }
    if (tidl.split(/\r?\n/).some(l => l.startsWith(idag) && l.includes('SELVTEST BESTÅET'))) { console.log('Selvtest allerede bestået i dag - springes over.'); process.exit(0); }
    console.log('Daglig selvtest af hele kæden (ca. 1-3 min) ...');
  }
  const k = tilfældigNøgle();
  const ren = krypter(k, KLAR);
  console.log(`SELVTEST · tilfældig nøgle ${k.rot.join('-')} ${k.græsk} ${k.refl} · stik ${k.plugs}`);
  const prøver = [];
  // T1: ren besked, 26-bogstavs krib forrest
  prøver.push({ navn: 'T1 ren besked', ct: ren, krib: KLAR.slice(0, 26), plads: 1 });
  // T2: 34-bogstavs krib, én hørefejl i kriben uden for GPU-vinduet
  { const krib = KLAR.slice(0, 34); let ct = ren, e = -1;
    for (let forsøg = 0; forsøg < 50 && e < 0; forsøg++) {
      const v0 = vindue(krib, ren, 0); const uden = [...Array(34).keys()].filter(i => i < v0.w || i >= v0.w + v0.L);
      const i = uden[rnd(uden.length)]; const c2 = skift(ren, i); const v1 = vindue(krib, c2, 0);
      if ((i < v1.w || i >= v1.w + v1.L) && c2[i] !== krib[i]) { ct = c2; e = i; } }
    prøver.push({ navn: `T2 hørefejl i kriben (plads ${e + 1}, uden for vinduet)`, ct, krib, plads: 1 }); }
  // T3: hørefejl uden for kriben + krib med maskeret blok (som perfektions-motoren laver).
  // 6/10: blokken placeres hvor menuen stadig er stærk MED DENNE NØGLE (før: fast blok -> kunne blive for svag,
  // og så afviste job-byggeren den som "umulig" - det var testens fejl, ikke værktøjets).
  const stærk = m => (m.frøKanter >= 15 && m.frøLøkker >= 1) || (m.frøKanter >= 13 && m.frøLøkker >= 2) || (m.frøKanter >= 12 && m.frøLøkker >= 3);
  { const i = 40 + rnd(30); const ct = skift(ren, i);
    const mulige = [...Array(18).keys()].map(a => a + 3).map(a => KLAR.slice(0, a) + '?????' + KLAR.slice(a + 5, 30))
      .filter(kr => stærk(vindue(kr, ct, 0).m));
    if (mulige.length) prøver.push({ navn: `T3 hørefejl i beskeden (plads ${i + 1}) + maskeret krib`, ct, krib: mulige[rnd(mulige.length)], plads: 1 });
    else console.log('(T3 sprunget over: ingen maske med stærk menu med denne nøgle)'); }
  // T4 (5/10): KORT krib (14 bogst.) midt i beskeden - CPU'en skal selv finde de fleste stikpar
  { const pladser = [...Array(72 - 14).keys()].filter(q => stærk(menuInfo(KLAR.slice(q, q + 14), ren.slice(q), 14)));
    if (pladser.length) { const q = pladser[rnd(pladser.length)]; prøver.push({ navn: `T4 kort krib (14 bogst. @${q + 1})`, ct: ren, krib: KLAR.slice(q, q + 14), plads: q + 1 }); }
    else console.log('(T4 sprunget over: ingen stærk 14-bogstavs plads med denne nøgle)'); }

  let alleOK = true;
  for (const t of prøver) {
    const t0 = Date.now();
    const { linjer, fejl } = await kørKoer(t.navn, t.ct, [`${t.krib} @${t.plads}`]);
    const r = linjer.find(x => x.krib === t.krib);
    const bedst = r && (r.fund || [])[0];
    let rigtige = 0; if (bedst && bedst.tekst) for (let i = 0; i < 72; i++) if (bedst.tekst[i] === KLAR[i]) rigtige++;
    const ok = !!r && r.status === 'MULIG LØSNING' && rigtige >= 68;
    if (!ok) alleOK = false;
    noter(`${ok ? 'BESTÅET' : 'FEJLET '}  ${t.navn}: ${r ? r.status : 'ingen logpost'}${bedst ? ' · sprog ' + bedst.sprog + ' · ' + rigtige + '/72' : ''}`);
    console.log(`${ok ? 'BESTÅET' : 'FEJLET '}  ${t.navn}: ${r ? r.status : 'ingen logpost'}` +
      (bedst ? ` · sprog ${bedst.sprog} · ${rigtige}/72 rigtige bogstaver` : '') + ` · ${Math.round((Date.now() - t0) / 1000)} s` +
      (!r && fejl ? `\n         ${fejl.split('\n').slice(-3).join(' | ')}` : ''));
  }
  const slut = alleOK ? 'SELVTEST BESTÅET - hele kæden finder nøglen' : '!!! SELVTEST FEJLET - stol IKKE på kørslerne før det er undersøgt !!!';
  // hele nøglen gemmes, så en fejl kan genskabes
  noter(slut + ` (nøgle ${k.rot.join('-')} ${k.græsk}@${k.gPos}/${k.gRing} ${k.refl} ringe ${k.ringe} pos ${k.pos} stik ${k.plugs})`); console.log(slut);
  process.exit(alleOK ? 0 : 1);
})().catch(e => { console.error('SELVTEST-FEJL', e.stack || e); process.exit(2); });

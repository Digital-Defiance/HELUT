DEFE 3/577-579 - OCR text and dated index
Christoffer Duif, October 2026 (shared for the P1030680 research with Selm Merel Wenselaers and Jessica Mulein)

SOURCE
  The National Archives (Kew), DEFE 3/577, 3/578 and 3/579: Bletchley Park teleprinter translations (ZTPG series)
  of German naval signals, approx. 29 April - 23 May 1945. The original page images are free to download from
  TNA Discovery (search "DEFE 3/577" etc.). File names here follow the PDF parts: DEFE-3-577_1_0001 = part 1, page 1.

CONTENTS
  ocr-text/        2,215 pages, Windows OCR (English). OCR quality is fair: numbers and call signs are often garbled
                   (e.g. "TOO 1552" may appear as "T 0 0 1552" or "TQ 0"). Always check the page image for anything important.
  dated-index.json one entry per page:
                     f      = file name
                     ztpg   = ZTPG serial number (as read by OCR, may be off)
                     too    = German time of origin, "HHMM"
                     toi    = [time "HHMM", day, month] of interception (Bletchley)
                     kilde  = how the date was found: "register" (header line), "hoved" (header OCR), "fuld" (full text)
                   1,974 of 2,215 pages are dated. Relation seen in known cases: U-534's own clock ~ TOI + 2 h.

WHAT I SEARCHED (negative results)
  - FT 1552 of 1 May 1945 (time group from Dan Girard), also 1531 (earlier misreading): no matching decrypt.
  - "Thetis" and any possible re-transmission of P1030680: nothing found.
  - All 179 pages in the window 1 May 13:00 - 2 May 12:00 plus 158 undated pages were also checked visually.
  - Note: the training-net frequency 3764 kc/s appears (e.g. DEFE-3-578_04_0102, "Captain U/B Front"), so Bletchley
    did read some training-net traffic in May 1945.

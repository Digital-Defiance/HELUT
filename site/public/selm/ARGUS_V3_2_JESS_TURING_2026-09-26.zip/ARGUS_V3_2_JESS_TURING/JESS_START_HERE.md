# Jess — start here

This build is deliberately boring at the interface. It is meant to sit beside Turing, not compete with it.

1. `python argus_turing.py status`
2. `python argus_turing.py next`
3. `python argus_turing.py cribs --limit 20`
4. After a run, fill `TURING_RESULT_TEMPLATE.csv` and run `python argus_turing.py ingest-results <file>`.
5. To annotate candidate plaintexts: `python argus_turing.py triage <candidate.csv>`.

**Non-negotiable:** exact full re-encryption wins even if ARGUS thinks the plaintext/history is weird. ARGUS annotates; it does not veto.

Current historical defaults: do not assume U-534; allow Teilfunkspruch; do not count multiple Hörenberg fragments as independent evidence; wait for letter-exact DEFE/HW18 text before promoting the new Travemünde ZTPG cluster to cribs.

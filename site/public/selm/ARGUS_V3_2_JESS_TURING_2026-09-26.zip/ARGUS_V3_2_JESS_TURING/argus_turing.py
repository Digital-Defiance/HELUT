#!/usr/bin/env python3
from pathlib import Path
import csv,json,argparse,datetime,shutil
R=Path(__file__).resolve().parent

def rows(n):
 with open(R/n,encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def status():
 c=json.loads((R/'argus_config.json').read_text()); h=rows('TURING_HYPOTHESES.csv'); q=rows('TURING_RETRIEVAL_QUEUE.csv'); l=rows('TURING_RUN_LEDGER.csv')
 print(f"ARGUS {c['version']} | {c['interface']} | target {c['target']['length']} chars")
 print('not-U534 assumption: OFF | Teilfunkspruch: ALLOWED | exact re-encryption: SUPREME')
 print('hypotheses:',len(h),'open:',sum(x['status'] in ('OPEN','DISCOVERY') for x in h),'waiting source:',sum(x['status']=='WAITING_SOURCE' for x in h))
 print('retrieval targets:',len(q),'| recorded Turing runs:',len(l))
def nxt():
 rank={'OPEN':0,'DISCOVERY':1,'WAITING_SOURCE':2}
 for x in sorted(rows('TURING_HYPOTHESES.csv'),key=lambda x:rank.get(x['status'],9)):
  print('\t'.join([x['hypothesis_id'],x['status'],x['compute_lane'],x['name'],x['compute_constraint']]))
def cribs(limit,nonh):
 d=rows('crib_master.csv'); seen=set(); out=[]
 def score(x):
  try: return (int(x.get('attestation_score') or 0)+int(x.get('date_score') or 0)+int(x.get('radio_score') or 0)+int(x.get('crypto_usability_score') or 0), int(x.get('length') or 0))
  except:return (0,0)
 for x in sorted(d,key=score,reverse=True):
  if nonh and x.get('provenance_family')=='HOERENBERG_U534': continue
  g=x.get('independence_group') or x.get('crib_id')
  if g in seen: continue
  if int(x.get('valid_alignment_count') or 0)<1: continue
  seen.add(g); out.append(x)
  if len(out)>=limit:break
 print('crib_id,exact_string,length,valid_positions,source_document,provenance_family,attestation_tier')
 for x in out: print(','.join([x.get('crib_id',''),x.get('exact_string',''),x.get('length',''), '"'+x.get('valid_positions','')+'"',x.get('source_document',''),x.get('provenance_family',''),x.get('attestation_tier','')]))
def ingest(p):
 inp=list(csv.DictReader(open(p,encoding='utf-8',newline=''))); ledger=R/'TURING_RUN_LEDGER.csv'; ts=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with open(ledger,'a',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['timestamp_utc','run_id','hypothesis_id','method','coverage','outcome','notes','source_file'])
  for x in inp:w.writerow({'timestamp_utc':ts,'run_id':x.get('run_id',''),'hypothesis_id':x.get('hypothesis_id',''),'method':x.get('method',''),'coverage':x.get('coverage',''),'outcome':x.get('outcome',''),'notes':x.get('notes',''),'source_file':Path(p).name})
 shutil.copy2(p,R/('TURING_ARCHIVE_'+Path(p).name)); print('ingested',len(inp),'rows')
def triage(p):
 inp=list(csv.DictReader(open(p,encoding='utf-8',newline=''))); vocab=[]
 for x in rows('crib_master.csv'):
  s=x.get('exact_string','')
  if len(s)>=8:vocab.append((s,x.get('provenance_family','')))
 fields=list(inp[0].keys()) if inp else ['candidate_id','plaintext']; fields += ['argus_matches','argus_note']
 out=R/'TURING_CANDIDATES_ANNOTATED.csv'
 with open(out,'w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for x in inp:
   pt=''.join(c for c in x.get('plaintext','').upper() if c.isalpha()); hits=[]
   for s,pv in vocab:
    if s in pt:hits.append(s+'@'+pv)
   exact=str(x.get('reencrypt_exact','')).lower() in ('1','true','yes','y')
   x['argus_matches']=';'.join(hits[:20]); x['argus_note']='EXACT_REENCRYPTION_DOMINATES_HISTORY' if exact else 'HISTORICAL_ANNOTATION_ONLY_DO_NOT_REJECT'
   w.writerow(x)
 print(out)
def main():
 ap=argparse.ArgumentParser(); sp=ap.add_subparsers(dest='cmd',required=True); sp.add_parser('status');sp.add_parser('next'); c=sp.add_parser('cribs');c.add_argument('--limit',type=int,default=20);c.add_argument('--non-hoerenberg',action='store_true');i=sp.add_parser('ingest-results');i.add_argument('file');t=sp.add_parser('triage');t.add_argument('file'); a=ap.parse_args()
 {'status':status,'next':nxt}.get(a.cmd,lambda:None)() if a.cmd in ('status','next') else (cribs(a.limit,a.non_hoerenberg) if a.cmd=='cribs' else ingest(a.file) if a.cmd=='ingest-results' else triage(a.file))
if __name__=='__main__':main()

# ARGUS → TURING bridge v1

Built for Jessica / Digital Defiance. ARGUS is the historical coprocessor; Turing remains the cryptanalytic authority.

## Commands
`python argus_turing.py status` — compact machine state.

`python argus_turing.py next` — ranked, computation-ready hypotheses. Historical ranking only; not a probability.

`python argus_turing.py cribs --limit 20 [--non-hoerenberg]` — provenance-aware crib batch. At most one representative per independence group by default.

`python argus_turing.py ingest-results results.csv` — import a Turing run into `TURING_RUN_LEDGER.csv`. Expected columns: `run_id,hypothesis_id,method,coverage,outcome,notes`; extra columns preserved in the archived input.

`python argus_turing.py triage candidates.csv` — annotate candidate plaintexts without rejecting them. Expected at minimum `candidate_id,plaintext`; optional `reencrypt_exact`.

## Firewall
* Full exact re-encryption dominates historical plausibility.
* ARGUS never discards a candidate because the German/history looks odd.
* P1030680 is not assumed to be U-534 traffic.
* Teilfunkspruch remains permitted.
* Hörenberg is a useful near-neighbour corpus, not independent evidence merely because it yields many cribs.
* Summaries/translations are leads, not letter-exact cribs.

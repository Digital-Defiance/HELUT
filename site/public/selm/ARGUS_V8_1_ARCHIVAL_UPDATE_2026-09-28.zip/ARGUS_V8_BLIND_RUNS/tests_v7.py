import json,subprocess,sys,tempfile,shutil
from pathlib import Path
R=Path(__file__).resolve().parent

# Isolation: the previous version of this file ran argus7.py directly
# against the live project, then wiped lanes/signal.jsonl and deleted
# every file under merged/ ("ship clean") to erase its test object.
# That destroys real, non-regenerable research artefacts the moment
# this suite is run a second time (merged/analysis_report.json and
# merged/merge_audit.json in particular are hand-authored and are not
# reproduced by argus7.py's own merge()/analyse() -- once deleted they
# are gone for good). This version copies the whole project into a
# scratch directory and runs the copy's own argus7.py there instead;
# the live project is never touched.
tmp=Path(tempfile.mkdtemp())
scratch=tmp/"argus_scratch"
shutil.copytree(R,scratch)

def run(*a): return json.loads(subprocess.check_output(
    [sys.executable,str(scratch/"argus7.py"),*a],text=True,cwd=str(scratch)))

s=run("status"); assert s["version"]=="8.0.0"; assert len(s["lanes"])==5
before=s["master_claim_count"]
before_lane_counts={k:v for k,v in s["lanes"].items()}

x=run("add","--lane","signal","--source","TEST","--claim","test acquisition object","--classification","IRRELEVANT")
assert x["written"]
x2=run("add","--lane","signal","--source","TEST","--claim","test acquisition object","--classification","IRRELEVANT")
assert not x2["written"]
m=run("merge"); assert m["object_count"]>=1
a=run("analyse"); assert a["red_team_required"] and not a["master_claim_ledger_mutated"]
after=run("status")
assert before==after["master_claim_count"]
assert after["lanes"]["signal"]==before_lane_counts["signal"]+1
for lane in ("boats","british","german","neighbours"):
    assert after["lanes"][lane]==before_lane_counts[lane]

shutil.rmtree(tmp,ignore_errors=True)
print("ARGUS 7.0 five-lane regression: PASS (isolated scratch copy; live lanes/merged untouched)")

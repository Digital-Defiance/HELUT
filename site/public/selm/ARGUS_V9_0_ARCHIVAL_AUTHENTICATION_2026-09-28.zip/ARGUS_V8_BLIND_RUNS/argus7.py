#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,hashlib,re
from pathlib import Path
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parent
STATE=ROOT/"state.json"
LANES=("signal","boats","british","german","neighbours")

def load(): return json.loads(STATE.read_text(encoding="utf-8"))
def norm(s): return " ".join(re.sub(r"\s+"," ",s).strip().split())
def oid(lane,source,claim):
    return hashlib.sha1((lane+"\0"+source+"\0"+norm(claim)).encode()).hexdigest()[:16]
def read_jsonl(p):
    if not p.exists(): return []
    return [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]
def append_jsonl(p,obj):
    with p.open("a",encoding="utf-8") as f: f.write(json.dumps(obj,ensure_ascii=False)+"\n")
def lane_path(l): return ROOT/"lanes"/f"{l}.jsonl"

def add(lane,source,claim,classification="NEW",source_type="unknown",date="",entities="",signals="",locations="",raw_note=""):
    if lane not in LANES: raise SystemExit("invalid lane")
    obj={"object_id":oid(lane,source,claim),"lane":lane,"observed_at":datetime.now(timezone.utc).isoformat(),
         "source":source,"source_type":source_type,"date":date,
         "entities":[x.strip() for x in entities.split(",") if x.strip()],
         "signals":[x.strip() for x in signals.split(",") if x.strip()],
         "locations":[x.strip() for x in locations.split(",") if x.strip()],
         "claim":norm(claim),"classification":classification,"raw_note":raw_note}
    existing={x["object_id"] for x in read_jsonl(lane_path(lane))}
    if obj["object_id"] in existing:
        return {"written":False,"reason":"EXACT_OBJECT_DUPLICATE","object_id":obj["object_id"]}
    append_jsonl(lane_path(lane),obj)
    return {"written":True,"object":obj}

def merge():
    (ROOT/"merged").mkdir(parents=True,exist_ok=True)
    allobjs=[]
    for l in LANES: allobjs += read_jsonl(lane_path(l))
    # Exact object IDs stay unique; claim-key groups preserve all attestations.
    groups={}
    for o in allobjs:
        key=hashlib.sha1(norm(o["claim"]).upper().encode()).hexdigest()[:16]
        groups.setdefault(key,[]).append(o)
    merged=[]
    for k,items in groups.items():
        merged.append({"claim_key":k,"claim":items[0]["claim"],
                       "attestations":[{"object_id":x["object_id"],"lane":x["lane"],"source":x["source"],
                                        "source_type":x["source_type"],"classification":x["classification"],
                                        "signals":x["signals"],"entities":x["entities"]} for x in items],
                       "lanes":sorted(set(x["lane"] for x in items)),
                       "signals":sorted(set(y for x in items for y in x["signals"])),
                       "entities":sorted(set(y for x in items for y in x["entities"]))})
    out={"generated_at":datetime.now(timezone.utc).isoformat(),"object_count":len(allobjs),
         "claim_group_count":len(merged),"groups":merged}
    p=ROOT/"merged"/"corpus.json"; p.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding="utf-8")
    return out

def analyse():
    p=ROOT/"merged"/"corpus.json"
    if not p.exists(): raise SystemExit("MERGE_REQUIRED")
    m=json.loads(p.read_text(encoding="utf-8"))
    # Machine report deliberately does not invent conclusions.
    report={"phase":"ANALYSE_READY","generated_at":datetime.now(timezone.utc).isoformat(),
            "objects":m["object_count"],"claim_groups":m["claim_group_count"],
            "required_questions":[
              "What is known about P1030680 itself?",
              "Which candidate networks fit its recoverable metadata?",
              "Which links are document identity, signal identity, event identity, or contextual proximity?",
              "Which hypotheses became stronger, weaker, or unchanged?",
              "Which unresolved source has highest expected information gain?"
            ],
            "red_team_required":True,
            "master_claim_ledger_mutated":False}
    q=ROOT/"merged"/"analysis_gate.json"; q.write_text(json.dumps(report,indent=2),encoding="utf-8")
    return report

def status():
    s=load()
    return {"version":s["engine_version"],"architecture":s["architecture"],
            "lanes":{l:len(read_jsonl(lane_path(l))) for l in LANES},
            "merged_exists":(ROOT/"merged"/"corpus.json").exists(),
            "analysis_gate_exists":(ROOT/"merged"/"analysis_gate.json").exists(),
            "master_claim_count":len(s.get("claim_ledger",[])),
            "pre_run_guardrails":len(s.get("pre_run_guardrails",[]))}

def main():
    p=argparse.ArgumentParser(prog="argus7")
    sp=p.add_subparsers(dest="cmd",required=True)
    sp.add_parser("status")
    a=sp.add_parser("add"); a.add_argument("--lane",required=True,choices=LANES); a.add_argument("--source",required=True); a.add_argument("--claim",required=True)
    a.add_argument("--classification",default="NEW",choices=["NEW","KNOWN","CORROBORATION","CONTRADICTION","IRRELEVANT"])
    a.add_argument("--source-type",default="unknown",choices=["primary","near_primary","secondary","index","unknown"])
    a.add_argument("--date",default=""); a.add_argument("--entities",default=""); a.add_argument("--signals",default=""); a.add_argument("--locations",default=""); a.add_argument("--raw-note",default="")
    sp.add_parser("merge"); sp.add_parser("analyse")
    x=p.parse_args()
    if x.cmd=="status": out=status()
    elif x.cmd=="add": out=add(x.lane,x.source,x.claim,x.classification,x.source_type,x.date,x.entities,x.signals,x.locations,x.raw_note)
    elif x.cmd=="merge": out=merge()
    else: out=analyse()
    print(json.dumps(out,indent=2,ensure_ascii=False))
if __name__=="__main__": main()

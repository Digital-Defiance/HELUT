# ARGUS 6.0 — STATEFUL

This release fixes repeated rediscovery by making state reconciliation mandatory **before** search.

## Mandatory pipeline
`ARGUS STATE → DEDUP → GAP → SEARCH → DELTA → COMMIT`

Candidate findings are classified as:
`NEW_FACT`, `NEW_CORROBORATION`, `CORRECTION`, or `DUPLICATE_DISCARD`.

A new source is not automatically a new fact. Duplicates are blocked from COMMIT.

## Commands
```bash
python3 argus.py preflight
python3 argus.py next
python3 argus.py classify "candidate claim"
python3 argus.py ledger --kind frontier
python3 argus.py commit "genuinely new claim" --source "source" --confidence HARD --tags U3030,HW18
```

## Current frontier
1. HW18/429 — terminal 30 Apr–1 May; U3030.
2. HW18/436 — terminal 30 Apr–1 May; U3032/U2540.
3. HW18/425 — U3024 / ZTPG 369048 control.
4. DEFE primary — ZTPG 369139 and 369048.

Open-web U3030/U3032/U2540 context mining is closed until a new primary source,
contradiction, or indicator-bearing object appears.

`legacy/ARGUS_findings_2026-09-26.json` is preserved verbatim.

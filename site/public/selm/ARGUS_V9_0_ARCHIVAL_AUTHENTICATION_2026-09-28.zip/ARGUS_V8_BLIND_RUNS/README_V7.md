# ARGUS 7.0 — Five-Lane Search

ARGUS 7 separates acquisition from interpretation.

## Architecture

Five independent acquisition lanes:

1. **SIGNAL** — P1030680/P1030710 message-level evidence.
2. **BOATS** — U3030/U3032/U2540 movement/communications, 28 Apr–3 May.
3. **BRITISH** — HW18/DEFE provenance and crosswalks.
4. **GERMAN** — M-Thetis procedure, allocations, training nets.
5. **NEIGHBOURS** — comparable traffic, alternative populations, negative controls.

During these five runs, **no synthesis or hypothesis upgrade is allowed**.

Then:

6. `merge` — assemble all lane objects while preserving source/document/signal/event distinctions.
7. `analyse` — open the analysis gate and require a red-team alternative-explanation pass.

The master claim ledger is not changed during acquisition.

## Commands

```bash
python3 argus7.py status

python3 argus7.py add --lane signal --source "SOURCE" --claim "FACTUAL OBSERVATION"   --source-type primary --signals P1030680 --entities U3030

python3 argus7.py merge
python3 argus7.py analyse
```

Each lane is an append-only JSONL scrape store under `lanes/`.
The merged corpus is written to `merged/corpus.json`.

V6.2 state and prior claims are retained in `state.json`; V7 changes the research workflow, not the established evidence firewall.

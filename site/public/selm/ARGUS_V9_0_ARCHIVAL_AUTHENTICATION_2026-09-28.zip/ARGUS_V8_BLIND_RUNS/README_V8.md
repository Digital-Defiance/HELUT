# ARGUS 8.0 — Blind Multi-Run Research Flow

V8 adds **information firewalls**, not merely instruction firewalls.

## Runs
- **A SIGNAL EXAMINER** — sees message evidence, not the boat-attribution hypothesis.
- **B BOAT HISTORIAN** — sees U3030/U3032/U2540, not P1030680.
- **C BRITISH PROVENANCE** — sees HW18/DEFE/ZTPG targets, no preferred attribution.
- **D GERMAN PROCEDURE** — sees procedure questions, not the desired ACH outcome.
- **E BLIND ALTERNATIVES** — does not receive U3030/U3032/U2540 or preferred ZTPG event.
- **F MERGE** — combines frozen A–E outputs without hypothesis scoring.
- **G SYNTHESIS + RED TEAM** — sees the merged corpus and pre-registered falsifiers.
- **H COMMIT** — only phase allowed to change the master claim ledger.

## Typical use
```bash
python3 argus8.py packet A
# Give only that packet to research run A.
python3 argus8.py add A --source "..." --observation "..."

# Repeat B–E in fresh model/research contexts.
python3 argus8.py merge
python3 argus8.py analysis-template
```

For genuine independence, run A–E as separate model/research sessions and provide each only its packet plus the sources it discovers. Do not provide the full ARGUS state to acquisition runs.

The prior V7 analysis remains historical project state, but it is not copied into the new V8 acquisition stores.

## Maintenance
```bash
python3 verify_manifest.py check   # detect drift/tamper vs MANIFEST.json
python3 verify_manifest.py update  # regenerate MANIFEST.json after an intentional change
python3 tests.py                   # v6 engine regression (isolated scratch copy)
python3 tests_v7.py                # v7 five-lane regression (isolated scratch copy)
```
Both test suites now run against throwaway copies of the project and
never modify the live `state.json`, `journal.jsonl`, `lanes/`, or
`merged/`. Run `verify_manifest.py update` after any deliberate edit
to tracked files, then commit the refreshed `MANIFEST.json` alongside
it — otherwise `check` will (correctly) report drift next time.

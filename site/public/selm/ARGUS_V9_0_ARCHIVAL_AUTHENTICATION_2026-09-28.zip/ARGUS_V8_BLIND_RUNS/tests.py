import json,subprocess,sys,shutil,tempfile
from pathlib import Path
R=Path(__file__).resolve().parent

# Isolation: copy the live state.json to a scratch file and point every
# invocation at it via --state. This suite must never mutate the
# project's real state.json/journal.jsonl, and must never depend on the
# exact size/contents of the live claim ledger (which grows over time
# as real research findings are committed) -- both of those were bugs
# in the previous version of this file.
tmp=Path(tempfile.mkdtemp())
scratch=tmp/"state.json"
shutil.copy(R/"state.json",scratch)

def run(*a): return subprocess.check_output(
    [sys.executable,str(R/"argus.py"),"--state",str(scratch),*a],text=True)

before=json.loads(run("verify-state"))

# Known-duplicate regression: a paraphrase of the seeded U3030/U3032/U2540
# Funkkontakt claim must still be recognised as a duplicate, however the
# live ledger has grown since this claim was first committed.
x=json.loads(run("classify","U3030 crew account reports Funkkontakt involving U3032 and U2540"))
assert x["classification"]=="DUPLICATE_DISCARD",x
print("ARGUS regression: known-claim paraphrase dedup PASS")

# The active frontier's #1 priority target must still be present and open
# (this is a structural invariant of the current research phase, not a
# value that should silently drift without someone noticing).
x=json.loads(run("next"))
assert x.get("priority")==1,x
print("ARGUS regression: frontier priority ordering PASS")

x=json.loads(run("preflight"))
assert x["workflow"]==["ARGUS_STATE","DEDUP","GAP","SEARCH","DELTA","COMMIT"],x
print("ARGUS regression: workflow order PASS")

# Event-fingerprint regression: a paraphrase of the known 369139 event
# (different wording, same date/time/location/entities/signal) must
# fingerprint-match that specific canonical event, not just "some" claim.
x=json.loads(run("classify",
    "On 1 May 1945 at 18:00 U3030, U3032 and U2540 were anchored at ROT07A/AO7819; "
    "HMA cites DEFE 3/579 ZTPG 369139."))
assert x["classification"]=="DUPLICATE_DISCARD",x
assert x["event_matches"][0]["event_id"]=="E-369139-19450501-1800-ROT07A",x
print("ARGUS regression: event-fingerprint match PASS")

# Persistence/commit regression: committing a genuinely new claim must
# atomically grow the ledger by exactly one and append exactly one
# journal line, on top of whatever was already there -- checked
# relatively, so this keeps passing as the real ledger grows.
novel_claim="TEST-ONLY placeholder claim for regression isolation, never a real finding."
c=json.loads(run("commit",novel_claim,"--source","tests.py","--confidence","UNASSESSED","--tags","TEST"))
assert c["committed"] is True,c
after=json.loads(run("verify-state"))
assert after["claim_count"]==before["claim_count"]+1,(before,after)
assert after["last_claim_id"]==c["claim_id"],(after,c)
assert after["journal_entries"]==before["journal_entries"]+1,(before,after)
print("ARGUS regression: commit persistence (ledger+journal, relative) PASS")

# Re-committing the exact same claim text must be rejected as a duplicate
# and must NOT grow the ledger further.
c2=json.loads(run("commit",novel_claim,"--source","tests.py","--confidence","UNASSESSED","--tags","TEST"))
assert c2.get("committed",False) is False,c2
after2=json.loads(run("verify-state"))
assert after2["claim_count"]==after["claim_count"],(after,after2)
print("ARGUS regression: duplicate re-commit is a no-op PASS")

shutil.rmtree(tmp,ignore_errors=True)
print(f"ARGUS engine_version under test: {before['engine_version']}")
print("ALL ARGUS regression tests: PASS (isolated scratch state; live state.json untouched)")

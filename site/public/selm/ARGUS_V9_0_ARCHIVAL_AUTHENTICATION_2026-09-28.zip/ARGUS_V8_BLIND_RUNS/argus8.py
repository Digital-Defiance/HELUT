#!/usr/bin/env python3
import argparse,json,hashlib
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
STATE=ROOT/"state.json"
RUNS={"A":"A_signal.jsonl","B":"B_boats.jsonl","C":"C_british.jsonl","D":"D_german.jsonl","E":"E_alternatives.jsonl"}
def state(): return json.loads(STATE.read_text(encoding="utf-8"))
def rows(p):
    return [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()] if p.exists() else []
def status():
    s=state()
    return {"version":s["engine_version"],"flow":[x["run"]+":"+x["role"] for x in s["v8_flow"]],
            "runs":{k:len(rows(ROOT/"runs"/v)) for k,v in RUNS.items()},
            "merged":(ROOT/"synthesis"/"merged.json").exists(),
            "analysed":(ROOT/"synthesis"/"analysis_template.json").exists(),
            "master_claim_count":len(s.get("claim_ledger",[]))}
def packet(run): return (ROOT/"packets"/f"RUN_{run}.txt").read_text(encoding="utf-8")
def add(run,source,observation,source_type="unknown",classification="NEW",tags=""):
    if run not in RUNS: raise SystemExit("Only acquisition runs A-E accept observations")
    oid=hashlib.sha1((run+"\0"+source+"\0"+observation.strip()).encode()).hexdigest()[:16]
    p=ROOT/"runs"/RUNS[run]; p.parent.mkdir(parents=True,exist_ok=True)
    old={x["id"] for x in rows(p)}
    if oid in old:return {"written":False,"reason":"DUPLICATE","id":oid}
    o={"id":oid,"run":run,"at":datetime.now(timezone.utc).isoformat(),"source":source,
       "source_type":source_type,"classification":classification,"observation":observation.strip(),
       "tags":[x.strip() for x in tags.split(",") if x.strip()]}
    with p.open("a",encoding="utf-8") as f:f.write(json.dumps(o,ensure_ascii=False)+"\n")
    return {"written":True,"object":o}
def merge():
    allr=[]; 
    for k,v in RUNS.items(): allr += rows(ROOT/"runs"/v)
    out={"generated_at":datetime.now(timezone.utc).isoformat(),"objects":allr,
         "run_counts":{k:len(rows(ROOT/"runs"/v)) for k,v in RUNS.items()},
         "rule":"Distinct source/document/signal/event identities are preserved; no hypothesis scoring occurs here."}
    (ROOT/"synthesis").mkdir(exist_ok=True)
    (ROOT/"synthesis"/"merged.json").write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding="utf-8")
    return {"objects":len(allr),"run_counts":out["run_counts"]}
def analysis_template():
    p=ROOT/"synthesis"/"merged.json"
    if not p.exists(): raise SystemExit("RUN_F_MERGE_REQUIRED")
    s=state(); m=json.loads(p.read_text(encoding="utf-8"))
    out={"phase":"RUN_G_READY","object_count":len(m["objects"]),"pre_registered_tests":s["pre_registered_tests"],
         "required_outputs":["evidence graph","hypothesis scorecard with evidence IDs","red-team alternatives",
                             "contradictions","highest-information-gain next sources"],
         "allowed_scores":["STRENGTHENED","WEAKENED","UNCHANGED","FALSIFIED"],
         "master_ledger_locked":True}
    (ROOT/"synthesis"/"analysis_template.json").write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding="utf-8")
    return out
def main():
    p=argparse.ArgumentParser(prog="argus8"); sp=p.add_subparsers(dest="cmd",required=True)
    sp.add_parser("status")
    q=sp.add_parser("packet");q.add_argument("run",choices=list("ABCDE"))
    a=sp.add_parser("add");a.add_argument("run",choices=list("ABCDE"));a.add_argument("--source",required=True);a.add_argument("--observation",required=True)
    a.add_argument("--source-type",default="unknown");a.add_argument("--classification",default="NEW");a.add_argument("--tags",default="")
    sp.add_parser("merge");sp.add_parser("analysis-template")
    x=p.parse_args()
    if x.cmd=="status":o=status()
    elif x.cmd=="packet": print(packet(x.run));return
    elif x.cmd=="add":o=add(x.run,x.source,x.observation,x.source_type,x.classification,x.tags)
    elif x.cmd=="merge":o=merge()
    else:o=analysis_template()
    print(json.dumps(o,indent=2,ensure_ascii=False))
if __name__=="__main__":main()

#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,hashlib,re
from pathlib import Path
from datetime import datetime,timezone
from difflib import SequenceMatcher
ROOT=Path(__file__).resolve().parent
DEFAULT=ROOT/"state.json"
VERSION="6.2.0"
STOP={"THE","A","AN","AND","OR","IS","ARE","WAS","WERE","OF","IN","AT","TO","WITH","FROM","ON","FOR","BY","AS","BE","NOT"}

def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def save(p,s):
    p=Path(p); t=p.with_suffix(".tmp"); t.write_text(json.dumps(s,indent=2,ensure_ascii=False),encoding="utf-8"); t.replace(p)
def norm(s): return " ".join(re.sub(r"[^A-Z0-9]+"," ",s.upper()).split())
def toks(s): return {x for x in norm(s).split() if x not in STOP and len(x)>1}
def sim(a,b):
    na,nb=norm(a),norm(b); ta,tb=toks(a),toks(b)
    seq=SequenceMatcher(None,na,nb).ratio() if na and nb else 0
    jac=len(ta&tb)/max(1,len(ta|tb))
    containment=len(ta&tb)/max(1,min(len(ta),len(tb)))
    return max(seq,jac,containment*0.95)

def event_features(text):
    u=set(re.findall(r"\bU\s*[- ]?(\d{3,4})\b",text.upper()))
    u={"U"+x for x in u}
    z=set("ZTPG"+x for x in re.findall(r"(?:ZTPG\s*)?(\d{6})",text.upper()))
    loc=set()
    up=text.upper().replace("Ü","U")
    if "ROT07A" in up or "ROT 07A" in up or "7A" in up: loc.add("ROT07A")
    if "AO7819" in up: loc.add("AO7819")
    if "TRAVEMUNDE" in up or "TRAVEMUENDE" in up: loc.add("TRAVEMUENDE")
    if "AO7793" in up: loc.add("AO7793")
    tm=set(re.findall(r"\b(?:AT\s*)?([012]?\d)[:.]([0-5]\d)\b",up))
    times={f"{int(h):02d}:{m}" for h,m in tm}
    if re.search(r"\b1800\b",up): times.add("18:00")
    if re.search(r"\b2023\b",up): times.add("20:23")
    dates=set()
    if re.search(r"\b1\s+MAY(?:\s+1945)?\b",up) or "1945-05-01" in up: dates.add("1945-05-01")
    return {"entities":u,"signals":z,"locations":loc,"times":times,"dates":dates}

def event_match(state,claim):
    f=event_features(claim); hits=[]
    for e in state.get("event_fingerprints",[]):
        ee=set(e.get("entities",[])); ss=set(e.get("signals",[])); ll=set(e.get("location",[]))
        score=0
        if f["signals"] & ss: score+=5
        score+=min(3,len(f["entities"] & ee))
        if f["locations"] & ll: score+=2
        if e.get("time") in f["times"]: score+=2
        if e.get("date") in f["dates"]: score+=2
        # A signal id plus one matching entity, or 3 entities + time/location, is decisive.
        decisive=(bool(f["signals"] & ss) and bool(f["entities"] & ee)) or (
            len(f["entities"] & ee)>=3 and (bool(f["locations"] & ll) or e.get("time") in f["times"]))
        if decisive: hits.append((score,e))
    return sorted(hits,key=lambda x:x[0],reverse=True)

def matches(state,claim,threshold=.70):
    out=[]
    for x in state.get("claim_ledger",[]):
        score=sim(claim,x.get("claim",""))
        if score>=threshold: out.append((score,x))
    return sorted(out,key=lambda z:z[0],reverse=True)
def classify(state,claim,source="",contradicts=""):
    em=event_match(state,claim)
    ms=matches(state,claim)
    if contradicts: label,reason="CORRECTION",f"Explicitly revises {contradicts}."
    elif em:
        score,event=em[0]
        label,reason="DUPLICATE_DISCARD",f"Canonical event fingerprint match: {event['event_id']} (score {score})."
    elif ms:
        score,best=ms[0]; known=set(best.get("sources",[]))
        if source and source not in known: label,reason="NEW_CORROBORATION",f"Known claim {best['claim_id']} ({score:.2f}); new source."
        else: label,reason="DUPLICATE_DISCARD",f"Known claim {best['claim_id']} ({score:.2f}); no new evidentiary value."
    else: label,reason="NEW_FACT","No claim-level match above threshold."
    return {"classification":label,"reason":reason,"event_matches":[{"score":s,"event_id":e["event_id"]} for s,e in em[:5]],"claim_matches":[{"score":round(s,3),"claim_id":x["claim_id"],"claim":x["claim"]} for s,x in ms[:5]]}
def preflight(s):
    return {"phase":"PRE_FLIGHT","workflow":s["workflow"],"canonical_target":s.get("canonical_target",{}).get("message"),
            "status":s.get("status",{}),"frontier":sorted(s.get("active_frontier",[]),key=lambda x:x["priority"]),
            "closed_search_zones":s.get("closed_search_zones",[]),"known_claim_count":len(s.get("claim_ledger",[])),
            "known_negative_count":len(s.get("known_negatives",[])),"invariants":s.get("invariants",[])}
def nextgap(s):
    for x in sorted(s.get("active_frontier",[]),key=lambda x:x["priority"]):
        if x.get("status","").startswith("OPEN"): return x
    return {"status":"NO_OPEN_FRONTIER","instruction":"Do not invent a side quest."}
def main():
    p=argparse.ArgumentParser(description="ARGUS 6.0 stateful provenance firewall"); p.add_argument("--state",default=str(DEFAULT))
    sp=p.add_subparsers(dest="cmd",required=True)
    sp.add_parser("preflight"); sp.add_parser("next"); sp.add_parser("verify-state")
    le=sp.add_parser("ledger"); le.add_argument("--kind",choices=["claims","negatives","frontier","closed"],default="claims")
    cl=sp.add_parser("classify"); cl.add_argument("claim"); cl.add_argument("--source",default=""); cl.add_argument("--contradicts",default="")
    co=sp.add_parser("commit"); co.add_argument("claim"); co.add_argument("--source",default=""); co.add_argument("--confidence",default="UNASSESSED"); co.add_argument("--tags",default=""); co.add_argument("--contradicts",default="")
    an=sp.add_parser("add-negative"); an.add_argument("text")
    a=p.parse_args(); s=load(a.state)
    if a.cmd=="preflight": print(json.dumps(preflight(s),indent=2,ensure_ascii=False))
    elif a.cmd=="verify-state":
        j=Path(a.state).resolve().parent/"journal.jsonl"
        print(json.dumps({"engine_version":s.get("engine_version"),
                          "claim_count":len(s.get("claim_ledger",[])),
                          "last_claim_id":s.get("claim_ledger",[])[-1].get("claim_id") if s.get("claim_ledger") else None,
                          "journal_exists":j.exists(),
                          "journal_entries":sum(1 for _ in j.open(encoding="utf-8")) if j.exists() else 0},indent=2))
    elif a.cmd=="next": print(json.dumps(nextgap(s),indent=2,ensure_ascii=False))
    elif a.cmd=="ledger":
        k={"claims":"claim_ledger","negatives":"known_negatives","frontier":"active_frontier","closed":"closed_search_zones"}[a.kind]; print(json.dumps(s.get(k,[]),indent=2,ensure_ascii=False))
    elif a.cmd=="classify": print(json.dumps(classify(s,a.claim,a.source,a.contradicts),indent=2,ensure_ascii=False))
    elif a.cmd=="commit":
        v=classify(s,a.claim,a.source,a.contradicts)
        if v["classification"]=="DUPLICATE_DISCARD":
            print(json.dumps({"committed":False,**v},indent=2)); return
        cid="C-"+hashlib.sha1(a.claim.encode()).hexdigest()[:10].upper()
        e={"claim_id":cid,"claim":a.claim,"status":v["classification"],"confidence":a.confidence,
           "tags":[x.strip() for x in a.tags.split(",") if x.strip()],"sources":[a.source] if a.source else [],
           "committed_at":datetime.now(timezone.utc).isoformat()}
        s.setdefault("claim_ledger",[]).append(e); save(a.state,s)
        journal=Path(a.state).resolve().parent/"journal.jsonl"
        with journal.open("a",encoding="utf-8") as jf:
            jf.write(json.dumps({"at":e["committed_at"],"action":"COMMIT","claim_id":cid,
                                 "classification":v["classification"],"confidence":a.confidence,
                                 "claim":a.claim,"source":a.source},ensure_ascii=False)+"\n")
        print(json.dumps({"committed":True,"claim_id":cid,"persisted_to":str(Path(a.state)),
                          "journal":str(journal),**v},indent=2))
    elif a.cmd=="add-negative":
        if a.text in s.setdefault("known_negatives",[]): print("Already present.")
        else: s["known_negatives"].append(a.text); save(a.state,s); print("Added.")
if __name__=="__main__": main()

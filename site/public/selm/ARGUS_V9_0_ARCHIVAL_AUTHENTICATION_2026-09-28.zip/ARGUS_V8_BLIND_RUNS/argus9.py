#!/usr/bin/env python3
import argparse, json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
STATE=ROOT/'state.json'
GRADES={'HARD','STRONG_PROVISIONAL','HYPOTHESIS','REJECTED_UNSUPPORTED'}
def state(): return json.loads(STATE.read_text(encoding='utf-8'))
def main():
    p=argparse.ArgumentParser(prog='argus9')
    sp=p.add_subparsers(dest='cmd',required=True)
    sp.add_parser('status'); sp.add_parser('watchlist'); sp.add_parser('constraints')
    v=sp.add_parser('validate-grade'); v.add_argument('grade')
    for name in ('packet','add','merge','analysis-template'):
        q=sp.add_parser(name,add_help=False); q.add_argument('rest',nargs=argparse.REMAINDER)
    x=p.parse_args(); s=state()
    if x.cmd=='status':
        print(json.dumps({'version':s['engine_version'],'target':s['project'],'plaintext':s['status']['plaintext'],'watchlist_open':sum(1 for z in s['v9_watchlist'] if z['status']=='OPEN'),'evidence_grades':s['v9_evidence_policy']['grades']},indent=2)); return
    if x.cmd=='watchlist': print(json.dumps(s['v9_watchlist'],ensure_ascii=False,indent=2)); return
    if x.cmd=='constraints': print(json.dumps(s['v9_constraints'],ensure_ascii=False,indent=2)); return
    if x.cmd=='validate-grade':
        g=x.grade.upper(); print(json.dumps({'grade':g,'valid':g in GRADES})); raise SystemExit(0 if g in GRADES else 2)
    # Inherit the hardened V8 A-H implementation for acquisition/merge mechanics.
    cmd=[sys.executable,str(ROOT/'argus8.py'),x.cmd]+x.rest
    raise SystemExit(subprocess.call(cmd,cwd=ROOT))
if __name__=='__main__': main()

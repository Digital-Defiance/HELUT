# ARGUS 9.0 — Archival Authentication & Constraint Ledger

V9 keeps the V8 information firewalls, but changes the centre of gravity: **authentication before attribution, archival constraints before compute**.

## Non-negotiable baseline
- P1030680: 1 May 1945, 72 ciphertext letters, supported M-Thetis identification, **UNBROKEN**.
- No plaintext, exact full re-encryption, sender, recipient, or U-boat attribution is established.
- P1030680 is not ZTPG 369139.
- Do not assume one daily Grundstellung.
- DGUG→Thetis is rejected/closed; DGUG survives only as a cheap Potsdam control.
- The tested Potsdam/Offizier-header escape route is closed for P1030680.

## V9 evidence grades
Every material assertion must be tagged:
1. **HARD** — directly supported by inspected primary evidence or reproducible computation.
2. **STRONG_PROVISIONAL** — multiple/strong indicators, but one decisive provenance link is missing.
3. **HYPOTHESIS** — testable lead; not evidence of the target claim.
4. **REJECTED_UNSUPPORTED** — contradicted, closed, or lacking evidentiary support.

Never silently promote a lower grade.

## Priority order
1. Authenticate the probable ~4860-kc/s Allied raw-intercept twin of P1030680.
2. Locate M-Thetis May 1945 key sheet / monthly Grundstellung table, including NR 201/202 surrendered key material.
3. Resolve Welle NB / Niobe–Narwhal provenance.
4. Revalidate 30-April Kenngruppen and Tafel-G readings.
5. Search Swedish raw intercepts / neighboring Thetis traffic.
6. Continue targeted DEFE and Kew archival acquisition.

## Kew rule
Catalogue hits and open-but-not-digitised records are **watchlist leads only** until inspected. Current candidates are recorded in `state.json` under `v9_watchlist`.

## Workflow
V8 runs A–H remain valid and are inherited. Use `argus9.py` for V9 status, watchlist, constraints, evidence-grade validation, packet access, acquisition, merge, and analysis-template generation.

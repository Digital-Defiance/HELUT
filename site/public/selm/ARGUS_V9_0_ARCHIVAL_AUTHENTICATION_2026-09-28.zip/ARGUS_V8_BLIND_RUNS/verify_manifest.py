#!/usr/bin/env python3
"""Integrity check for MANIFEST.json.

MANIFEST.json records a sha256 per tracked file at the moment it was
last generated. Nothing in ARGUS ever re-checked it, so it silently
drifts out of sync the moment state.json/journal.jsonl are updated by
normal use (commit, add-negative, ...) or the code is patched -- there
was no way to tell "manifest is stale" from "manifest is a meaningful
integrity record" without doing this by hand.

Usage:
    python3 verify_manifest.py check   # report drift, exit 1 if any
    python3 verify_manifest.py update  # regenerate MANIFEST.json from disk
"""
import sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
MANIFEST=ROOT/"MANIFEST.json"

def sha256(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def check():
    m=json.loads(MANIFEST.read_text(encoding="utf-8"))
    drift=[]
    for rel,meta in m.items():
        p=ROOT/rel
        if not p.exists():
            drift.append({"file":rel,"status":"MISSING"}); continue
        h=sha256(p)
        if h!=meta["sha256"]:
            drift.append({"file":rel,"status":"CHANGED","manifest_sha256":meta["sha256"],"actual_sha256":h})
    extra=sorted(set(str(p.relative_to(ROOT)) for p in ROOT.rglob("*")
                      if p.is_file() and p.name!="MANIFEST.json"
                      and not any(part.startswith(".") for part in p.relative_to(ROOT).parts))
                 - set(m.keys()))
    out={"tracked":len(m),"drifted":drift,"untracked_files":extra}
    print(json.dumps(out,indent=2,ensure_ascii=False))
    return 1 if (drift or extra) else 0

def update():
    files=sorted(p for p in ROOT.rglob("*") if p.is_file() and p.name!="MANIFEST.json"
                 and not any(part.startswith(".") for part in p.relative_to(ROOT).parts))
    m={str(p.relative_to(ROOT)):{"bytes":p.stat().st_size,"sha256":sha256(p)} for p in files}
    MANIFEST.write_text(json.dumps(m,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps({"updated":True,"tracked":len(m)},indent=2))
    return 0

if __name__=="__main__":
    cmd=sys.argv[1] if len(sys.argv)>1 else "check"
    sys.exit({"check":check,"update":update}.get(cmd,lambda:(_ for _ in ()).throw(SystemExit("usage: check|update")))())

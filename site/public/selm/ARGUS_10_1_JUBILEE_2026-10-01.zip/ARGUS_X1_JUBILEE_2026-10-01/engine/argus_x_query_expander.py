#!/usr/bin/env python3
"""ARGUS X query expander. No network calls: emits auditable search queries."""
import json, re, sys
from pathlib import Path

CONFUSIONS = {
    "0":["O"], "O":["0"], "1":["I","L"], "I":["1","L"], "5":["S"], "S":["5"],
    "8":["B"], "B":["8"], "6":["G"], "G":["6"]
}

def one_edit_ocr(s):
    out={s}
    for i,ch in enumerate(s):
        for repl in CONFUSIONS.get(ch,[]):
            out.add(s[:i]+repl+s[i+1:])
    return sorted(out)

def expand(identifier):
    q=set(one_edit_ocr(identifier))
    compact=re.sub(r"\s+","",identifier)
    q.add(compact)
    if compact.startswith("P") and compact[1:].isdigit():
        q.add(compact[1:])
        q.add("P "+compact[1:])
    return sorted(q)

if __name__=="__main__":
    ident=" ".join(sys.argv[1:]) or "P1030680"
    print(json.dumps({"identifier":ident,"queries":expand(ident)},indent=2))

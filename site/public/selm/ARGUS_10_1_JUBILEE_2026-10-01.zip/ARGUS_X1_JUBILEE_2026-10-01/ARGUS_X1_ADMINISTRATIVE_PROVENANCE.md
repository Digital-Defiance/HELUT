# ARGUS X.1 — Administrative provenance / key-production trail
Updated 2026-10-01

## Research pivot
Instead of searching only for “Thetis”, ask who made Kriegsmarine naval keys, where they were produced, who distributed them, and what administrative trail this process should have left. This creates a provenance-first route to the missing May 1945 allocation/key material.

## Evidence map

### HARD / primary-document anchor
- A surviving 1945 Schlüssel-M document for Sonder-Schlüssel Nixe carries the German issuing reference `OKM 4/Skl IIc 140/45 g.Kdos.`
- Guardrail: the German Nixe document reads **IIc**. A British RIP 401 translation renders the reference as **IIcc**. Do not silently normalize the German original to IIcc; retain the discrepancy as evidence to resolve.
- Consequence: search captured German records for the literal reference pattern `4/Skl IIc [number]/45`, adjacent 1945 registry numbers, and both IIc/IIcc variants.

### STRONG_PROVISIONAL / organizational reconstruction
- Postwar organizational reconstruction DF-225, John Pitz, *Organization of the Communications Service of the German Navy, 4/SKL* (1 Dec 1950), places cipher/key work in 4/SKL IIc and describes IIcc as responsible for production/distribution of naval keys and radio names.
- 4/SKL Ia is reported as handling document registration/classification. This makes Ia registries, Geschäftstagebücher, Aktenverzeichnisse and Geschäftsverteilungspläne a parallel target for recovering IIc/IIcc document numbers even if the key sheets themselves are missing.
- Henno Lucan is a named senior officer in the 4/SKL II command chain. This is organizational context, NOT proof that he personally handled M-Thetis.

### PERSONNEL / TICOM trail
Priority reports to acquire and inspect in full:
- TICOM I-24 — interrogation of members of OKM/4 SKL II; target: extract every name, rank, subsection and responsibility; cross-match to IIc/IIcc.
- TICOM I-10, I-14, I-34 (Brown Lists) — personnel/name-resolution route.
- TICOM I-28 — interrogation of Amtsrat Dr Stiehler of OKM 4/SKL II on meteorological ciphers. Stiehler is a confirmed II person but must NOT be promoted to IIc/IIcc; meteorological responsibility may place him elsewhere (e.g. IIW).
- AFSA DF-225 — obtain the full primary/postwar report, not merely derivative web summaries; extract organization chart, personnel, functions, documentary/registry references and source notes.

## NARA RG 457 route
Existing priority remains:
- RG 457 — Historic Cryptographic Collection
- Box 620
- NR 1665 / CBKJ17 / 7465A
- `GERMAN KEY LOGS (FEB 41–MAY 45)`

When inspecting Box 620 and adjacent finding aids, explicitly watch for:
- `OKM 4/SKL IIc`, `4/SKL IIcc`, `4/SKL Ia`
- `Schlüssel M`, `Thetis`, `M-Thetis`
- `Schlüsseltafel`, `Schlüsselzettel`, `Zuteilungsliste`, `Schlüsselmittel`, `Funknamen`
- references of the form `4/Skl IIc [number]/45`, especially March–May 1945
- registry/file-number sequences surrounding known 1945 IIc documents
- references/cross-references to TICOM I-24, Brown Lists, DF-225 or captured OKM registries

## Registry-sequence hypothesis
`IIc 140/45` may be usable as an anchor in a 1945 office registry/file-number sequence. Test by collecting independently surviving 1945 documents issued by 4/SKL IIc/IIcc, recording date + reference number + title/function. If numbering is chronological or registry-based, reconstruct the local number interval for March–May 1945 and search for missing Thetis/Schlüssel-M entries.

Status: HYPOTHESIS until the numbering practice is demonstrated from multiple primary documents.

## Why this matters for P1030680
The cryptanalytic bottleneck is provenance/authentication of the applicable May 1945 M-Thetis allocation/key context. A dated allocation list, key log, Schlüsseltafel, registry entry, or authenticated second Thetis witness could materially constrain the key and satisfy ARGUS's compute gate. Organizational provenance alone does NOT reopen compute.

## Active human/archive actions
- Heather / WW2 History Project: copying request for Box 620; follow-up brief adds IIc/IIcc/Ia, the `140/45` reference pattern, TICOM I-24/Brown Lists/DF-225. Box 620 remains the primary task; extra research should be scoped separately.
- NARA Textual Reference: existing RG 457 request already includes NR 1665 and related key/allocation items; separate addition also points to relevant RG 38/CNSG material. Avoid flooding NARA with duplicate follow-ups unless a new concrete identifier appears.
- Jessica Mulein: informed 2026-10-01 of the provenance pivot. Framing: archival search is “substantially less blind”; no claim that IIcc→M-Thetis May 1945 is proven.

## New search vocabulary
German: `4/Skl IIc`, `4/Skl IIcc`, `4/SKL Ia`, `Referatsleiter`, `Geschäftsverteilungsplan`, `Geschäftstagebuch`, `Registratur`, `Aktenverzeichnis`, `Schlüsselmittel`, `Schlüsselmittelverteilung`, `Schlüsseltafel`, `Zuteilungsliste`, `Funknamen`, `g.Kdos.`, `Thetis`.
Allied/postwar: `OKM/4 SKL II`, `TICOM I-24`, `Brown List`, `DF-225`, `German Key Logs`, `naval keys`, `radio names`, `RG 457`.

## Promotion criteria / firewalls
- Do not state that IIcc specifically produced M-Thetis until a source ties IIcc to Thetis or to the relevant Schlüssel-M series.
- Do not treat the British RIP 401 `IIcc` rendering as correction of the German original `IIc` without corroboration.
- Do not identify Stiehler as IIc/IIcc without an explicit source.
- Do not infer chronology from `140/45` until multiple primary references establish numbering behavior.
- Do not restart compute merely because the administrative producer/distributor has been identified.
- Promote a lead only when provenance is explicit and independently checkable.

## Immediate acquisition order
1. Box 620 / NR 1665 German Key Logs, complete images including folder/cover/tab/provenance context.
2. Full TICOM I-24; extract names and subsections.
3. Brown Lists I-10/I-14/I-34; cross-reference names against I-24 and DF-225.
4. Full DF-225; extract exact IIc/IIcc/Ia structure and named personnel.
5. Collect 1945 `4/Skl IIc .../45` primary documents to test registry sequence.
6. Search NARA/Bundesarchiv by identified personnel and registry terminology rather than “Thetis” alone.

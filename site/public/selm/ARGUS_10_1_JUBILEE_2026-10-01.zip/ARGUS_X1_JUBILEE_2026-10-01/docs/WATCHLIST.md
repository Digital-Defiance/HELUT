# ARGUS X Watchlist

## P0 — changes the attack
- Second/raw intercept copy of P1030680 / VROL NMKA.
- Authentic May 1945 M-Thetis key sheet, daily key, Zuteilungsliste, Grund table, or independently constraining Thetis specimen.
- Swedish archival reply containing retained German naval traffic/key material.

## P1 — acquisition
- RG457 HCC Box 620 / NR 1665 / CBKJ17 / 7465A: GERMAN KEY LOGS (FEB 41–MAY 45).
- Recover archived Enigma@Home pages/data for `VROL NMKA` and `m4_vroln72_*` to establish exact historical coverage.
- Trace citations behind Thetis descriptions to primary archival references.

## P2 — discovery expansion
- OCR/fuzzy variants of P-number, indicator, ciphertext prefix and catalog identifiers.
- German/Swedish/Danish/Norwegian archive vocabulary.
- Citation graph from R.I.P. 401, Hörenberg, Ralph Erskine, Bauer, TICOM and NSA/NARA catalog indexes.

## Closed / guarded
- No restart of menu campaign from existing evidence.
- ROT07A withdrawn as a P1030680 lead.
- Travemünde/Neustadt Volksliste wording already crib-negative.
- 368775 has no plaintext.
- Forelle October 1944 allocation is not May 1945 proof.

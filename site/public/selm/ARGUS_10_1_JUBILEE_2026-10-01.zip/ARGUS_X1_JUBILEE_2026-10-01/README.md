# ARGUS X.1 / 10.1 — Jubilee

ARGUS X.1 (10.1) is the archival/internet-discovery successor to ARGUS v9 for P1030680. X.1 adds an ADMINISTRATIVE_PROVENANCE lane for reconstructing who produced, distributed and registered Kriegsmarine naval keys.

## Canonical target
P1030680 — 1 May 1945 — 72 ciphertext letters — indicator VROL NMKA — M-Thetis supported — UNBROKEN.

## What X changes
X adds an INTERNET_DISCOVERY layer. It searches the public internet as a collection of imperfect indexes rather than as one search engine. It expands identifiers into OCR variants, historical aliases and multilingual archive vocabulary; follows citations and catalog identifiers; and records negative searches.

## Epistemic firewall
Every discovery is one of:
HARD / STRONG_PROVISIONAL / HYPOTHESIS / REJECTED_UNSUPPORTED.
A search-engine result is never HARD merely because several mirrors repeat it. Independence is evaluated by provenance.

## Compute gate
Do not restart a cryptanalytic campaign unless a discovery supplies at least one of:
1. an independent/second copy of the intercept;
2. authentic May 1945 M-Thetis key material (or a source that materially constrains it);
3. another independently authenticated Thetis specimen that constrains the daily key;
4. an archival fact that creates a genuinely new, source-grounded crib/constraint.

## X.1 administrative-provenance delta
The new lane follows `4/SKL IIc → IIcc → naval-key production/distribution` in parallel with `4/SKL Ia → document registration`, anchored by the surviving 1945 reference `OKM 4/Skl IIc 140/45 g.Kdos.`. It adds TICOM I-24, Brown Lists I-10/I-14/I-34 and AFSA DF-225 as personnel/organization targets. See `ARGUS_X1_ADMINISTRATIVE_PROVENANCE.md`.

Critical guardrail: IIcc→M-Thetis is a strong research hypothesis, not yet a proved specific attribution; the German Nixe source says IIc while British RIP 401 renders IIcc.

## Priority acquisition targets
A. NARA/NSA RG457 HCC Box 620, NR 1665, CBKJ17, 7465A — GERMAN KEY LOGS (FEB 41–MAY 45).
B. A second/raw intercept witness for P1030680 / VROL NMKA, including reception metadata.
C. May 1945 Thetis Zuteilungsliste / Tagesschlüssel / Schlüsselzettel / Grund material.
D. Swedish archival/FRA response or retained German naval intercept/key material.
E. Web-archive remains of Enigma@Home's 2013 VROL NMKA campaign.

## Important guardrail
The online Forelle Zuteilungsliste is October 1944. Its column allocation is historical evidence, not proof of the 1 May 1945 allocation.

# U3030 / U3032 / U2540 — 1 May 1945 event hypothesis

Status: PLAUSIBLE / TESTABLE HISTORICAL HYPOTHESIS. Not a P1030680 attribution.

## Working scenario

The three Type XXI training boats are separated during the final Baltic evacuation movement; U3030 is behind U3032 and U2540. During the interval before the boats are documented together at ROT07A/AO7819 at 1800 on 1 May, radio communication may have contributed to re-establishing contact or a rendezvous. P1030680 falls on the same date and is M-Thetis, the training-network context relevant to Baltic U-boats.

## Why it matters

The hypothesis gives ARGUS a historically constrained event window and a falsifiable attribution target. It does not provide a crib by itself.

## Evidence/status boundaries

- DIRECT/PRIMARY to seek: original ZTPG 369139; original P1030710 sheet and full surviving groups; P1030680 reception metadata; applicable Thetis procedure/key-allocation material.
- DOCUMENTED/SECONDARY or retrospective: U3030 crew narrative about departure, attack, radio watch/contact. Verify chronology against contemporaneous records because retrospective dating may be unstable.
- INFERENCE: U3030 was attempting to locate/rejoin U3032/U2540 by Thetis.
- SPECULATION ONLY: any proposed wording of P1030680.

## Falsifiers / reducers

- Metadata dates/times P1030680 outside the separation window.
- Sender/recipient/circuit identification unrelated to this boat cluster.
- Thetis procedure showing the relevant transmission direction impossible for the proposed sender.
- Primary chronology showing the three boats were already together when 0680 was transmitted.

## Promoters

- Primary radio metadata tying 0680 to U3030/U3032/U2540, their control station, or their circuit.
- A Thetis traffic rule/specimen demonstrating comparable boat-to-boat or boat-to-control rendezvous/position traffic.
- Recovery of missing P1030710 material explicitly describing the reunion or the other two boats.

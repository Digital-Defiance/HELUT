# ARGUS V5 — 27 September 2026

V5 carries forward the complete V4 research state and adds the 1 May operational-event hypothesis around U3030, U3032 and U2540.

## New in V5

A new bounded historical branch asks whether P1030680 could belong to communications associated with the separation and reassembly of the Type XXI training boats U3030, U3032 and U2540 on 1 May 1945.

This is a **historical attribution hypothesis, not a plaintext claim and not a cryptanalytic solution**. It must not seed machine plaintext as fact.

Current chain to test:

1. U3030, U3032 and U2540 form a relevant late-war Type XXI training-boat cluster.
2. U3030 is reported in the surviving crew narrative as leaving after U3032/U2540 amid the Swinemünde evacuation context and subsequently maintaining radio/Morse watch; later radio contact with the two boats is described.
3. British SIGINT record ZTPG 369139 places U2540 + U3030 + U3032 together at ROT07A / AO7819 at 1800 on 1 May.
4. The U-534 corpus contains P1030710, attributed to U3030/Luttmann, with surviving material that appears closely related to the 1800 anchoring event; the damaged/missing `MIT...` region is especially important. Exact equivalence with ZTPG 369139 remains to be demonstrated from primary records.
5. P1030680 is the 72-character message classified M-Thetis on 1 May. Thetis is historically associated with Baltic U-boat training traffic, making this cluster a contextually relevant population, but this does **not** identify sender, recipient or content of 0680.

## New discriminator

Recover timing, direction, callsign, frequency, Leitnummer/repeat metadata and normal Thetis traffic procedure. Determine whether training boats transmitted as well as received on the relevant circuit. Recover the missing P1030710/ZTPG 369139 material if possible.

## Firewall

Do not promote reunion/rendezvous language (`POSITION`, `TREFFPUNKT`, `KURS`, `WO SIND`, etc.) to plaintext evidence merely because it fits the story. Such vocabulary is scenario-derived only until independently attested in a comparable message or primary record.

V5 preserves V4's acceptance criterion: **no solution without coherent full plaintext and exact full M4 re-encryption**.

# V5 changelog

- Added H7: U3030 reunion-traffic hypothesis.
- Added evidence records E022–E026 with explicit provenance/firewall boundaries.
- Added dedicated 1 May hypothesis note.
- Preserved all V4 files, controls, negative results and compute firewall.
- No new plaintext, key or exact re-encryption claim.
- No scenario-derived rendezvous wording promoted to crib evidence.

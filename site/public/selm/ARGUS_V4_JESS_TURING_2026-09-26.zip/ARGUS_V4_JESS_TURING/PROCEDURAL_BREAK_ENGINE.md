# PROCEDURAL-BREAK ENGINE — V6.3

This layer asks a different question from the crib factory:

> Which historically attested environments predict that the nominal 1-May/Potsdam-like key chain or ordinary German-body scoring is the wrong computational assumption?

It is deliberately orthogonal to Bombe/menu attractiveness.

## Historically licensed branches

**PB3 EARLIER_REPEAT.** Allied technical history documents an extensive VLF repetition service over which practically all U-boat traffic was repeated. A 1-May reception therefore does not, by itself, prove a 1-May original transmission. This licenses adjacent earlier transmission/key-date hypotheses only where radio metadata/timing supports them.

**PB2 GROUP_CIRCUIT_ROUTING.** Allied COMINT documentation says grouped U-boats could shift to a predetermined frequency, appoint one boat as control, and operate there until home communications returned. This licenses a routing/circuit break. It does *not* establish a different M-key.

**PB5 STALE_STICHWORT.** U-466 KTB, 23 March 1944: Küste traffic could not be solved because of `falscher Schlüsselstellung`; the crew believed a Leitnummer carrying a Stichwort change had been missed and switched to Mittelmeerschaltung. This is the strongest empirical control for a nominally legitimate traffic environment becoming unreadable through procedural desynchronisation.

**PB4 THETIS_OFFIZIER.** Outer M-Thetis plus inner Offizier is a scoring-model break: successful outer decryption need not yield German throughout the body.

## Compute discipline

The engine does NOT say “search everything”.
It narrows alternate branches to:
1. nominal Thetis;
2. historically licensed earlier-date/repeat states;
3. same-family stale/desynchronised concrete state;
4. routing-only group-circuit branch without automatic key change;
5. Offizier outer-procedure scoring.

A negative under the ordinary 1-May/Potsdam-like chain must never automatically promote one of these branches to fact. The branch remains a historical prior until independently supported by provenance or a full decrypt/re-encryption.

## Acceptance
No branch counts as solved without coherent full 72-character plaintext and exact full M4 re-encryption.

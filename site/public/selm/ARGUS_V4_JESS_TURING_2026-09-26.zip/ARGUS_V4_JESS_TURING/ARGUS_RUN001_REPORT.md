# ARGUS v2.0 — RUN 001

## Outcome
No decrypt and no new Thetis daily key were found. The run instead tightened the evidence graph and acquisition priorities.

### Confirmed
- P1030680 remains target-specifically reconstructed as M-Thetis after two failed Potsdam attempts.
- Forelle / Prüfnr. 3596 independently documents `M Thetis (M Tht)` as a distinct key-net allocation (columns 671–703).
- Public HELUT material still treats P1030680 as the sole M-Thetis item in its 48-message broken comparison corpus and records the 1-May Potsdam/Plaice daily-key branches as exhausted against the target.
- NARA/CNSG catalog targets 5750/781 and 5750/218 are real and remain high-value acquisitions.

### Not found
- No independently identifiable second M-Thetis transmission.
- No indexed Thetis Schlüsseltafel/daily key for April/May 1945.
- No public content scan of 5750/781 or 5750/218.

### ARGUS decision
Do **not** widen compute space from these negatives.
The highest-information move remains source acquisition:
5750/781 + 5750/218 + original P1030680 radio metadata + 2499/1772a provenance + second Thetis witness.

### Firewall state
- Neighboring Potsdam settings remain blocked from inheritance into 0680.
- `228 Grundstellungen` remains quarantined.
- Group-circuit evidence remains routing-only unless independent key evidence appears.
- Historical priors remain independent of menu/Bombe attractiveness.

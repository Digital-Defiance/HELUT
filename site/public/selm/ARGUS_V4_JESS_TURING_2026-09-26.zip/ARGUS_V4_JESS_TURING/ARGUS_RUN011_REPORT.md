# ARGUS v2.0 — RUN 011: CANADA DEEP HARVEST

## Major result: U-889 is much more valuable than expected

The Canadian N.I.D.3 interrogation report does not merely describe U-889.
It proves that **secret operational documents survived aboard the submarine into Canadian custody**.

The report explicitly says:
- secret Orders of the Day for 30 and 31 March 1945, issued at Horten, were found aboard;
- a **Top Secret order of 21 March 1945** was also found aboard.

That materially changes the Canadian branch.

U-889 had passed through:
Stettin → Danzig → Pillau → Hela → Gdynia → Bornholm tactical training → Horten → Kristiansand → Atlantic → Canadian surrender.

It is therefore a strong control for the exact ARGUS question:
**what paperwork survived when a boat moved from Baltic training into the Norway/front-boat system?**

This does not prove Thetis material survived aboard U-889.

## Exact Canadian archival handles

Published Canadian naval research provides several direct LAC targets:

### RG24, Series D-10, Vol.11565, File D20-35-3
`HMCS U-889`

### RG24, Series D-10, Vol.11116, File 66-1-1
Contains Canadian NRE Report **PHx-59**, 7 Nov 1945:
`Report on ex-German Submarine U-889, with Appendix on ex-German Submarine U-190`

### RG24, Vol.11545
Immediate U-889 surrender reporting.

Official Canadian research history independently confirms that U-889 was technically examined and that information on captured German equipment was rapidly transmitted to NSHQ.

## DHH 97/3 becomes navigable

The finding aid gives internal handles:
- Series 2: SRGN translations, including **SRGN Series A-1 and A-2**
- Series 4: SRMN intelligence summaries, including **SRMN 022 and SRMN 37-32 through 37-80**
- Series 5: radio intelligence bulletins

This is enough to stop treating DHH 97/3 as one undifferentiated collection.

## Highest-value next move

The strongest Canadian needle is now not a keyword search for `Thetis`.

It is:
**recover the complete U-889 captured-paper packet/inventory.**

The NID.3 report proves such papers existed.
If the cited secret orders have exhibit numbers, translation identifiers or forwarding annotations, neighboring items may expose:
- radio orders;
- key-change notices;
- training paperwork;
- cipher/procedure documents;
- destruction instructions;
- Norway/Baltic transition material.

## Firewall
No Canadian Thetis document has yet been found.
U-889 is a provenance/control population, not evidence that Thetis remained aboard.

## RUN012
1. Attack LAC Vol.11565 File D20-35-3.
2. Attack Vol.11116 File 66-1-1 / PHx-59.
3. Trace the captured 21 March and 30/31 March papers as archival exhibits.
4. Enumerate DHH 97/3 SRGN A-1/A-2 around 30 Apr–10 May.

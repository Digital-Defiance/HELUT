# ARGUS v2.0 — RUN 013: U-889 ENIGMA-HARDWARE NEEDLE

## Breakthrough, with an important firewall

A source-reference database built from Arthur Bauer/CDV&T research contains a highly specific entry in its Canadian U-889 cluster:

`SCHLÜSSEL M MZSS NR.1259GVX/41`

and labels the context:

`FUNKANLAGEN AN BORD VON U-889`

The same cluster contains:
`LIST OF APPARATUS ON BOARD 889`
with an annotation including:
`MZSS, GVX/41`.

This is the first concrete Canadian archival pointer found by ARGUS that connects U-889's documented onboard communications equipment to the **naval Enigma equipment family**.

## Do NOT overread it

MZSS is not a Tagesschlüssel or Grund table.

It is the external power-supply unit used by the naval Enigma **Schreibmax** printer. A wartime captured-equipment inventory for U-505 independently demonstrates the distinction: it lists Enigma machines, an MZSS transformer, printer, and cipher aids as separate objects.

Therefore RUN013 does **not** establish:
- Thetis aboard U-889;
- a surviving Thetis daily key;
- a surviving Grundtabelle;
- even yet the serial number of U-889's Enigma itself.

It establishes a much better acquisition target:
**the original Canadian onboard-apparatus inventory.**

## The survival model gets richer

N.I.D.3 says Braeucker destroyed on 8 May:
- Funk Kladde
- Kriegstagebuch
- Tauch Tagebuch

but overlooked:
- documents already cited by interrogators;
- **certain loose W/T messages**;
- an updated copy of **Staendige Kriegsbefehle B.d.U.**

The report then transcribes recovered late-war W/T traffic and says that despite poor May reception, almost all control messages were eventually obtained through **control repetitions**.

This means Canada held not only technical hardware and March orders, but an actual residue of U-889's final radio-message environment.

## New archival neighborhood

Bauer's index associates the U-889 packet with National Archives Canada **RG24 accession 1983-84/167** and a garbled reference containing `BOX 3741` plus file-number fragments.

This cannot yet be cited as the exact file. It is now a finding-aid resolution problem.

## RUN014 priority

1. Recover the original `LIST OF APPARATUS ON BOARD 889`.
2. Recover Bauer's LIT [242a] packet / Z969 source pages.
3. Resolve the RG24 1983-84/167 box/file reference.
4. Extract every surviving loose W/T message from U-889.
5. Trace the separate Canadian report on the recovered `Staendige Kriegsbefehle B.d.U.`
6. Determine whether MZSS No.1259 / GVX-41 can be joined to an Enigma or MZSE serial.

The key shift is:
**Canada now offers a documented Enigma-hardware + surviving-W/T-paper trail aboard a Baltic-trained boat that transitioned through Norway.**

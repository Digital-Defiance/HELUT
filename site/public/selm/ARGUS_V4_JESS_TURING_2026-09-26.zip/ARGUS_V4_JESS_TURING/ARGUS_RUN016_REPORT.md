# ARGUS v2.0 — RUN 016: SCHLÜSSELMITTEL TAXONOMY

## Main result

RUN016 produces a terminology breakthrough.

The Bundesarchiv catalogue describes **M.Dv. Nr. 434** as a
`Sammelmappe für Schlüsselmittel`.
Its contents include:
- rules for preserving key security when Schlüsselmittel are lost;
- `Der Schlüssel M - Allgemeine Bestimmungen`;
- `Der Schlüssel M - Verfahren M Offizier und M Stab`.

Even more important, an OKM order introducing **Schlüssel Neptun** says:
`Hierzu werden folgende Schlüsselmittel benutzt`
and lists both the **Schlüssel M Form M4** and the **Schlüsseltafel Neptun**.

Therefore a **Schlüsseltafel is demonstrably a Schlüsselmittel** in official Kriegsmarine usage.

This does NOT prove that U-889's Canadian phrase
`coding material for future use`
translated the German word `Schlüsselmittel`.
Nor does it prove that the spared material contained Grundtafeln.

But it removes an important lexical objection:
**Grund-/Schlüsseltafel-class material is compatible with the documented umbrella category Schlüsselmittel.**

## U-260 becomes a physical taxonomy control

The published inventory of secret papers recovered from U-260 is remarkably broad:
RHV Offizier; Schlüsselheft 17; RHV Tauschtafelweiser; Kenngruppenhefte; Kurzsignalheft 1944 I/II;
Doppelbuchstabentauschtafeln `Meer`; Funkspruchheft `Ursula`; Schlüsselheft F;
`Der Schlüssel M - Verfahren M Offizier und M Stab`; E.S.-Tafel 4.

This gives ARGUS an empirical picture of what a late-war U-boat cryptographic paper suite could contain.

Experience FT 136 also uses the phrase:
`Schlüssel M und Schlüsselmittel`
showing that wartime German usage could distinguish the Schlüssel-M system from the broader family of cipher aids/material.

## Effect on the 7–8 May hypothesis

The hypothesis becomes narrower:

1. 7 May: some `coding material for future use` is spared.
2. Official terminology proves key tables can belong to the broader class `Schlüsselmittel`.
3. 8 May: U-boat cipher keys are announced compromised.
4. A few days after 5 May: Hut 8 hears Grund tables have been captured.

This is now **lexically plausible but still documentarily unjoined**.

The German original of 2046/7 is the decisive next document.

If it says `Schlüsselmittel für den weiteren Gebrauch` or a close equivalent,
the capture-survival model strengthens materially.

If it names a narrower category excluding daily/Grund tables,
the hypothesis weakens.

## RUN017

Highest-value move:
obtain **M.Dv.434 / BArch RM 6/1614** and recover the official loss/destruction taxonomy,
while continuing the hunt for the German original of 2046/7 and the 8-May compromise signal.

This is now a terminology-and-provenance problem, not a semantic guessing problem.

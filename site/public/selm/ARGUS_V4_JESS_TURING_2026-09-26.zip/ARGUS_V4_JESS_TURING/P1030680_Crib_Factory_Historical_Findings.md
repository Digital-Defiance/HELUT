# P1030680 Crib Factory — Historical Findings (First Run)

## WHAT THE SOURCES ESTABLISH

The first run supports a disciplined crib factory built from **actual late-war naval telegraphese**, not reconstructed prose. The strongest corpus is the solved U-534 message set around 30 April–1 May 1945. It preserves exactly the register we need: routing blocks (`VVV`, `VON`, command addressees), urgency and radiogram markers (`SSD`, `FFF/TTT`), movement orders, harbour instructions, group movement, radio-circuit references, acknowledgements, and key/procedure warnings.

Several 1 May messages are especially valuable. P1030698 contains the compact order `TRAVEMUENDEBLEIBEN ... WEITEREBEFEHLE...`; P1030696 combines a position report with `FOLGEVERBAND`; P1030693 contains movement to Neustadt plus `MARSCHFAHRT` and a `SCHALTU...` circuit reference; P1030699 is a radio-control warning prompted by many unclear radiograms and points to the 1200 key-change environment. P1030700 is a multi-boat departure report from Warnemünde. These are independent of the unknown plaintext of P1030680.

The radio-history branch is also source-grounded. The US Navy technical COMINT history explicitly describes a “Group Circuit”: when grouped U-boats lost normal contact with home stations, all shifted to a predetermined frequency, one boat became control, and group communications continued until return to the assigned circuit. Walter Kennhöfer’s U-466 recollection independently describes the same training mechanism: simulated loss of the home Leitstelle, a specified Sonderfrequenz, one boat taking radio control, announcement on the normal wave, then a prepared message on the Gruppenwelle enciphered with Maschinenschlüssel M. This establishes the **mechanism**, not a Thetis identification.

U-466’s March 1944 KTB provides an equally important failure-mode control: Küste traffic could not be solved “wegen falscher Schlüsselstellung”; the crew suspected a missed Leitnummer/Stichwort change and switched circuit. Thus a nominally correct traffic classification can coexist with receiver-side inability to decipher.

For Offizier, the first run remains intentionally conservative. A primary 1945 M-Nixe instruction states that its second stage is treated like M Offizier/M Stab under M.Dv.32/1 §§81ff., and preserves an outer procedural example using `SONDER...`. That is enough to justify a separate D branch, but not enough to invent ordinary Offizier markers. The factory therefore exports only the directly attested Nixe outer fragments and marks primary M.Dv.32/1 Offizier examples as a gap.

## WHAT THE SOURCES MAKE PLAUSIBLE

The surviving P1030680 sheet need not describe U-534’s own situation. The solved corpus shows U-534’s papers contained traffic addressed to training commands, other boats, flotillas, tenders and general recipients. A foreign/incidental-reception model therefore deserves its own crib population.

The 1 May environment also makes short movement/group/order language more useful than dramatic narrative guesses. Independently attested forms include remaining in a harbour, awaiting further orders, setting out for Neustadt, passing a point westbound, meeting another boat at a position, following a formation, and departing Warnemünde with a multi-boat group. These are now candidates because they occur in authentic traffic, not because they “sound right” for P1030680.

A repeat/earlier-transmission branch remains plausible because the radio system used control/repetition procedures and reception time is not necessarily time of origin. The factory therefore keeps 30 April material (notably P1030669 and the 30 April message referenced by P1030705) separate but eligible under Scenario C.

## WHAT REMAINS SPECULATIVE

No source harvested in this run proves `GRUPPENWELLE = M-THETIS`. No source proves U-534 was sender or intended recipient of P1030680. No source yet proves the original transmission occurred on 1 May, or identifies its radio circuit/frequency.

The Thetis attribution remains a strong working classification but retains the edition-compatibility caveat already present in the project: the surviving table-selection evidence and the surviving `Quelle` Tafel A set are not yet documentary proof that the exact editions belonged together operationally.

No second independently identifiable M-Thetis transmission was verified in this first run. P1030680 is explicitly excluded from that count.

## WHAT WOULD MOST CHANGE THE SEARCH

1. Recover the original P1030680 sheet and immediate neighbours at image level and transcribe **all** radio metadata without inference.
2. Recover original DEFE3 pages for ZTPG 367822, 369045, 369054 and 369140. HMA establishes the associated movements, but the original decrypts/headers are needed for exact register and timing.
3. Harvest M.Dv.32/1 §§81ff. directly for M Offizier outer procedure.
4. Find a second M-Thetis specimen, solved or unsolved, with independent classification.
5. Harvest Baltic training Funkkladden/Funkbücher and flotilla radio material for 30 April–2 May.
6. Recover the exact cryptanalytic coverage of the prior negative `FFFTTTBLEIBTBESETZT + NEUSTADT` constellation.

The first-run factory contains a deliberately small, provenance-rich Tier-1 set. Its purpose is to let computation reject history-derived candidates without allowing Bombe behaviour to rewrite the historical ranking.

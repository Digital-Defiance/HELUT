# P1030680 HARVEST × CRIB MACHINE v1

This bundle merges the **multi-search harvesting workflow** and the **historical crib factory** into one auditable pipeline.

## The loop

**SEARCH → CAPTURE → REVIEW → EXTRACT → DEDUP → NO-SELF FILTER → SCORE → SCENARIO EXPORT → GAP FEEDBACK → SEARCH AGAIN**

The key rule is that search results never become cribs automatically.

### 1. SEARCH
`harvest_queue.csv` contains a query lattice across:
- M-Thetis / training traffic;
- incidental reception;
- Gruppenwelle / Group Circuit;
- repeat/programme traffic;
- Offizier/Stab;
- key-desynchronisation;
- exact ZTPG/P103 targets;
- priority domains.

### 2. CAPTURE
Put search discoveries into `harvest_hits.csv`.

### 3. REVIEW
A hit may be marked `APPROVED` only when the proposed phrase is actually visible in the cited source.
Use `provenance_grade=PRIMARY` or `DIRECT` only for genuine plaintext/procedural wording.
Database/event summaries may be kept as metadata but **must not be reverse-translated into cribs**.

### 4. EXTRACT
In `authentic_plaintext`, semicolons separate reviewer-approved contiguous phrase units.
Telegraphic spelling must be preserved.

### 5. PROMOTE
Run:
`python crib_machine.py promote`

The script:
- deduplicates phrase+source;
- assigns evidence tier conservatively;
- runs the Enigma no-self test against all target alignments;
- appends to `crib_master.csv`;
- writes fingerprints to `dedup_ledger.csv`.

### 6. EXPORT
Run:
`python crib_machine.py export`

This creates separate A/B/B2/C/D/E candidate files. The machine deliberately does **not** create one master historical ranking.

### 7. FEEDBACK
`harvest_gaps.csv` and `p1030680_provenance_wanted.csv` determine the next search cycle.

## Contamination firewall
- Ciphertext alignment cannot increase historical scores.
- P1030680 cannot validate its own Thetis classification/register.
- Event summaries are metadata, not plaintext.
- Tier 4 is quarantined.
- Negative Bombe/menu results stay in `negative_results.csv`.
- Group Circuit ≠ M-Thetis unless independently proven.
- Radio circuit ≠ cryptographic key.
- Receiving boat ≠ sender/recipient.

## Current strongest machine branches
1. **Late-war authentic U-534 plaintext** for register/formula mining.
2. **NHHC Group Circuit / training-radio procedure** for B2 structural constraints.
3. **M.Dv.32/2 Offizier/Stab** for Scenario D structure.
4. **DEFE3/HMA serial targets** for exact late-April/May plaintext recovery.
5. **Second independent M-Thetis witness** as the highest-value open target.

## Files
Existing v2 factory files remain intact. New machine files are:
- `machine_config.json`
- `harvest_queue.csv`
- `harvest_hits.csv`
- `dedup_ledger.csv`
- `crib_machine.py`
- `MACHINE_README.md`

This is designed so a future harvest can be dropped in without rewriting the methodology.

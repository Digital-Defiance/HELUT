# ARGUS KNOWN-FINDINGS GATE — added RUN018

Before promoting any finding as NEW:

1. Search all ARGUS_RUN*_FINDINGS.csv.
2. Search ARGUS reports and manifest.
3. Search historical_compute_bridge.csv, source_corpus.csv, m_thetis_candidates.csv and procedural-break files.
4. Classify result as:
   NEW / REFINEMENT / CONFIRMATION / KNOWN / CONTRADICTION.
5. Only NEW and materially stronger REFINEMENT items may headline a run.
6. Never regenerate a retired target unless new evidence changes the question.

Retired as a discovery target:
- Q107: discovering that column 645 moved from Aegir to Thetis.
  The project already knew the late Thetis allocation/provenance problem.
  The unresolved task is primary provenance/edition compatibility, not rediscovery of the move.

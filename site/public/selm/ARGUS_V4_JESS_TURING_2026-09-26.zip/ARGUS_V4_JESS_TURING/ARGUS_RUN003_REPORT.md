# ARGUS v2.0 — RUN 003: CITATION-CHAIN ATTACK

## Breakthrough in acquisition topology

RUN003 does not decrypt P1030680, but it converts RIP425 from a vague citation into a retrievable archival object.

The NSA war-history inventory identifies **R.I.P. 425 — THE AMERICAN ATTACK ON THE GERMAN NAVAL CIPHERS**, prepared by **GYA-1 & 2**. Its structure is unusually relevant to ARGUS:

- Chapter I — Introduction
- Chapter II — Problems and Solutions
- Chapter III — Research and Development
- Chapter IV — Operations as a Going Concern
- Chapter V — histories of:
  - Traffic Group
  - Crib Group
  - Bombe Group
  - Decryption Group
  - Communication Group
  - Sub Section Watch Officer

The inventory indicates coverage through **May 1945**.

More importantly, it supplies a storage handle: **AFSA-0.3A3; microfilm in archives**.

## NARA crosswalk

A scholarly cryptologic-history citation independently points the OP-20-G/GYA RIP425 material and the 7 July 1944 `American Cryptanalysis of German Naval Systems` toward **NARA RG38 CNSG Library 5750/205, Box 117**.

The CNSG finding aid independently confirms:
**5750/205 — OP-20GY-A / GY-A-1 (1 of 4 ... 4 of 4), Box 117.**

This is the strongest acquisition shortcut found so far.

## Why it matters to ARGUS

RIP425's Traffic and Crib Group histories are potentially more useful than another broad Thetis web search. Even if Thetis is never named, these chapters may expose:

- how special/unreadable naval networks were classified;
- how message beginnings and signatures were harvested;
- how indicator/procedure changes were tracked;
- how captured key documents entered operational cryptanalysis;
- how crib doctrine differed by traffic population;
- what remained unresolved through May 1945.

That maps directly onto ARGUS's Crib Factory and Procedural-Break Engine.

## Negative discipline

The searchable NSA inventory contains no `Thetis` or `Schluessel` hit. This says nothing about the full RIP425 text, which has not yet been acquired.

No historical hypothesis is promoted in RUN003.

## Revised acquisition order

1. **5750/205 Box 117** — inspect all four OP-20GY-A/GY-A-1 parts.
2. **RIP425 microfilm, AFSA-0.3A3**.
3. **NSA CCH R Collection Box CCO 66** — OP-20-GY-A, 7 July 1944.
4. Then return to 5750/781 and 5750/218 with references harvested from these histories.

This is now a document-chain attack rather than a keyword search.

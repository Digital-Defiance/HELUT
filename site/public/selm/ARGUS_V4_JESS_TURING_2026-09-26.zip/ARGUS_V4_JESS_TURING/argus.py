#!/usr/bin/env python3
from pathlib import Path
import csv,json
R=Path(__file__).resolve().parent
def rcsv(n):
    with open(R/n,encoding="utf-8",newline="") as f:return list(csv.DictReader(f))
def main():
    m=json.loads((R/"ARGUS_RUN_MANIFEST.json").read_text())
    e=rcsv("ARGUS_evidence_ledger.csv"); h=rcsv("ARGUS_hypothesis_graph.csv")
    w=rcsv("ARGUS_WATCHLIST.csv"); p=rcsv("ARGUS_PROMOTION_RULES.csv")
    print("ARGUS",m["version"],"—",m["target"])
    print("active hypotheses:",len(h))
    print("evidence records:",len(e))
    print("watchlist items:",len(w),"(critical:",sum(x["priority"]=="CRITICAL" for x in w),")")
    print("promotion rules:",len(p))
    print("quarantined claims:",",".join(m["quarantined_claims"]))
    print("acceptance:",m["acceptance"])
if __name__=="__main__":main()

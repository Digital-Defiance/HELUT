# ARGUS v2.0 — RUN 008: GRUND SOURCE-OF-NEWS + NORWAY REACTIVATION

## Major convergence

RUN008 keeps the Mahon source-of-news hunt active and reopens the Norwegian branch under stricter evidential rules.

The strongest new chronological bridge is an official U.S. Navy cryptologic history:
**on 8 May 1945 German naval traffic announced that U-boat cipher keys had been handed over to the enemy.**

Mahon independently says that a few days after 5 May Hut 8 stopped work after hearing that the **Grund tables had been captured**.

ARGUS does not equate those statements yet. But they now occupy the same very narrow surrender window and must be cross-correlated.

## Norway returns — but in a different role

Norway should not be treated as evidence that P1030680 itself is Norwegian traffic:
- Thetis = Baltic tactical-training key.
- Niobe/Narwhal = northern U-boats based in Norway.

The useful Norwegian question is instead:
**what cryptographic material travelled with boats, commands and surrendering U-boat infrastructure between the Baltic/Germany and Norway during the final days?**

This matters because many boats survived in Norwegian ports and passed into Allied custody.

## New archival needles

Two NSA Historic Cryptographic Collection entries are exceptionally relevant:

### NR332 / accession 6609A
`GERMAN CIPHER TABLES FOR NORTH SEA, BALTIC SEA AND NORWAY`

This is now one of ARGUS's highest-value targets because its title explicitly bridges the geographic zones involved in the P1030680 transition problem.

### NR1665 / accession 7465A
`GERMAN KEY LOGS (FEB 41 - MAY 45)`

The end of this log overlaps P1030680 and the German surrender exactly. If it records Schlüssel-M names, change dates, compromise events or custody, it could materially reduce the search.

Also elevated:
### NR328 / accession 6445A
`GERMAN NAVAL HIGH COMMAND BALTIC SEA COMMUNICATIONS` (1945)

## Operational control

The U-889 interrogation report records poor German W/T reception in May but says nearly all control messages were eventually obtained through **control repetitions**.

This gives ARGUS a real late-war control for Scenario C:
a sheet's reception context need not equal the original transmission context.

## What was NOT found

No indexed source was found explicitly placing Thetis key material at Bergen, Trondheim, Kristiansand, Horten or Stavanger in May 1945.

Therefore:
**NORWAY ≠ THETIS** remains a hard firewall.

## RUN009

Run two synchronized attacks:

1. **8-May compromise chain**
   - identify the original German signal saying U-boat keys had been handed over;
   - determine which keys/tables, where captured/handed over, and whether this is the event Mahon heard about.

2. **Norwegian custody/distribution chain**
   - NR332 / 6609A;
   - NR1665 / 7465A;
   - NR328 / 6445A;
   - surrender/inventory records for Norwegian U-boat bases;
   - boat-level Baltic→Norway transition matrix.

The goal is no longer “find Thetis in Norway.”
It is:
**find where the late-war key/procedure material physically went.**

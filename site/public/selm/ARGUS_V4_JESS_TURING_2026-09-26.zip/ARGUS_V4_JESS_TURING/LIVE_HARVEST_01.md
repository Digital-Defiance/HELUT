# LIVE HARVEST LOOP 1

## Result
Promoted **29 new Tier-1 fragments**. Factory now contains **99 cribs**.

## High-value gains
1. **P1030709** gives an authentic late-war retransmission/error vocabulary: `FUNKSPRUCHMITUHRZEITGRUPPE`, `HIERSEHRVERSTUEMMELT`, `GRUPPEVOLLKOMMENUNKLAR`, `NACHPRUEFEN`, `NEUVERSCHLUESSELTABSET...`.
2. **P1030673 / DEFE 3/578 p722** gives `WARTEAUFUUULEITSTELLE`, an unusually relevant exact Leitstelle phrase from the same surviving U-534/ULTRA environment.
3. **P1030662 / DEFE 3/577 p765** gives a three-boat movement order with `MITUUU...`, `ZURFLENDERWERFTLUEBECKGEHEN`, and `FONDORTFOLGTWEITERES`.
4. **U-466 Funkkladde** adds independently authentic group/circuit language: `GRUPPESCHILL`, `LEITNUMMER...`, course + maximum speed, `WIEBEFOHLENSOFORTTAUCHEN`, and `RUECKMARSCH`.
5. **P1030706/P1030712** add escort/onward-movement register directly tied to U-534.

## Guardrails
- R.I.P. 401's `671–703 M Thetis (M Tht)` allocation is stored as classification evidence and generates **no plaintext crib**.
- U-466 group language is Tier 1 as language but scores lower on date/geography than 1945 Baltic material.
- No `GRUPPENWELLE = M-THETIS` promotion was made.
- No HMA English/Dutch event summary was reverse-translated into German.

## Next highest-value gaps
- exact DEFE3 text for ZTPG 367822 / 369045 / 369054 / 369140;
- original P1030680 sheet radio metadata;
- a second independent M-Thetis specimen;
- Baltic training Funkkladde/Funkbuch language matching the U-466 group mechanism.

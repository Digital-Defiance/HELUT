# ARGUS v2.0 — RUN 009: 8-MAY JOIN + NORWAY/HCC CLUSTER

## Executive result

RUN009 does not yet recover the original 8-May German signal, but it strengthens the archival attack in two ways.

### 1. The 8-May / Mahon join is now the right chronological needle

The official OP-20-G history says:
- April: compromise of the U-boat Reserve Hand Procedure was announced.
- 8 May: German naval traffic announced that **U-boat cipher keys had been handed over to the enemy**.

Mahon independently records Hut 8 hearing, a few days after 5 May, that **the Grund tables had been captured**.

ARGUS still refuses to equate these statements. But the problem is now bounded:
recover the German 8-May signal and determine exactly what class of key material it described.

### 2. The Norway branch has become an archival-cluster attack

Three exact HCC objects now dominate:

- **NR1665 / 7465A — GERMAN KEY LOGS (FEB 41 - MAY 45)**
- **NR332 / 6609A — GERMAN CIPHER TABLES FOR NORTH SEA, BALTIC SEA AND NORWAY**
- **NR328 / 6445A — GERMAN NAVAL HIGH COMMAND BALTIC SEA COMMUNICATIONS (1945)**

NR1665 is particularly important because its terminal month is exactly May 1945.

ARGUS also identified a surrounding HCC naval-crypto neighborhood:
- NR262 — cipher tables for West Baltic & North Seas
- NR265 — German ciphers H and M / Code M Hydra
- NR268 — German indicator books, tables, groups
- NR270 — German code and cipher tables, books and documents

This suggests collection-level provenance may be more productive than isolated title searching.

## Norway firewall

Niobe/Narwhal was the operational cipher for Norway-based northern U-boats; Thetis was Baltic tactical training.

Therefore the Norway branch asks:
**what key/procedure material survived, moved, or was surrendered?**

It does not ask:
**was Thetis secretly the Norway key?**

## Crib Factory side-result

P1030684 remains useful as an authentic late-war multi-boat movement-register control. Its telegraphic plaintext can seed source-attested formula extraction for movement/group scenarios, but cannot be promoted merely because P1030680 is nearby in the surviving U-534 material.

## RUN010

Priority:
1. attack the terminal Apr/May pages of NR1665;
2. determine internal contents/date span of NR332;
3. recover the original 8-May compromise signal;
4. search the HCC naval-crypto cluster as one provenance family;
5. continue Norway surrender inventories as a custody track.

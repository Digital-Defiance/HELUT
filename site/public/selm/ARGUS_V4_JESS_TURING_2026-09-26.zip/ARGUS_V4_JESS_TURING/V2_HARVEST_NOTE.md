# P1030680 Crib Factory — v2 Harvest Note

## Major correction: Offizier procedure
The first run followed the project prompt in looking for M.Dv.32/1 §§81ff. The dedicated primary regulation is actually **M.Dv.32/2, Der Funkschlüssel M — Verfahren M Offizier und M Stab**. Its §10 is exceptionally useful for the crib factory because it defines the plaintext structure handed to radio personnel before the second (M Allgemein) encipherment:

**Address → VON → Signature → OFFIZIER or STAB → one message-setting indicator letter → first-stage ciphertext groups.**

M.Dv.32/2 §§15–18 then says radio personnel encipher that whole form under the General procedure. Thus, if P1030680 is Scenario D, an M-Allgemein decryption can contain genuine German procedural markers near the beginning followed by material that is ciphertext-like. The factory now admits literal `VON`, `OFFIZIER`, and `STAB` as direct Tier-1 procedural fragments, but does **not** invent an address, signature, indicator letter, or filler.

## 1 May DEFE3 controls
The HMA/DEFE3 crosswalk independently anchors four high-value events:
- ZTPG 367822: U-2361/U-4701/U-4702/U-4703 depart Sassnitz at 10:00 toward Sonderburg.
- ZTPG 369045: at 17:33 BdU directs U-4701/U-4702/U-4703 to Kiel/Howaldtswerke for front equipment.
- ZTPG 369054: the seven-boat Type XXIII group departs Warnemünde at 16:00 toward Kiel.
- ZTPG 369140: U-534 is recorded at 18:00 departing the Kiel-Feuerschiff area, escorted by V201, in the Norway-transfer context.

These are strong **metadata controls**, but the exact original decrypt text did not surface in this web pass. Accordingly v2 creates source records but generates **zero lexical cribs from the HMA summaries**. This is intentional anti-contamination.

## New priority
The most valuable next archival gain is no longer “more plausible late-war vocabulary.” It is the actual DEFE3 page text/headers and the original P1030680 sheet metadata. Those would turn metadata controls into exact telegraphic strings and may sharply improve Tier-1/Tier-2 coverage.

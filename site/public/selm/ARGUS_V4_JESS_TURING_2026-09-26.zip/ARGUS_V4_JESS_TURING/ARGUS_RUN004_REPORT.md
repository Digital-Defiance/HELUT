# ARGUS v2.0 — RUN 004: CAPTURE-PROVENANCE ATTACK

## Main result
RUN004 found a more direct route than waiting for RIP425.

The NSA Historic Cryptographic Collection contains an exact April-1945 item:
**NR 2335 / CBLL51 / accession 35445A — `CAPTURING AND EXPLOITING ENEMY NAVAL DOCUMENTS REPORT, 1945`**.

Independent archival literature identifies the corresponding British report as **TNA HW 8/103**, describing the work of Naval Section VI at GC&CS and 30 Assault Unit in capturing and exploiting enemy naval documents.

Even more important, **TNA HW 8/116** is an accession list of captured documents and explicitly includes a German captured-document sequence **PU/G/1–62**.

This changes the provenance attack. Instead of guessing where Quelle 2499 / 1772a came from, ARGUS can try to reconstruct the capture chain:

`German document → 30 Assault Unit / Naval Section VI → PU/G accession → GC&CS exploitation → U.S. liaison / OP-20-G records → HCC/CNSG copies`.

## New operational source
CNSG **5750/176, Box 113** contains five parts of a GY-A-1/GM/GE Daily War Diary. This is now a critical target for the last days of April and first days of May 1945, because a daily diary can record:
- new or unreadable traffic;
- key/procedure changes;
- receipt of captured material;
- liaison reports;
- special-net handling.

## New procedural source
NSA HCC **NR2334 / accession 35350A — RIP402, German Cryptographic Memoranda, 1943–1945** is a newly elevated target for procedure-change evidence.

## Discipline
No Thetis key, second M-Thetis message, or new decrypt was found.
No hypothesis is promoted.

## Revised top acquisition chain
1. HW 8/116 — German captured-document accession list PU/G/1–62.
2. NR2335 / 35445A = HW 8/103 capture/exploitation report.
3. 5750/176 late-April/May GY-A-1 Daily War Diary.
4. 5750/205 / RIP425.
5. RIP402 German Cryptographic Memoranda.
6. Re-run Quelle 2499 / 1772a provenance against any accession/capture identifiers recovered.

The goal is now to identify the **physical capture lineage** of the procedure documents, not merely find another online reproduction.

# ARGUS v2.0 — RUN 017: LAST WILD DEEP SEARCH

## 1. The strongest finding tonight: the Thetis allocation actually moved

R.I.P. 401 reproduces an October 1944 Zuteilungsliste:
- Kennwort: **Forelle**
- Prüfnr. **3596**
- columns **641–670 = M Aegir**
- columns **671–703 = M Thetis**

But the P1030680 worksheet analysis says the operator's allocation list identified
**ACH / column 645 as M-Thetis**.

Therefore column 645 changed allocation between the October 1944 Forelle edition and the edition used in the P1030680 procedure.

This is a major procedural constraint.

It proves that edition compatibility is not merely theoretical. An older authentic Zuteilungsliste would positively misclassify the target's Schlüsselkenngruppe.

### New hunt
Find the **first post-Forelle Zuteilungsliste in which 645 becomes Thetis**.

That transition may:
- bracket the date of the relevant allocation edition;
- expose the later Prüfnummer/Kennwort;
- reveal whether other Thetis column blocks changed simultaneously;
- give us another route to a second Thetis specimen.

## 2. U-249 becomes a serious — but quarantined — Grund-table capture candidate

U-249 surrendered on 9 May and was brought into British custody at Portland on 10 May.
A substantial set of early-1945 BdU Standing/Current Orders was physically captured aboard and survives.

The set includes an **April 1945 update concerning South Norway**, so this was current operational paperwork.

This aligns strikingly with Mahon's timing:
a few days after 5 May, Hut 8 heard the Grund tables had been captured and stopped work.

But there is still **no evidence that U-249 carried the Grund tables**.

The right question for RUN018 is not `Was it U-249?`
It is:
**What exactly was removed from U-249 on first boarding, and where was it routed during 9–11 May?**

If an urgent cipher packet went Portland → Admiralty/GC&CS, the hypothesis becomes testable.

## 3. Key-sheet destruction was progressive

The U-441 Schlüsseltafel case quotes BdU Standing War Order No.251:
the plugboard-number portions of a Schlüsseltafel were to be cut off and destroyed no later than **four days after expiry**.

The same German proceeding explicitly calls the Triton Schlüsseltafel a **Schlüsselmittel**.

This gives us a much better surrender-survival model:
- expired key material was progressively destroyed;
- current/future material necessarily remained useful;
- therefore a capture at surrender would be biased toward exactly the still-current/future material that could stop Hut 8 work.

This fits the 7-May distinction between material to destroy and material retained for future use, without proving the two orders use identical terminology.

## 4. A new American mega-target

The NSA Historic Cryptographic Collection index contains:

**NR 1665 — CBKJ17 — 7465A — GERMAN KEY LOGS (FEB 41 - MAY 45)**

Box 620.

That date range reaches all the way through the target month.

We do not yet know what kind of `key logs` these are or whether Thetis appears in them.
But this is now one of ARGUS's highest-value acquisition targets.

Adjacent items are:
- 7460A — German Naval Operating Signals
- 7461A — German Q Code and Procedure Signals
- 7464A — Enigma, Offizier and Staff Procedure

That is almost a ready-made ARGUS archival bundle.

## 5. Late Baltic→Norway register

A surviving Allied decrypt from 4 May orders serviceable U-boats at Geltinger Bucht to prepare to leave in subdivisions for southern Norway and report.
A companion message says Norway is the headquarters of U-boat operational control.

These should be harvested in original German/decrypt form for the Crib Factory.
They are independently attested register from exactly the environment surrounding U-534 without assuming P1030680 concerned U-534.

## Bottom line

RUN017 produces three concrete needles rather than another cloud of hypotheses:

**A. Find when column 645 changed from Aegir to Thetis.**
This may recover the missing late Thetis allocation edition.

**B. Acquire NSA 7465A — GERMAN KEY LOGS (FEB 41–MAY45).**
This is potentially the richest unopened US source now on the board.

**C. Reconstruct U-249's first-board capture inventory and routing, 9–11 May.**
This is the cleanest test yet of Mahon's captured-Grund-table event.

The Thetis-allocation change is the strongest new historical finding of this run.

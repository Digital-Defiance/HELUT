# ARGUS v3.0 — Consolidated Evidence + Watchlist

ARGUS v3 preserves the complete v2/RUN018 machine and adds a formal consolidation of the historical information sent to Jessica on 23–26 September 2026.

## What changed
- Added E011–E021 to `ARGUS_evidence_ledger.csv`: Schlüssel-M procedure, Quelle 1772a plan, surviving 2499 Tafel A, acquisition recollection with provenance caveat, Teilfunkspruch mechanism, P1030704/0707 sister-copy lesson, Neustadt/crib tiers, Baltic training context, WEUWY control, and radio-history layer.
- Added `ARGUS_WATCHLIST.csv`: 21 live/open/control lines with expected evidence, next action and explicit promotion rule.
- Added `ARGUS_PROMOTION_RULES.csv`: hard rules preventing interesting leads from silently becoming stronger claims.
- Corrected the stale config naming rule: future integrated builds are ARGUS.
- Preserved every v2 file and RUN001–RUN018 result unchanged except the integrated ledgers/config/status/readme.

## Evidence families
MESSAGE / PROCEDURE / KEY-NET / OPERATIONAL / PROVENANCE / RADIO / CONTROL / ARCHIVE

## Central discovery target
Can P1030680 be independently classified as M-Thetis, and can a SECOND surviving M-Thetis transmission be identified without using P1030680 as the discovery case?

## Non-negotiable provenance gap
The May-1945 Quelle Tauschtafelplan is Prüf-Nr. 1772a. The surviving photographed Quelle Tafel A set is Prüf-Nr. 2499. Their compatibility remains OPEN until documentary provenance establishes the join. Paul Reuvers' acquisition recollection is valuable but remains a lead, not a catalog record.

## Watchlist principle
A watch item is not merely a to-do. Each item states what evidence would change an existing claim and what shortcut is forbidden. Negative compute cannot promote historical priors.

## Acceptance criterion
P1030680 is solved only when the complete 72-character plaintext is coherent in context AND one historically valid M4 configuration exactly re-encrypts the full original ciphertext.

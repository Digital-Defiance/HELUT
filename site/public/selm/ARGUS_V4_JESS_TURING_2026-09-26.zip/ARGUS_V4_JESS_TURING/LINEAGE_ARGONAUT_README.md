# ARGONAUT — P1030680 historical/cryptanalytic research machine

ARGONAUT is the continuing name of the integrated P1030680 research system formerly called
`P1030680_SUPERMACHINE` (through V6.5).

Pipeline:
MULTI-SEARCH → PROVENANCE → M-THETIS DETECTOR → CRIB FACTORY → PROCEDURAL-BREAK ENGINE →
NO-SELF FILTER → V5/HELUT COVERAGE FIREWALL → EXPERIMENT PLANNER → NEGATIVE FEEDBACK → HARVEST.

Hard rule: historical probability is never upgraded because a crib/menu performs attractively against
the target ciphertext.

## Current key finding
The immediate P1030679–P1030680–P1030681 neighborhood is treated as a
Potsdam-compatible solved → M-Thetis-classified anomaly → Potsdam-compatible solved sandwich.
Accordingly, alternate date/synchronization branches for 0680 are THETIS-state branches, not fallback
Potsdam branches.

## Current acquisition target
Search specifically for surviving Thetis/Tetis/U-Boot-Übungsschlüssel key material and procedural
evidence around 30 April–1 May 1945: Tages-/Monatsschlüssel, Schlüsselzettel, Schlüsselunterlagen,
Grund tables, Stichwort/Schlüsselstellung changes, Leitnummer notices, training Funkkladden and
independent Thetis messages.

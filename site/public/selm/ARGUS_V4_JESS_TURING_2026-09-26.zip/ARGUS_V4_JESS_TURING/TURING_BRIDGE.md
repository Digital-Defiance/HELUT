# ARGUS → TURING bridge V2

ARGUS V4 is a documentary/traffic-analysis coprocessor. Turing owns cryptanalytic acceptance.

## Separation firewall
1. Historical attestation is stored independently of inference.
2. Ciphertext fit/no-self/menu score cannot raise historical probability.
3. Traffic fields are atomic: receiver != addressee != sender; transmission time != reception time; circuit != M-key.
4. A radio hypothesis is only a compute hypothesis if `KEY_SEARCH_CONSEQUENCES.csv` says it changes the key search and its evidentiary requirement is met.
5. Exact re-encryption wins.

## Outputs
- `MESSAGE_METADATA.csv` — atomic traffic fields.
- `TRAFFIC_METADATA_QUEUE.csv` — the next-document selector.
- `KBUCH_LOOKUP_FINGERPRINTS.csv` — Jess's Hörenberg lookup strings + ACH/645 target fingerprint.
- `TAFEL_A_STATE.csv` — what Tafel A proves and does not prove.
- `KEY_SEARCH_CONSEQUENCES.csv` — prevents radio-history ideas from spawning unjustified compute branches.
- `CRIB_ELIGIBILITY_V4.csv` — exact-source gate and cross-war/key quarantine.

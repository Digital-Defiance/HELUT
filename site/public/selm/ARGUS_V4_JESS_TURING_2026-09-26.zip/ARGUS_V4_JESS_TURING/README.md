# P1030680 Crib Factory — v1

This is a **historically grounded candidate factory**, not a decryption claim.

## Target
- P1030680 ciphertext length: 72
- Indicator groups: `VROL NMKA`
- M-Thetis attribution is retained with the existing **Tauschtafel / edition-compatibility caveat**.
- P1030680 is excluded from independent M-Thetis discovery counts.

## Evidence tiers
- **TIER 1 — DIRECT**: exact contiguous string attested in an authentic/comparably authentic plaintext or primary procedural example.
- **TIER 2 — FORMULAIC**: attested template with independently justified slot substitution.
- **TIER 3 — CONTEXTUAL**: attested elsewhere in naval/U-boat traffic and strongly relevant.
- **TIER 4 — SPECULATIVE**: plausible reconstruction only; excluded from default Bombe export.

**v1 deliberately contains only TIER 1 candidates.** No lexical slot substitution has yet been promoted to Tier 2.

## Scenario tree
A ordinary genuine M-Thetis; B incidental/foreign reception; B2 local group/Group Circuit; C repeat/earlier transmission; D Thetis+Offizier; E stale/wrong-key desynchronisation.

## Normalization
`exact_string` preserves the harvested telegraphic spelling as entered. Mechanical no-self testing strips non A–Z characters only. X/Y/UUU/VVV/FFF/TTT and operator spellings are not silently modernized.

## No-self filter
For every crib, all 1-based start positions against the 72-letter target are tested. Any alignment with plaintext letter = ciphertext letter at the same position is rejected. `valid_alignment_count` and `valid_positions` record survivors. Survival is **not** treated as evidence of likelihood.

## Contamination controls
1. Historical scores are assigned from source/register/date/geography/radio/scenario provenance only.
2. No candidate receives a higher historical score because it aligns well against P1030680.
3. P1030680 never validates its own historical register.
4. Prior negative menu results are retained separately.
5. Tier 4 is excluded from default exports.

## Adding sources
Add one row to `source_corpus.csv`, preserving exact plaintext and source URL/reference. Extract contiguous strings without modernization. Add provenance and scores before running the no-self alignment function.

## Export for Jessica / Bombe-menu experiments
Start with rows where:
- `attestation_tier` = Tier 1 or Tier 2
- `crypto_usability_score` >= 2
- `valid_alignment_count` > 0
Then test scenario-specific subsets separately. Do not merge A/B/B2/C/D into one historical prior.

## Current gaps
- Original P1030680 sheet metadata: exact reception time, frequency, Leitnummer, callsign, serial, repeat/programme marks, Offz mark, Schaltung, marginalia, sister sheets.
- Primary M.Dv.32/1 §§81ff. text/examples for **M Offizier** (v1 has only a primary Nixe instruction explicitly pointing to that procedure).
- Original DEFE3 pages for ZTPG 367822 / 369045 / 369054 / 369140, not just database summaries.
- A second independently identifiable M-Thetis specimen.
- Late-war Baltic training Funkkladden/Funkbücher and radio assignment material.
- Exact log/coverage for the earlier negative `FFFTTTBLEIBTBESETZT + NEUSTADT` joint-menu run.

## v2 correction and expansion
The dedicated primary manual for M Offizier / M Stab is **M.Dv.32/2**, not M.Dv.32/1 §§81ff. M.Dv.32/2 itself refers back to M.Dv.32/1 for preparation/general procedure. Scenario D now uses the primary §10 structure: Address + `VON` + Signature + `OFFIZIER`/`STAB` + one indicator letter, followed by first-stage cipher groups; the radio operator then applies M Allgemein as the second stage. No address, signature, indicator letter, or dummy filler is invented.

# ARGUS V4 — Jess / Turing

This version implements Jessica's 26 Sep requirements. It is deliberately less eager to generate plaintext and more aggressive about traffic metadata and independent key evidence.

## Start
```bash
python argus_turing.py status
python argus_turing.py metadata
python argus_turing.py fingerprints
python argus_turing.py scenarios
python argus_turing.py cribs --limit 20
```

## V4 rule
**Attestation != inference != ciphertext fit != compute consequence.** None may silently promote another.

The most valuable missing fields are reception time, frequency, Leitnummer, callsign and repeat mark on P1030680/original neighbours. They select the next source to transcribe; they are not bombe inputs.

Crib output is restricted to exact strings with source message, provenance/reuse state, and daily-key-change flag. Hörenberg solved-other-net material and 1943 U-466/Nixe material are quarantined from default 0680 crib emission. **At present `cribs` may correctly return an empty set.**

Full exact re-encryption remains supreme.

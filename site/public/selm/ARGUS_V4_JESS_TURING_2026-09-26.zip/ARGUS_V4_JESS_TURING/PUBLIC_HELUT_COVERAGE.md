# PUBLIC HELUT COVERAGE RECONSTRUCTION — 2026-09-26

The public Digital-Defiance/HELUT campaign record was checked against V5 R1–R8.

## Result
All eight V5 rows are **PUBLIC_NEW_NOT_PRIVATE_LEDGER_VERIFIED**.

No exact public crib+placement match was found for:
GEGENSTELLEN@41; FFFTTTNICHTZ@25; PRUCHMITUHR@23; NACHPRUEFENU@21;
LEITSTELLEXF@6; SCHALTUNGNAN@41; RTEGELEITJLE@37; FFENXFOLGEVE@31.

## What the public ledger *does* establish
- exact >=16 catalog × AAAA: clean negative;
- curated exact/fuzzed top-40 × right rings: clean negative;
- UEBUNG/Thetis-register arms: 73/73 complete, no break;
- catalog was parked at originalIndex 417/2513, with 418–2513 the stated next tranche;
- Selm's first three historical leads: 28/28 exact and 28/28 post-gap placements clean negative;
- P1030668 BLEIBTBESETZT context fixture: 4/4 dead under VIII-fast × middle-ring;
- the public report explicitly says the remaining 294 wheel orders stay open for the VIII-fast-bounded historical lead work.

## Critical limitation
Absence from the public ledger is **not** proof of absence from Jessica's private/local machine-space ledger.
Therefore these rows are not marked LAUNCHABLE automatically. The correct state is:
PUBLIC NEW → PRIVATE LEDGER CHECK / JESSICA CONFIRMATION → RUN.

This distinction prevents the Supermachine from converting a web-search negative into a false coverage claim.

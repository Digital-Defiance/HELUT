# ARGUS v2.0 — RUN 007: LATE-GRUND CAPTURE TOPOLOGY

## Result

RUN007 narrows the late-Grund problem without pretending to identify the capture.

Mahon remains the strongest anchor: Hut 8's history says that a few days after 5 May work stopped when they heard that the **Grund tables had been captured**.

A separate TICOM/30AU history now gives ARGUS a concrete northern-Germany target map:
- Kriegsmarine Y/intercept station — **Neumünster**
- secret U-boat `Kurier` receiving station — **Bokel**
- Kriegsmarine B-Dienst / 4 SKL III — evacuated to the **Naval Signal School at Flensburg**
- a captured late bigram table called **Flusslauf**, due to enter force on 5 May

### Critical correction
`Flusslauf` must not be collapsed into Mahon's captured Grund tables.
The source describes Flusslauf as a **bigram table**, while Mahon separately says **Grund tables**. ARGUS therefore creates two independent provenance objects.

### Timing constraint
TICOM Team 6 as a whole reached Flensburg on 19 May. Mahon's report is only `a few days` after 5 May. Therefore the captured Grund tables cannot be attributed to Team 6's 19-May Flensburg arrival without additional evidence.

Possible routes remain:
- earlier 30AU/British capture in northern Germany;
- surrender handover;
- material captured by another Allied formation and reported rapidly to Hut 8;
- earlier capture whose news reached Hut 8 only after 5 May.

No route is promoted yet.

### P1030680 relevance
This is now a bounded procedural question:
Can the captured late-war Grund-table set be recovered, and does it contain the cells corresponding to P1030680's 14/5 and 14/9 lookups?

That can test the indicator reconstruction independently of the unknown Thetis daily machine key.

### 228 claim
Still quarantined.
Mahon's phrase `Grund tables` does **not** by itself verify the secondary claim of 228 month-valid Grund settings introduced in April 1945.

## RUN008 target
Find the **source-of-news** behind Mahon's sentence: a Hut 8 watch log, liaison note, 30AU/TICOM capture report, surrender inventory, or GC&CS receipt record dated approximately 6–12 May 1945.

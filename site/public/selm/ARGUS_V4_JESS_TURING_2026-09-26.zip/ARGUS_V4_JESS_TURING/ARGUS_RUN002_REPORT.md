# ARGUS v2.0 — RUN 002: ACQUISITION ATTACK

## Result
The public-web acquisition attack did not recover the contents of 5750/781 or 5750/218, a second M-Thetis witness, or a May-1945 Thetis key.

It did, however, expose a useful cross-reference layer around the CNSG collection.

### New archival bridge
The CNSG finding aid identifies 5750/350 as OP-20-G's February-1946 `German Naval Communications Intelligence`; NHHC publishes this report as SRH-024. This proves that at least some CNSG folder titles can be cross-walked to separately digitized historical-report series.

NSA's historical bibliography additionally identifies:
- RIP 425 — `The American Attack on the German Naval Ciphers`
- OP-20-GY-A, 7 July 1944 — `American Cryptanalysis of German Naval Systems`

These become new acquisition targets because they may cite the underlying key files, capture reports, or document identifiers represented only by folder title in 5750/781.

### Provenance upgrade
Erskine's scholarly study of captured Kriegsmarine Enigma documents reinforces a crucial ARGUS rule: possession of a bigram/procedure table is not enough. Individual captured tables can be tied to P-number/capture histories, and some captured bigram tables never entered operational service. Therefore Quelle/2499 ↔ 1772a remains a provenance problem, not merely a cell-mapping problem.

### No hypothesis promotion
RUN002 does not promote earlier-Thetis, stale-Thetis, group-circuit, or Offizier. No new target-specific evidence supports one over the others.

## Next run
Shift from exact-folder searching to **citation-chain reconstruction**:
RIP 425 → OP-20-GY-A → SRH-024 appendixes → captured-document P-number literature → 5750/781/218.
The objective is to recover an alternate scan, citation, accession reference, or underlying document identifier.

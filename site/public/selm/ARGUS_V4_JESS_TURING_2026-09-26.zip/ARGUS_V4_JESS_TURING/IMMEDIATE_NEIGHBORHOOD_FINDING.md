# P1030680 IMMEDIATE-NEIGHBORHOOD HARVEST — V6.5

## Main finding: the Potsdam–Thetis–Potsdam sandwich

The surviving numbering sequence gives a much sharper local context than the earlier broad 1-May model:

- **P1030679** is solved with UKW C / Beta / 5-6-8 / rings AAEL and plugboard AE BF CM DQ HU JN LX PR SZ VW. Its plaintext is addressed to `KOM. ADM. U-BOOTE`, `F.D.U. AUSBILDUNG`, `TORPEDOINSPEKTION` and U-Tender Mosel.
- **P1030680** sits immediately next. Its form has VROL NMKA. Dan Girard's reconstruction of the annotations shows the receiver tried two Potsdam-derived message-key paths and got gibberish; only then did he check the allocation and annotate **M-Thetis**.
- **P1030681** is the immediately following surviving number and is solved with the same daily machine family as 0679: UKW C / Beta / 5-6-8 / rings AAEL / the same plugboard. It is the Dönitz succession broadcast.

This is not proof of original transmission order, nor proof that 0679 and 0681 were received immediately before/after 0680 in clock time. But it establishes a strong documentary fact: **0680 is an M-Thetis-classified anomaly embedded between two solved sheets using the same Potsdam-compatible daily machine family.**

That makes `INCIDENTAL FOREIGN THETIS` and `THETIS KEY MATERIAL ABSENT ON U-534` more economical documentary explanations than a generic failure of the surrounding 1-May Potsdam chain. It also weakens any model that treats the entire sheet sequence as one homogeneous circuit/key stream.

## C×E consequence

The C×E branch remains historically licensed, but the neighborhood evidence changes its role.

A stale/repeat hypothesis should now be tested **inside Thetis**, not by assuming that 0680 is a broken Potsdam message. The receiver's own work on the sheet already supplies evidence that the Potsdam interpretation was rejected and the Schlüsselkenngruppe belonged to Thetis.

Therefore:
1. `earlier repeat` asks whether the applicable **Thetis** daily state might pre-date 1 May;
2. `stale Stichwort` asks whether sender/receiver could be on different **Thetis** procedural states;
3. neither branch should reuse Potsdam merely because the neighboring sheets do.

## Sister-sheet metadata still missing

The web transcription exposes ciphertext, indicator and solved settings, but not a reliable exact reception clock time / frequency / repeat mark / programme-time mark for 0679–0681. Those remain archival acquisition targets. Direct sheet-image URLs exist, but the current web extractor does not expose their image metadata sufficiently for a defensible transcription.

## Additional local controls

P1030682 references an earlier message dated 28 April, while P1030683 and P1030684 are authentic group/multi-boat movement traffic. This reinforces that the U-534 packet contains mixed-origin, repeated/referenced and operational traffic rather than a single sender-recipient conversation.

# ARGUS v2.0 — RUN 018: FINAL RUN — U-249 CRYPTO CAPTURE

## The hard new finding

The Royal Navy's official May 1945 War Diary contains the first-board report from HMS MAGPIE on U-249.

At **1800B on 9 May**, with U-249 still at sea under a British boarding party, MAGPIE reported:

`C.Bs. apparently intact. Cypher machine ... located.`

The searchable transcription is awkward at one word boundary (`ashore located`), so ARGUS does not silently repair the phrase. The important unambiguous elements are:
- `C.Bs. apparently intact`
- `Cypher machine`
- `located`

This is materially stronger than the earlier evidence that Standing Orders were later taken from U-249.

## Why it matters

U-249 is now a documented **cryptographic capture event** in exactly Mahon's window.

The chronology is:

- 5 May: Mahon's reference point.
- 9 May: U-249 surfaces/surrenders; British boarding party takes physical control.
- 1800B/9 May: MAGPIE reports confidential books apparently intact and cipher machine located.
- 10 May 1100: U-249 reaches/formally surrenders at Portland.
- Mahon: `a few days later` Hut 8 hears the Grund tables have been captured and stops work.

This does **not** prove U-249 supplied the Grund tables.

But U-249 must now be tested before speculative Norway/Canada capture stories, because the Royal Navy has given us a timestamped positive crypto-capture report.

## Same-procedure negative control

The War Diary is even more useful because on 10 May the Royal Navy reports of U-1023:

`C.Bs. and cypher machine not located.`

That means the Navy was actively checking surrendering U-boats for these categories.

So U-249's positive entry is not casual description; it is the positive result of an operational search category.

## What has to be found next

The decisive document is no longer a generic U-249 history.

It is the **first-board inventory / confidential-books report** behind MAGPIE 091800B.

We need to know:
- what `C.Bs.` meant in this boarding report;
- whether current/future Schlüsseltafeln or Grund tables were among them;
- who removed them;
- where they were sent on 9–10 May;
- whether an urgent report went to Admiralty/NID/GC&CS.

A routing receipt or Hut 8 liaison note could settle the Mahon question.

## Method correction

RUN018 installs a Known-Findings Gate after RUN017 mistakenly promoted an already-known Thetis allocation issue as new.

Future ARGUS runs must classify findings as:
NEW / REFINEMENT / CONFIRMATION / KNOWN / CONTRADICTION
before promotion.

## Final state tonight

The two highest-information unopened doors are now:

1. **U-249 / MAGPIE 091800B → first-board C.B. inventory → Admiralty/GC&CS routing**
2. **NSA HCC 7465A — GERMAN KEY LOGS (FEB 41–MAY 45)**

The first is now the sharper immediate target because it has a precise date, boat, boarding party, message timestamp and positive crypto-capture statement.

# ARGUS v2.0 — RUN 014: THE 7–8 MAY CRYPTO-SURVIVAL BRIDGE

## Major result

RUN014 finds the first documentary mechanism that explains how cryptographic material could deliberately survive the German surrender destruction process.

A W/T message recovered aboard U-889 was transmitted at **2046 on 7 May** and received aboard at **0341 on 8 May**.

F.d.U. West ordered the addressed flotillas/bases:
- no U-boat was to leave;
- no transfers between bases;
- code books and U-boat/base W/T day logs were to be destroyed;
- **but coding material for future use and the Enigma machine were to be spared**, along with navigation aids, equipment and weapons.

This is a critical distinction.

The German destruction policy immediately before surrender was **selective**, not simply `destroy all crypto`.

## The 8-May join gets much sharper

OP-20-G independently says that on **8 May** German naval traffic announced that **U-boat cipher keys had been handed over to the enemy**.

ARGUS now has two adjacent facts:

**2046/7 May → destroy codebooks/logs, spare future-use coding material + Enigma**
**8 May → announcement that U-boat cipher keys had reached the enemy**

We still do not know whether the second event was caused by material preserved under the first order, by a shore-station surrender, or by another capture.

But this is now a tightly bounded historical problem rather than a vague capture hypothesis.

## Mahon's Grund tables

This also creates a plausible surrender-survival mechanism for Mahon's statement that Hut 8 soon heard the Grund tables had been captured.

Do NOT collapse these into one event.

What RUN014 establishes is only:
**late cryptographic material could intentionally be spared at surrender.**

The next question is whether Grund tables belonged to the `future use` category and whether the captured set can be linked to a specific surrender/capture.

## U-889's surviving W/T residue is richer than expected

The Canadian interrogation preserves:
- 1614/4 May — explicitly **Offizier-only**;
- 2046/7 May — crypto-destruction/retention order;
- 2116/9 May — Kremplermoor VLF programme, received 0505/10;
- an enciphered 1130/9 message;
- several Allied surrender messages relayed by B.d.U.;
- Dönitz's final surrender message.

This gives ARGUS exact transmission/reception lags and source-attested late-war procedure language.

## New Canadian packet split

Bauer's database shows two distinct source packets:

### Z969 / LIT [242a]
U-889 interrogation + onboard radio/electronic equipment + MZSS/Schlüssel-M hardware reference.

### Z970 / LIT [243]
Top Secret Naval Message Canada + NSHQ U-889 report + **20 May 1945 report** + surrender material + **LIST OF APPARATUS ON BOARD 889**.

RUN015 should attack **LIT [243]** first. It is likely closer to the first Canadian post-surrender documentation than the later interrogation report.

## Crib Factory

RUN014 exports source-attested translated fragments separately. They are not silently treated as original German telegraphese. The next step is to recover the German originals before promoting lexical strings into the main German crib corpus.

## Highest-value question

What exactly did the Germans mean by:
**`coding material for future use`**

on 7 May 1945?

If the surviving German original or surrender instructions enumerate that category, it could tell us whether Grund/bigram/key tables were deliberately retained — and therefore where to look for them after surrender.

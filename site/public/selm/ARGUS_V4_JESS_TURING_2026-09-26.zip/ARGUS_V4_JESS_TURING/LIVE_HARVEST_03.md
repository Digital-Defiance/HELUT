# LIVE HARVEST LOOP 3

Promoted **14** additional Tier-1 fragments; factory total **121**.

## Acquisition pivot
Direct searches for a flotilla-level Funkkladde were weak. The KTB record structure gives a better route: radio-log excerpts survive as attachments to **individual boat KTBs**, and KTB distribution can explicitly include the training flotillas. U-186 is a concrete archival example: the distribution links 27 U-Flottille to 2 ULD/25 U-Flottille and Agru-Front to 1 ULD/24/26, while a radio-log excerpt is among the enclosures.

## Scenario D pivot
The archive taxonomy explicitly distinguishes `Funkkladde M-Allgemein` from `Funkkladde M-Offizier`. We can therefore build an empirical Offizier outer-register corpus from paired surviving logs instead of relying only on M.Dv.32/2.

## New Tier-1 grammar
U-466's first-patrol Funkkladde adds exact operational forms: `NEUANSTEUERUNG...`, `ANSTEUERN`, `FAHRT SO EINRICHTEN`, `BEFOHLENES QUADRAT`, `MIT MARSCHFAHRT 8 SM`, superseding an earlier FT (`DER BEFEHL GEM. F.T. ... DAMIT UEBERHOLT`), `STEHE MAR. QU.`, `STOSSE NACH`, `SOFORT MELDEN`, `ERBITTE BEFEHL`, and `LETZTE HORCHPEILUNG`.

## New repository
WLB Stuttgart's catalogue explicitly lists an `Auszug aus der Funkkladde von U 99 (1939/40)` (Kapsel 110/9) plus Kurzsignalheft copies. This is an acquisition lead, not a P1030680 crib source.

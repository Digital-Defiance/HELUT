# ARGUS v2.0 — RUN 015: THE THREE-EVENT JOIN

## Executive result

RUN015 does not yet prove the capture event behind Mahon's sentence.

It does, however, tighten the problem into three independently documented events:

1. **2046 / 7 May 1945**
   F.d.U. West orders code books and W/T day logs destroyed, while sparing
   `coding material for future use` and the Enigma machine.

2. **8 May 1945**
   OP-20-G records a German naval announcement that U-boat cipher keys had
   been handed over to the enemy.

3. **A few days after 5 May**
   Mahon says Hut 8 stopped work after hearing that the Grund tables had been captured.

ARGUS does not merge these events.
The objective is now to recover the missing primary signals/liaison record and test the join.

## A new control: U-260 / Schlüsselmittel

A German naval-history lead points to Experience FT No.136 (9 Jan 1945), warning of Allied interest in:
`Schlüssel M und Schlüsselmittel`.

The same discussion concerns secret material from U-260 that fell into Allied hands in March 1945.

This creates a useful physical-vocabulary experiment:
recover the U-260 captured-material inventory and ask what German/Allied documents actually called `Schlüsselmittel`.

That can help interpret the otherwise ambiguous Canadian translation:
`coding material for future use`.

## Norway remains active

OP-20-G's Experience Message #236 (1255/27 Apr 1945) describes an attempted boarding of a U-boat off the Norwegian coast, interpreted as an attempt to capture classified material.

This is not a Thetis link.
It is evidence that immediately before surrender German U-boat command was explicitly thinking about capture of classified material in the Norwegian theatre.

## LIT243

Bauer's index continues to confirm:
Z970 / LIT [243]
- surrender-order material
- U-889 Canadian/NSHQ material
- LIST OF APPARATUS ON BOARD 889
- MZSS / GVX-41

But the exact LAC call number and scans remain unresolved.

RUN016 should therefore split into:
A. archive-resolution attack on Z970/LIT243;
B. primary-text attack on 2046/7 and the 8-May compromise notice;
C. U-260/Experience-136 control to learn the period vocabulary of Schlüsselmittel.

## Evidential firewall

Nothing in RUN015 proves:
- Grund tables = the keys announced compromised on 8 May;
- the capture occurred in Norway;
- U-889 was the source;
- future-use coding material = Grundtafeln;
- Thetis was among the captured material.

Those remain hypotheses to test.

# ARGUS v2.0

ARGUS is the optimized successor to ARGONAUT.

## Why the redesign
The previous machine accumulated useful layers but risked mixing three different questions:
1. What do the historical sources establish?
2. Which alternative procedural/key branches do those sources license?
3. What machine space has already been tested?

ARGUS keeps these as separate ledgers and joins them only at the compute firewall.

## Architecture
**HARVEST → PROVENANCE → EVIDENCE LEDGER → HYPOTHESIS GRAPH → CRIB FACTORY →
PROCEDURAL-BREAK ROUTER → NO-SELF → COVERAGE LEDGER → COMPUTE FIREWALL → RESULTS →
NEGATIVE FEEDBACK → ACQUISITION QUEUE**

### Evidence ledger
Every factual claim has a grade and status. Unverified secondary claims can be quarantined without being deleted.

### Hypothesis graph
Each scenario has both a *promoter* and a *falsifier*. A negative Bombe run is not a promoter.

### Acquisition queue
Targets are prioritized by expected decision value, scenario discrimination, and provenance value.
The current top cluster is NARA RG38 5750/781 + 5750/218, original P1030680 metadata,
Thetis May-1945 key material, Quelle 2499/1772a edition provenance, and a second independent M-Thetis witness.

### Compute firewall
No alternate key/date/state branch launches merely because the nominal search is negative.
The branch must be historically licensed first.

## Hard acceptance criterion
ARGUS calls P1030680 solved only when:
- the complete 72-character plaintext is coherent in its historical/operational context; and
- one historically valid M4 configuration exactly re-encrypts the full original ciphertext.

## Identity
All future integrated builds should be named **ARGUS**.

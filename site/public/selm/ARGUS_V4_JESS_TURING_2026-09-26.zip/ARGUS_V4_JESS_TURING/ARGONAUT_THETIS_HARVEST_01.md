# ARGONAUT — THETIS KEY HARVEST 01

## Result
The first tightly targeted search for a surviving **30 April / 1 May 1945 Thetis daily key or
Stichwort/Grundstellung change** did **not** recover the desired key sheet.

That negative result is useful because it separates three evidence layers:

1. **Network allocation survives.** The October-1944 `Forelle` Zuteilungsliste assigns
   Kenngruppen columns 671–703 to `M Thetis (M Tht)`.
2. **0680 is target-specifically classified Thetis.** The surviving sheet reconstruction maps its
   Schlüsselkenngruppe ACH to Thetis after two failed Potsdam attempts.
3. **The daily Thetis machine state remains missing.** No indexed 30-Apr/1-May-1945 Thetis
   Tages-/Grund-/Stichwort sheet was recovered in this cycle.

## Consequence for C×E
ARGONAUT therefore keeps:
- nominal 1-May Thetis;
- earlier-date Thetis;
- stale/desynchronised Thetis;
- earlier-Thetis × stale-Thetis

as separate branches. None may inherit the neighboring Potsdam settings.

## New archival search vocabulary
Future harvesting should combine both names and document classes:
`Thetis`, `Tetis`, `M Tht`, `MTht`, `U-Boot-Übungsschlüssel`, `U-Übungsschlüssel`
with `Schlüsselzettel`, `Monatsschlüssel`, `Tagesschlüssel`, `Grundtafel`,
`Schlüsselstellung`, `Stichwort`, `Zuteilungsliste`, `Kenngruppenbuch`,
`Funkkladde`, `Leitnummer`, and specific training-flotilla/boat identifiers.

## Important ambiguity
Web sources also contain a different wartime `Thetis`: the FuMT radar decoy. ARGONAUT must
reject those hits unless the document explicitly concerns Schlüssel/Funkverkehr.

#!/usr/bin/env python3
from pathlib import Path
import csv, sys, re
ROOT=Path(__file__).resolve().parent

def read(name):
    with open(ROOT/name,encoding="utf-8",newline="") as f: return list(csv.DictReader(f))

def status():
    cr=read("crib_master.csv"); br=read("historical_compute_bridge.csv")
    v5=read("v5_exact_run_import.csv"); neg=read("v5_exclusions.csv")
    print("SUPERMACHINE")
    print("cribs:",len(cr))
    print("bridge candidates:",len(br))
    print("V5 exact run rows imported:",sum(r.get("import_status","IMPORTED")=="IMPORTED" for r in v5),"/ 8")
    print("V5 exclusions:",len(neg))
    print("launchable exact V5 rows:",sum(r.get("import_status","IMPORTED")=="IMPORTED" and r.get("ledger_match","")=="PASS" for r in v5))

def next_history(n=20):
    rows=read("historical_compute_bridge.csv")
    rows=[r for r in rows if r["compute_status"]=="UNTESTED_AGAINST_V5_LEDGER"]
    for r in rows[:n]:
        print(r["crib_id"],r["exact_string"],"L="+r["length"],"S="+r["scenario"],
              "align="+r["valid_alignment_count"],"V5overlap="+(r["v5_overlap"] or "-"))

def preflight():
    rows=read("v5_exact_run_import.csv")
    bad=[]
    for r in rows:
        if r.get("import_status","IMPORTED")!="IMPORTED": bad.append((r.get("run_id",r.get("v5_run_id","?")),"exact V5 row missing"))
        elif not (r.get("crib") or r.get("exact_crib")) or not (r.get("placement_1based") or r.get("placement")): bad.append((r.get("run_id",r.get("v5_run_id","?")),"crib/placement missing"))
        elif r.get("ledger_match","")!="PASS": bad.append((r.get("run_id",r.get("v5_run_id","?")),"ledger coverage not PASS"))
    if bad:
        print("NO-LAUNCH")
        for x in bad: print(*x,sep=": ")
        return 2
    print("PREFLIGHT PASS")
    return 0

cmd=sys.argv[1] if len(sys.argv)>1 else "status"
if cmd=="status": status()
elif cmd=="next-history": next_history()
elif cmd=="preflight": raise SystemExit(preflight())
else: status()

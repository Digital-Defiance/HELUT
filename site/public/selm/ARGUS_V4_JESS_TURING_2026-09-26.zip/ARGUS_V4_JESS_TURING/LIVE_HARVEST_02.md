# LIVE HARVEST LOOP 2

Promoted 8 additional Tier-1 fragments; total factory size is 107.

## Main gain: group-message grammar
Expanded U-466 Funkkladde extraction now captures not just isolated nouns but whole authentic command structures:
- AUF LEITNUMMER ... HINGEWIESEN
- BEI TAG ALLE ZWO STUNDEN AUF EMPFANGSTIEFE GEHEN
- UM WICHTIGE NACHRICHTEN ZU ERFASSEN
- FALLS BIS ... KEIN ANHALT ... VORLIEGT
- AN GRUPPE SCHILL
- IM AUFKLAERUNGSSTREIFEN STEHEN
- AB ... UHR KURS NORD
- ZWO SM FAHRT UNTER WASSER

These are Tier 1 language controls but retain low date/geography scores because they are 1943 Atlantic Irlandschaltung traffic.

## Main structural gain: Baltic training radio architecture
The captured U-505 training guide establishes a separate Baltic radio ecology: Karl-Fritz 71.77m for Baltic/individual training boats; training flotillas on their own short frequencies; Kiel support point and Neustadt school as radio positions; daily 0800 operating time; dummy/question traffic in quiet periods. This strengthens the rule that reception frequency/circuit and M-key must remain separate variables.

## ZTPG result
Exact serial searches for 367822, 369045, 369054 and 369140 did not surface the primary decrypt text in indexed web sources. The machine now marks this branch as requiring archival scans/unindexed transcriptions, rather than wasting future semantic-search cycles or reverse-translating summaries.

## Thetis
R.I.P. 401 remains a primary classification anchor for 671–703 = M Thetis (M Tht), but still produces no lexical crib and does not prove Gruppenwelle = Thetis.

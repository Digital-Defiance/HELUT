# ARGUS v2.0 — RUN 010: CANADA BRANCH

## Result

Canada is now promoted from a peripheral museum lead to a full ARGUS evidence branch.

### DHH 97/3 is the key discovery
The Canadian Directorate of History and Heritage finding aid states:
- Series 1: cryptologic historical material including Mahon's *History of Hut Eight*;
- Series 2: **translations of German U-boat messages**;
- Series 4: **U-boat intelligence summaries**;
- Series 5: **radio intelligence bulletins**.
Consultation is unrestricted.

This creates a Canadian archival route into the same traffic universe ARGUS has been harvesting through DEFE, SRGN and U.S. Navy records.

The U.S. records schedule identifies SRGN as a very large series of individual German U-boat message translations (up to 49,668). The Canadian copies can therefore be cross-walked by serial/date, with special attention to 30 April–10 May 1945.

### Physical cryptographic custody
CSE officially confirms that the RCN recovered an Enigma from U-190 and that it remains in CSE's collection.

The important ARGUS target is not the machine alone. It is the **custody/accession paperwork**:
what else was inventoried aboard the boat, what secret papers were destroyed or retained, and how the cryptographic material moved through RCN/Canadian intelligence custody.

### Canadian War Museum accession
CWM accession **19680168** is demonstrably a multi-object U-190 donation:
- -009 surrender document
- -006 and -010 through -015 equipment plates
- plus `related artifacts`

ARGUS should reconstruct the entire accession and donor file rather than search individual web exhibits.

### Canada firewall
No Canadian source found here explicitly places Thetis material in Canada.
The branch is valuable for:
1. duplicate/alternate U-boat message copies;
2. end-war SIGINT summaries;
3. physical capture/custody paperwork;
4. U-190/U-889 technical examination;
5. Canadian intercept-station records.

## RUN011
Highest-information actions:
1. obtain/enumerate DHH 97/3 Series 2 for 30 Apr–10 May;
2. inspect Series 4/5 for the 8-May compromise / Grund capture;
3. trace CSE U-190 accession history;
4. locate U-889 Canadian technical-examination files;
5. build Canada↔SRGN↔DEFE/ZTPG crosswalk.

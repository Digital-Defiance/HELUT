# C×E ENGINE — EARLIER REPEAT × PROCEDURAL DESYNCHRONISATION

## Purpose
Test a narrowly defined historical proposition without allowing a negative cryptanalytic run to manufacture history:

**Could P1030680 have been received on 1 May while belonging to an earlier transmission/key state, possibly across a missed Stichwort/Schlüsselstellung update?**

## Why this branch is licensed

1. Allied technical COMINT history states that an elaborate VLF repetition service repeated practically all U-boat traffic. Reception date is therefore not automatically original transmission date.
2. Arthur O. Bauer describes Leitnummer-controlled repeats: boats waited for the shore repeat and repeats were guaranteed at programme times when traffic prevented immediate repetition.
3. U-466 provides an empirical synchronization-failure control: Küste traffic became unreadable because of `falscher Schlüsselstellung`; the crew suspected that a Leitnummer carrying an `Änderung Stichwort` had been missed and switched circuit.
4. A surviving Tirpitz KTB example shows a message being repeated with a Leitnummer on one path while another transmission was not repeated because a key error was detected. This is useful as a procedural control: repetition, Leitnummer and key-error handling interacted operationally.

None of these facts proves that P1030680 crossed such a boundary.

## New machine behavior
The supermachine now maintains three independent ledgers:
- plaintext/crib evidence;
- procedural-break evidence;
- compute coverage.

A Bombe negative can update the third ledger. It cannot upgrade H_CXE_1–H_CXE_5 in the historical ledger.

## C×E diagnostic pool
13 existing cribs have both a repeat/date signal and a synchronization/procedural-break signal under the current conservative rules. They are exported in `CxE_crib_diagnostics.csv`. Their purpose is to recognize authentic register and build tests, not to assert that those strings occur in 0680.

## Highest-value evidence
The single most valuable acquisition is still the original P1030680 radio metadata and sister sheets. Exact time + repeat/programme mark + Leitnummer could turn C×E from a broad mechanism into a bounded historical branch.

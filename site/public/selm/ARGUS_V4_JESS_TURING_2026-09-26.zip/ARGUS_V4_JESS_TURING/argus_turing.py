#!/usr/bin/env python3
from pathlib import Path
import csv,json,argparse,datetime,shutil
R=Path(__file__).resolve().parent

def rows(n):
 with open(R/n,encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def status():
 c=json.loads((R/'argus_config.json').read_text())
 print(f"ARGUS {c['version']} | {c['interface']} | target {c['target']['length']} chars")
 print('PLAINTEXT: NONE | second Thetis witness: NONE | alternate Thetis key: NONE')
 print('Tafel A: fully transcribed | target: VROL NMKA -> ACH | K-Buch column: 645')
 print('Hörenberg: exhausted for second Thetis/key; retain as lookup/context corpus')
 print('Primary mission: recover traffic metadata + independent Thetis key/witness evidence')
def metadata():
 for x in rows('TRAFFIC_METADATA_QUEUE.csv'):
  print('\t'.join([x['priority'],x['field'],x['value'],x['best_source'],x['why_it_matters']]))
def fingerprints():
 for x in rows('KBUCH_LOOKUP_FINGERPRINTS.csv'):
  print('\t'.join([x['family'],x['known_key'],x['kbuch_column'],x['decoded_skg_sequence'],x['anchor']]))
def scenarios():
 for x in rows('KEY_SEARCH_CONSEQUENCES.csv'):
  print('\t'.join([x['scenario_id'],x['status'],x['changes_daily_key_search'],x['scenario'],x['requirement']]))
def cribs(limit):
 d=[x for x in rows('CRIB_ELIGIBILITY_V4.csv') if x['p1030680_emit_eligible']=='YES']
 print('exact_string,source_message,source_date,known_key,provenance_family,independent_reuse,daily_key_change_flag')
 for x in d[:limit]: print(','.join([x[k] for k in ['exact_string','source_message','source_date','known_key','provenance_family','independent_reuse','daily_key_change_flag']]))
def ingest(p):
 inp=list(csv.DictReader(open(p,encoding='utf-8',newline=''))); ledger=R/'TURING_RUN_LEDGER.csv';ts=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with open(ledger,'a',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['timestamp_utc','run_id','hypothesis_id','method','coverage','outcome','notes','source_file'])
  for x in inp:w.writerow({'timestamp_utc':ts,'run_id':x.get('run_id',''),'hypothesis_id':x.get('hypothesis_id',''),'method':x.get('method',''),'coverage':x.get('coverage',''),'outcome':x.get('outcome',''),'notes':x.get('notes',''),'source_file':Path(p).name})
 shutil.copy2(p,R/('TURING_ARCHIVE_'+Path(p).name));print('ingested',len(inp),'rows')
def main():
 ap=argparse.ArgumentParser(description='ARGUS V4 historical coprocessor for Turing');sp=ap.add_subparsers(dest='cmd',required=True)
 for c in ['status','metadata','fingerprints','scenarios']:sp.add_parser(c)
 c=sp.add_parser('cribs');c.add_argument('--limit',type=int,default=20)
 i=sp.add_parser('ingest-results');i.add_argument('file')
 a=ap.parse_args(); {'status':status,'metadata':metadata,'fingerprints':fingerprints,'scenarios':scenarios}.get(a.cmd,lambda:None)() if a.cmd in ('status','metadata','fingerprints','scenarios') else cribs(a.limit) if a.cmd=='cribs' else ingest(a.file)
if __name__=='__main__':main()

# P1030680 SUPERMACHINE V6

This fuses the **Harvest × Crib Machine v1.3**, the historical **M-Thetis detector**, the aggressive document scrape, the May-1945 training-boat cohort, and the recoverable state of **V5** into one auditable research/experiment machine.

## Pipeline
SEARCH → SOURCE CAPTURE → DETECTOR/PROVENANCE → CRIB EXTRACTION → DEDUP → NO-SELF →
SCENARIO ROUTING → V5 NEGATIVE/COVERAGE CHECK → EXPERIMENT PLAN → RESULT LEDGER →
HISTORICAL GAP FEEDBACK → SEARCH AGAIN.

## What V5 contributes
V5 is treated as the **compute-selection and exclusion layer**, not as a historical source.
Recovered V5 state includes the GEGENSTELLEN, FFFTTTNICHTZ, LEITSTELLE, GELEIT and FOLGEVE families,
plus Jessica-ledger exclusions (4,103 repaired-stripe candidates, 86 quarantined stops, 55 UEBUNG
near-misses, 81 exact ghosts killed at plug completion, and the duplicate 2,513-menu VIII-fast catalog).

The exact eight V5 run rows were not present in the accessible files. They are therefore represented by
eight reserved rows in `v5_exact_run_import.csv`. **Nothing has been invented.** `supermachine.py preflight`
refuses launch until exact crib + placement + rotor/ring coverage + ledger match are imported.

## New fusion layer
`historical_compute_bridge.csv` is the key new table. It takes high-evidence historical cribs from the factory,
keeps their scenario/provenance, carries all mechanically valid target alignments, and marks overlap with known
V5 families. It does not promote a candidate because its menu looks attractive.

## Hard acceptance rule
P1030680 is solved only with:
1. coherent complete 72-character plaintext in historical/operational context; and
2. one historically valid M4 configuration that exactly re-encrypts the full original ciphertext.

## Commands
`python supermachine.py status`
`python supermachine.py next-history`
`python supermachine.py preflight`

The old `crib_machine.py` remains intact for harvest → crib promotion and scenario exports.

#!/usr/bin/env python3
"""
P1030680 HARVEST -> CRIB MACHINE
No web access is required by this script itself.
Feed search results into harvest_hits.csv, review them, then run:
  python crib_machine.py promote
  python crib_machine.py export
  python crib_machine.py status
"""
from pathlib import Path
import pandas as pd, re, hashlib, json, sys

ROOT=Path(__file__).resolve().parent
CFG=json.loads((ROOT/"machine_config.json").read_text(encoding="utf-8"))
CIPHER=CFG["target"]["ciphertext"]

def az(s): return re.sub(r"[^A-Z]","",str(s).upper())

def valid_alignments(plain):
    p=az(plain)
    if not p or len(p)>len(CIPHER): return []
    return [i+1 for i in range(len(CIPHER)-len(p)+1)
            if all(p[j]!=CIPHER[i+j] for j in range(len(p)))]

def fp(text,ref):
    return hashlib.sha256((az(text)+"|"+str(ref).strip()).encode()).hexdigest()[:20]

def status():
    q=pd.read_csv(ROOT/"harvest_queue.csv")
    h=pd.read_csv(ROOT/"harvest_hits.csv")
    c=pd.read_csv(ROOT/"crib_master.csv")
    print("queries",len(q),"open",(q.status=="OPEN").sum())
    print("hits",len(h),"reviewed",(h.review_status=="APPROVED").sum() if len(h) else 0)
    print("cribs",len(c),"tier1",(c.attestation_tier.str.contains("TIER 1",na=False)).sum())
    print("scenarios",c.scenario.value_counts(dropna=False).to_dict())

def promote():
    hits=pd.read_csv(ROOT/"harvest_hits.csv")
    cribs=pd.read_csv(ROOT/"crib_master.csv")
    ledger=pd.read_csv(ROOT/"dedup_ledger.csv")
    approved=hits[(hits.review_status=="APPROVED") & hits.authentic_plaintext.notna()].copy()
    if approved.empty:
        print("No APPROVED hits with authentic_plaintext.")
        return
    existing={(az(r.exact_string),str(r.source_reference)) for _,r in cribs.iterrows()}
    nextid=max([int(str(x)[1:]) for x in cribs.crib_id if str(x).startswith("C")]+[0])+1
    new=[]
    led=[]
    for _,h in approved.iterrows():
        # Semicolon separates reviewer-approved contiguous phrase units.
        for raw in str(h.authentic_plaintext).split(";"):
            exact=raw.strip()
            p=az(exact)
            if len(p)<4: continue
            key=(p,str(h.url))
            if key in existing: continue
            va=valid_alignments(p)
            grade=str(h.provenance_grade).upper()
            tier="TIER 1 — DIRECT" if grade in ("PRIMARY","DIRECT","A") else "TIER 3 — CONTEXTUAL"
            new.append({
              "crib_id":f"C{nextid:03d}","exact_string":exact,"normalized_reading":exact,
              "length":len(p),"source_quote_or_context":h.snippet_or_quote,
              "source_reference":h.url,"source_date":h.date,"sender":h.sender,
              "recipient":h.recipient,"boat_station":h.boat_station,
              "message_class":h.semantic_family,"known_key":h.known_key,
              "known_schaltung":h.known_schaltung,"attestation_tier":tier,
              "scenario":h.scenario,"semantic_family":h.semantic_family,
              "attestation_score":3 if "TIER 1" in tier else 2,
              "register_score":3 if "TIER 1" in tier else 2,
              "date_score":3 if "1945-05-01" in str(h.date) else 1,
              "geography_score":2,"radio_score":3 if "radio" in str(h.semantic_family).lower() else 2,
              "scenario_score":3,"crypto_usability_score":3 if 8<=len(p)<=15 else 2,
              "independence_score":3,"valid_alignment_count":len(va),
              "valid_positions":";".join(map(str,va)),
              "notes":"Promoted from reviewed harvest hit; no-self survival is exclusion-only."
            })
            led.append({"fingerprint":fp(exact,h.url),"exact_string":exact,
                        "source_reference":h.url,"source_date":h.date,
                        "first_seen_hit_id":h.hit_id,"duplicate_count":0,
                        "status":"PROMOTED","notes":h.review_notes})
            existing.add(key); nextid+=1
    if new:
        pd.concat([cribs,pd.DataFrame(new)],ignore_index=True).to_csv(ROOT/"crib_master.csv",index=False)
        pd.concat([ledger,pd.DataFrame(led)],ignore_index=True).drop_duplicates("fingerprint").to_csv(ROOT/"dedup_ledger.csv",index=False)
    print("promoted",len(new))

def export():
    c=pd.read_csv(ROOT/"crib_master.csv")
    c=c[(c.valid_alignment_count>0) & (~c.attestation_tier.str.contains("TIER 4",na=False))]
    # Keep scenario populations separate.
    for scen in ["A","B","B2","C","D","E"]:
        mask=c.scenario.fillna("").str.split(",").apply(lambda xs: scen in [x.strip() for x in xs])
        x=c[mask].copy()
        x["historical_total"]=x[["attestation_score","register_score","date_score","geography_score",
                                  "radio_score","scenario_score","crypto_usability_score","independence_score"]].sum(axis=1)
        x=x.sort_values(["historical_total","crypto_usability_score"],ascending=False)
        x.to_csv(ROOT/f"export_{scen}.csv",index=False)
    ag=c[c.scenario.fillna("").str.contains("SCENARIO-AGNOSTIC")].copy()
    ag.to_csv(ROOT/"export_scenario_agnostic.csv",index=False)
    print("exports written")

if __name__=="__main__":
    cmd=sys.argv[1] if len(sys.argv)>1 else "status"
    {"status":status,"promote":promote,"export":export}.get(cmd,status)()

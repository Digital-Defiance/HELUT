# ARGUS v2.0 — RUN 006: NS-VI / LATE GRUND CAPTURE

## Major finding

RUN006 finds the first strong documentary bridge between ARGUS's missing late-war Grund-table layer and an actual Allied capture event.

A.P. Mahon's *History of Hut 8*, quoted independently in Cryptologia scholarship, says that during the final May-1945 procedural episode:

- Dolphin began the new system with a bigram table of its own;
- the bigram tables did not change on 5 May;
- a few days later work stopped when Hut 8 heard that **the Grund tables had been captured**.

This is materially different from the earlier unverified `228 Grundstellungen` claim. It is a primary institutional history saying that late Kriegsmarine Grund tables were in fact captured.

## Consequence for P1030680

The current reconstruction of 0680 says the real Kriegsmarine Grund tables no longer appear to survive and derives MNNS/DGUG computationally from the known Potsdam key.

ARGUS now has a new provenance problem:

**Which Grund tables were captured after 5 May 1945, from where, for which networks/procedure generation, and what happened to them?**

If the captured set included the Grund-table generation used on 1 May, it could independently validate the 14/5 and 14/9 lookups on P1030680 and potentially remove a major procedural uncertainty.

This does NOT imply that the captured tables contained Thetis's M-machine daily key. Grund tables and key-net Schlüsseltafeln remain separate artifacts.

## Capture timing matters

Tambach was captured on 25 April. Mahon's wording places news of the Grund-table capture a few days after 5 May. ARGUS therefore must not silently equate the two. A later capture — potentially in the north-German/Flensburg collapse — is now an explicit search target.

## NS-VI indexing breakthrough

Independent scholarship confirms that Naval Section VI maintained:
- an NS-VI Index/Library of captured naval documents;
- a Captured Documents Index containing roughly 10,000 German items by war's end;
- specialized dictionaries/indexes derived from captured terminology.

HW 8/103 is cited for this workflow, including pp.24 and 29.

This is exactly the missing cryptographic-document side-channel identified in RUN005.

## New priority order

1. Recover Mahon pp.112–113 in full and date the Grund-table capture precisely.
2. Search 6–12 May 1945 capture/liaison records for the Grund tables.
3. Identify the surviving NS-VI Index/Library or its postwar disposition.
4. Acquire HW8/103 pp.24/29 and appendices.
5. Map HW8/104 capture operations after Tambach.
6. Trace the captured Grund tables into postwar British/U.S. custody.

## Discipline

No Thetis daily key or second Thetis message has been found.
No machine-state hypothesis is promoted.
The new finding concerns the **procedure/Grund layer**, not the Thetis daily M-key.

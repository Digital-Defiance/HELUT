# ARGUS v2.0 — RUN 012: U-889 PAPER-SURVIVAL MODEL

## Major correction

RUN012 resolves an ambiguity from RUN011.

U-889 did **not** surrender with an intact secret-paper suite.

The Canadian N.I.D.3 interrogation says that on **8 May 1945**, after receiving news of unconditional surrender and Dönitz's recall order, Braeucker **dumped his secret papers overboard**. The report explicitly includes his:
- W/T Day Book — `Funk Kladde`
- War Diary — `Kriegs Tagebuch`

among the destroyed material.

Yet Canadian interrogators also had surviving secret March material, including:
- a Top Secret `Wireless Message No. 231A`, 21 March 1945, in the `Experiences` series;
- secret Orders of the Day for 30/31 March issued at Horten.

This is a much better historical control than the simpler model from RUN011.

## What it means

U-889 demonstrates **selective document survival after an explicit destruction event**.

Therefore:

`not found aboard at surrender`
does NOT imply
`not carried during Baltic training / transition to Norway`.

This matters directly to the Norway branch.

A boat could have carried key/procedure material and destroyed it on surrender instructions while older operational papers survived for mundane reasons.

ARGUS must therefore shift from:
**post-surrender inventory only**

to:
**pre-8-May issue/return/destruction records + interrogation testimony + surviving-paper provenance**.

## Strong repeat control

The same N.I.D.3 report says U-889 transmitted its passage report **eight times over about a week** before control acknowledged it.

This is excellent empirical support for the factory's Scenario C mechanism:
late-war U-boat traffic could be repeatedly transmitted and acknowledged only after substantial delay.

It does not prove P1030680 was a repeat.

## Wireless Message 231A

The surviving Top Secret 21-March item is now identified more precisely:
`Wireless Message No. 231A`, `Experiences` series.

That lowers its probability of being cryptographic-procedure material, but raises its value as a provenance tracer. If we can recover its Canadian translation/exhibit number, the neighboring captured-paper packet may reveal what else survived.

## PHx-59

The published description of PHx-59 shows its main purpose was technical trials: diving, schnorkel, radar/GSR, Hohentwiel, acoustics and listening gear.

So PHx-59 is downgraded as a likely direct source for key papers. Its appendices/inventories remain worth checking.

## New visual corpus

LAC has an RG24 technical photographic sequence for U-889 from June 1945, including creator numbers in the `HS-1377` family.

ARGUS should enumerate that whole sequence for:
- Funkraum
- radio equipment
- chart/command spaces
- document storage
- Enigma/cipher-machine views

## Next attack

The highest-information question is now:

**What exactly did Braeucker destroy on 8 May, and what survived that destruction?**

Then reconstruct the pre-surrender key-distribution chain from 4th Training Flotilla → 33rd Flotilla → Kiel → Horten.

# Jessica findings integrated into ARGUS V4

## Hard current state
- No plaintext for P1030680.
- The Hörenberg/U-534 scrape contains solved messages from other nets and P1030680 unbroken; no second Thetis message and no Thetis key.
- 1943 U-466 diary material and Nixe material are a different war/different key and are quarantined from P1030680 crib emission.
- Full transcribed Tafel A, layout `VROL NMKA -> ACH`: all Hörenberg indicators decode. This does **not** prove other nets used Tafel A; a complete table decodes any indicator.
- No kenngruppe is shared by two nets in that scrape. `ACH` occurs only on P1030680.
- `DUZ` is P1030690, Potsdam, K-Buch column 12; P1030680 is column 645.

## Compute consequence
Radio models do not change the key search merely because U-534 heard a message intended for someone else. Earlier encipherment/repeat changes the day-state only if independently evidenced and requires that day’s Tafel letter/pairs. Offizier still needs the outer key. Stale key needs another Thetis key. Gruppenwelle remains open but unlinked.

## Retrieval priority
Recover from the original sheet and neighbours: reception time, frequency, Leitnummer, callsign, repeat mark. These choose the next document to transcribe; they do not enter the bombe.

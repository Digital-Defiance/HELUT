# ARGUS v2.0 — RUN 005: PU/G RECONSTRUCTION

## Main finding

RUN005 establishes what HW 8/116 actually is, and also explains why it may *not* contain the cryptographic needle we hoped for.

A recent archival study cites:
**TNA HW 8/116 — PU Series Accession Lists, PU/G/1–62 German Documentation, 237 pages.**

The study describes these lists as covering German naval archives captured by 30 Assault Unit at **Tambach Castle**, plus documentation seized by British authorities at **Flensburg in June and July 1945**.

However, its author reports that the accession lists contain many decrypted SIGINT messages but **no examples of code or cipher documents**.

That is not evidence that no cryptographic material was captured. The same study explains that NS-VI distributed captured intelligence but **withheld code and cipher documents**. It suggests this segregation may explain why cryptographic captures are poorly represented in surviving ordinary TNA accession lists.

## Consequence

ARGUS's previous model:

`German cipher document → PU/G accession → GC&CS`

is now too simple.

The better model is:

`German capture`
→ triage by 30AU / Naval intelligence
→ **cryptographic material diverted to NS-VI / GC&CS**
→ ordinary naval documentation enters PU/G accession stream.

Therefore Quelle/2499 and 1772a may never appear in HW8/116 even if they came from the same physical capture operation.

## Search result

Exact indexed-web searches for:
- Prüf-Nr./Prüfnummer 2499 + Quelle/Enigma
- 1772a + Tauschtafelplan/Kriegsmarine
- PU/G + Schlüssel/Tauschtafel/Kenngruppen

did not recover a defensible accession cross-reference.

## New priority

The next provenance target is **the cryptographic side-channel itself**:
Naval Section VI / GC&CS registers, card indexes, receipt records, captured-code-document files, and the segregation instructions in HW8/103 / NR2335.

Tambach and Flensburg remain highly useful because they define the physical capture populations, but HW8/116 should now be treated primarily as a *context and omission map*, not automatically as the cipher-document index.

## No hypothesis promotion

Nothing in RUN005 changes the probability of nominal Thetis, earlier repeat, stale Thetis, group circuit, or Offizier. It changes only where ARGUS should look for the missing evidence.

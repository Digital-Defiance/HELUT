# First-run crib views

## A. 20 strongest source-attested procedural fragments
- `TTTFFFZWOVIER` (13) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030698 — routine radio procedure; valid starts: 31.
- `VONVONZEHNXSIDI` (15) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030694 — routine radio procedure; valid starts: 40.
- `SCHALTU` (7) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030693 — communication failure / frequency change; valid starts: 49.
- `SSDCHEFFUNF` (11) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030669 — routine radio procedure; valid starts: 40.
- `LEITUNGVVVUUU` (13) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030695 — routine radio procedure; valid starts: 33.
- `TTTFFFEINSACHT` (14) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030669 — routine radio procedure; valid starts: 33.
- `UNKLLRERFUNKSPR` (15) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030699 — communication failure / frequency change; valid starts: 30.
- `VONVONJOTTOWUENSCHE` (19) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030693 — routine radio procedure; valid starts: 27.
- `ERLEDIGT` (8) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030695 — routine radio procedure; valid starts: 46.
- `VONKREFELD` (10) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030679 — routine radio procedure; valid starts: 43.
- `GROSSEZAHL` (10) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030699 — routine radio procedure; valid starts: 39.
- `ABEINSXFUENF` (12) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030699 — routine radio procedure; valid starts: 44.
- `NULUHRSCHLUESS` (14) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030699 — communication failure / frequency change; valid starts: 33.
- `KOMXBDMXUUUBOOTE` (16) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030700 — routine radio procedure; valid starts: 35.
- `BESTAETIGUNGERBETEN` (19) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030669 — routine radio procedure; valid starts: 26.
- `ANALLEVONVONFUNKHEITUNG` (23) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030699 — routine radio procedure; valid starts: 20.
- `ANANCHEFZWOSECHSUUUFLOTT` (24) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030696 — routine radio procedure; valid starts: 25.
- `VONKOMXADMX` (11) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030705 — routine radio procedure; valid starts: 46.
- `INABAENDERUNG` (13) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030705 — routine radio procedure; valid starts: 42.
- `VVVUUU` (6) — https://enigma.hoerenberg.com/index.php?cat=Breaking+the+M4&page=First+U534+Ciphertext+only+break — routine radio procedure; valid starts: 52.

## B. 20 strongest late-April/early-May operational fragments
- `UEBERWEGZWO` (11) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030693 — boat movement / transfer; valid starts: 42.
- `JANGETRETEN` (11) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030693 — boat movement / transfer; valid starts: 40.
- `WARNEMUENDE` (11) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030693 — port / harbour; valid starts: 47.
- `ALLEINMARSCH` (12) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030693 — boat movement / transfer; valid starts: 43.
- `FEINDBESETZT` (12) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030694 — port / harbour; valid starts: 38.
- `NORWEGENKARTEN` (14) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030693 — boat movement / transfer; valid starts: 33.
- `STELLKARTEN` (11) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030669 — boat movement / transfer; valid starts: 36.
- `AUSRUESTUNG` (11) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030669 — fuel / supply / transfer; valid starts: 37.
- `HAFENPLAENEN` (12) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030669 — port / harbour; valid starts: 45.
- `AUSNACZEIGLHL` (13) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030700 — boat movement / transfer; valid starts: 37.
- `SOFORTNEUSTADT` (14) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030669 — boat movement / transfer; valid starts: 29.
- `WARNEMUONDEAUS` (14) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030700 — boat movement / transfer; valid starts: 43.
- `HAFENWARNEMUENDE` (16) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030694 — port / harbour; valid starts: 40.
- `WEGDREIUNDWEGVIER` (17) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030693 — boat movement / transfer; valid starts: 29.
- `MARSCHFAHRTEINSZWO` (18) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030693 — boat movement / transfer; valid starts: 27.
- `TRAVEMUENDEBLEIBEN` (18) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030698 — port / harbour; valid starts: 29.
- `MARSCHNACHJNEUSTADT` (19) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030693 — boat movement / transfer; valid starts: 25.
- `ROSTOCKNICHTBEKOMMEN` (20) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030693 — fuel / supply / transfer; valid starts: 23.
- `UUUTENDERMOSELL` (15) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030679 — fuel / supply / transfer; valid starts: 39.
- `NACHWZSTENPASSIRT` (17) — https://enigma.hoerenberg.com/index.php?cat=Breaking+the+M4&page=First+U534+Ciphertext+only+break — boat movement / transfer; valid starts: 23.

## C. 20 strongest training/group-radio fragments
- `SCHALTU` (7) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030693 — communication failure / frequency change; valid starts: 49.
- `BEFEHLEATWART` (13) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030698 — training / tactical exercise; valid starts: 36.
- `MITUUVZWODREI` (13) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030700 — group assembly / rendezvous; valid starts: 42.
- `WEITEREBEFEHLE` (14) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030698 — training / tactical exercise; valid starts: 35.
- `UNKLLRERFUNKSPR` (15) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030699 — communication failure / frequency change; valid starts: 30.
- `UUUFLOTTXVVVUUU` (15) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030700 — training / tactical exercise; valid starts: 29.
- `UUUFLOTT` (8) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030669 — training / tactical exercise; valid starts: 49.
- `GETROFFEN` (9) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030696 — group assembly / rendezvous; valid starts: 44.
- `FOLGEVERBAND` (12) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030696 — group assembly / rendezvous; valid starts: 40.
- `NULUHRSCHLUESS` (14) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030699 — communication failure / frequency change; valid starts: 33.
- `SECHSUHRWARNEMUONDE` (19) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030700 — group assembly / rendezvous; valid starts: 26.
- `FDUUUAESBX` (10) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030679 — training / tactical exercise; valid starts: 47.
- `TORPXINSPEKTION` (15) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030679 — training / tactical exercise; valid starts: 27.
- `ZWODREISECHSEINS` (16) — https://enigma.hoerenberg.com/index.php?cat=Breaking+the+M4&page=First+U534+Ciphertext+only+break — group assembly / rendezvous; valid starts: 29.
- `VERBANDMITGGGSIEBEN` (19) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030696 — group assembly / rendezvous; valid starts: 29.
- `MITUUUVIRSIBENNULZWO` (20) — https://enigma.hoerenberg.com/index.php?cat=Breaking+the+M4&page=First+U534+Ciphertext+only+break — group assembly / rendezvous; valid starts: 29.
- `BEIPOSITIONEINSZWODORA` (22) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030696 — group assembly / rendezvous; valid starts: 24.
- `UEBERNIMMT` (10) — https://enigma.hoerenberg.com/index.php?cat=The+U534+messages&page=P1030705 — training / tactical exercise; valid starts: 47.

## D. Documented Offizier outer-procedure fragments harvested so far
- `UUUEINSEINSNEUN` (15) — https://cryptocellar.org/enigma/e-keys/sonder-schluessel-nixe.pdf — Offizier outer procedure; valid starts: 40.
- `VONBDUUU` (8) — https://cryptocellar.org/enigma/e-keys/sonder-schluessel-nixe.pdf — Offizier outer procedure; valid starts: 53.
- `SONDEREINSEINSZWO` (17) — https://cryptocellar.org/enigma/e-keys/sonder-schluessel-nixe.pdf — Offizier outer procedure; valid starts: 33.

**Limit:** these D items come from the primary M-Nixe instruction that explicitly points to M Offizier/M Stab procedure and substitutes `Sonder` for `Offizier`/`Stab`. Direct M.Dv.32/1 §§81ff. Offizier examples are not yet harvested, so no invented `OFFIZIER...` crib has been added.

## E. Best 10 historically coherent crib constellations

- **K001** `C008;C009` — same-message movement-order family; alternatives, not simultaneous; joint no-self placements: 304.
- **K002** `C045;C046` — both contiguous concepts in P1030698; joint no-self placements: 529.
- **K003** `C040;C042` — same P1030696 group-movement message; joint no-self placements: 507.
- **K004** `C035;C037` — same P1030695 procedural acknowledgement; joint no-self placements: 1031.
- **K005** `C048;C052` — same P1030699 radio-control warning; joint no-self placements: 276.
- **K006** `C025;C027` — same P1030693 movement report; joint no-self placements: 302.
- **K007** `C033;C034` — same P1030694 warning; joint no-self placements: 883.
- **K008** `C059;C057` — same P1030700 group departure register; joint no-self placements: 1076.
- **K009** `C061;C063` — same P1030705 personnel-order register; joint no-self placements: 1286.
- **K010** `C066;C067` — same primary Nixe procedural example; Offizier-related outer-layer control; joint no-self placements: 1117.

## Largest evidence gaps
- P1030680 radio-provenance fields from original/sister sheets.
- Original DEFE3 decrypt pages/headers for ZTPG 367822, 369045, 369054, 369140.
- Primary M.Dv.32/1 §§81ff. Offizier examples.
- Second independent M-Thetis specimen.
- 30 Apr–2 May Baltic training Funkkladden/Funkbücher and flotilla radio orders.
- Exact coverage log for the earlier negative BLEIBTBESETZT/NEUSTADT menu run.
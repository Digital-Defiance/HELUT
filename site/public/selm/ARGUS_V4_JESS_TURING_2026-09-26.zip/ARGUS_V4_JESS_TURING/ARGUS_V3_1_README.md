# ARGUS V3.1 — provenance-aware crib library

This revision fixes a provenance-independence bug exposed during the Jessica crib export.

## Changes
- Every crib now carries `source_document`, `provenance_family`, `source_type`, `independence_group`, `image_verified`, and `provenance_caution`.
- Multiple strings from one specimen are no longer conceptually independent evidence.
- Hörenberg/U-534 material is explicitly tagged `HOERENBERG_U534`.
- `TIER 1 — DIRECT` in legacy data is retained for compatibility but MUST NOT be read as archival-original provenance. Attestation and provenance are separate axes.
- Added `ARGUS_CRIB_PROVENANCE_AUDIT.csv`.
- Added `P1030680_CROSS_CORPUS_CRIB_BATCH_B.csv`, containing only non-Hörenberg families.

## Promotion rule
No crib family may gain evidential weight merely because several fragments come from the same message, webpage, transcription lineage, or derivative corpus. Promotion requires independent provenance or verification against the archival/original image.

# ARGUS V4

Rebuilt after Jessica's full review of V3.2. V4 shifts the centre of gravity from plaintext suggestion to **traffic-metadata reconstruction and independent Thetis-key discovery**.

Current result: **no plaintext**. Hörenberg is retained as context/lookup material but is exhausted as a source for a second Thetis message/key. The primary documentary targets are the original P1030680 sheet and neighbours, especially reception time, frequency, Leitnummer, callsign and repeat mark.

See `JESS_FINDINGS_2026-09-26.md` and `JESS_START_HERE.md`.
